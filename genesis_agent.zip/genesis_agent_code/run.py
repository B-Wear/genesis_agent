"""
Genesis Agent Main Application
----------------------------------------
This is the main entry point for the Genesis Agent application.
"""

import os
import sys
import logging
import argparse
import json
import datetime
import time
import threading
import signal
import webbrowser
from pathlib import Path

# Add the src directory to the Python path
src_dir = os.path.dirname(os.path.abspath(__file__))
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

from src import config
from src.core import GenesisCore
from src.utils import setup_logging, generate_id
from src.database import DatabaseManager
from src.security import SecurityManager
from src.advanced_risk import AdvancedRiskManager
from src.learning import LearningSystem
from src.models import ModelManager
from src.trading import TradingEngine
from src.analysis import AnalysisEngine
from src.ai_strategy import AIStrategyManager

# Configure logging
setup_logging()
logger = logging.getLogger('genesis_agent')

def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='Genesis Agent - Autonomous Financial Intelligence System')
    
    parser.add_argument('--config', type=str, default='config.py',
                        help='Path to configuration file')
    
    parser.add_argument('--data-dir', type=str, default=None,
                        help='Directory for storing data')
    
    parser.add_argument('--log-level', type=str, default=None,
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help='Logging level')
    
    parser.add_argument('--web-port', type=int, default=None,
                        help='Port for web interface')
    
    parser.add_argument('--no-browser', action='store_true',
                        help='Do not open browser automatically')
    
    parser.add_argument('--setup', action='store_true',
                        help='Run initial setup')
    
    parser.add_argument('--reset-db', action='store_true',
                        help='Reset database')
    
    parser.add_argument('--version', action='store_true',
                        help='Show version information')
    
    return parser.parse_args()

def show_version():
    """Show version information."""
    print(f"Genesis Agent v{config.VERSION}")
    print(f"Build date: {config.BUILD_DATE}")
    print(f"Python version: {sys.version}")
    print(f"Platform: {sys.platform}")
    sys.exit(0)

def run_setup(args):
    """Run initial setup."""
    logger.info("Running initial setup")
    
    # Create data directory
    data_dir = args.data_dir or config.DATA_DIR
    os.makedirs(data_dir, exist_ok=True)
    
    # Create subdirectories
    os.makedirs(os.path.join(data_dir, "models"), exist_ok=True)
    os.makedirs(os.path.join(data_dir, "data"), exist_ok=True)
    os.makedirs(os.path.join(data_dir, "logs"), exist_ok=True)
    os.makedirs(os.path.join(data_dir, "strategies"), exist_ok=True)
    os.makedirs(os.path.join(data_dir, "backups"), exist_ok=True)
    
    # Initialize database
    db = DatabaseManager()
    db.initialize()
    
    # Create initial configuration
    if not os.path.exists(args.config):
        with open(args.config, 'w') as f:
            f.write(f"""# Genesis Agent Configuration
# Generated on {datetime.datetime.now().isoformat()}

# General settings
VERSION = "{config.VERSION}"
BUILD_DATE = "{config.BUILD_DATE}"
DEBUG = False
LOG_LEVEL = "INFO"
DATA_DIR = "{data_dir}"

# Web interface settings
WEB_HOST = "0.0.0.0"
WEB_PORT = 8080
WEB_ENABLE_SSL = False
# WEB_SSL_CERT = "/path/to/cert.pem"
# WEB_SSL_KEY = "/path/to/key.pem"

# Database settings
DATABASE_TYPE = "sqlite"
DATABASE_PATH = os.path.join(DATA_DIR, "genesis_agent.db")
# For PostgreSQL
# DATABASE_HOST = "localhost"
# DATABASE_PORT = 5432
# DATABASE_NAME = "genesis_agent"
# DATABASE_USER = "username"
# DATABASE_PASSWORD = "password"

# API keys for external services
ALPACA_API_KEY = ""
ALPACA_API_SECRET = ""
BINANCE_API_KEY = ""
BINANCE_API_SECRET = ""
OPENAI_API_KEY = ""

# Risk management settings
MAX_TRADE_SIZE = 10000.0
MAX_DAILY_VOLUME = 50000.0
MAX_POSITION_SIZE = 0.2  # 20% of portfolio
MAX_LEVERAGE = 2.0
MAX_DRAWDOWN = 0.1  # 10% drawdown
MAX_CONCENTRATION = 0.25  # 25% in single asset

# AI settings
ENABLE_OPENAI = True
OPENAI_MODEL = "gpt-4"
ENABLE_HUGGINGFACE = True
ENABLE_TENSORFLOW = True
ENABLE_PYTORCH = True
ENABLE_SCIKIT_LEARN = True
""")
    
    logger.info("Setup completed successfully")
    print("Setup completed successfully. You can now start Genesis Agent.")
    sys.exit(0)

def reset_database(args):
    """Reset database."""
    logger.info("Resetting database")
    
    # Initialize database
    db = DatabaseManager()
    db.reset()
    
    logger.info("Database reset successfully")
    print("Database reset successfully.")
    sys.exit(0)

def handle_signal(sig, frame):
    """Handle signals."""
    logger.info(f"Received signal {sig}")
    print("\nShutting down Genesis Agent...")
    sys.exit(0)

def main():
    """Main entry point."""
    # Parse arguments
    args = parse_arguments()
    
    # Show version if requested
    if args.version:
        show_version()
    
    # Run setup if requested
    if args.setup:
        run_setup(args)
    
    # Reset database if requested
    if args.reset_db:
        reset_database(args)
    
    # Update configuration
    if args.data_dir:
        config.DATA_DIR = args.data_dir
    
    if args.log_level:
        config.LOG_LEVEL = args.log_level
    
    if args.web_port:
        config.WEB_PORT = args.web_port
    
    # Register signal handlers
    signal.signal(signal.SIGINT, handle_signal)
    signal.signal(signal.SIGTERM, handle_signal)
    
    # Initialize core components
    logger.info("Initializing Genesis Agent")
    
    # Initialize database
    db = DatabaseManager()
    
    # Initialize security manager
    security_manager = SecurityManager(db)
    
    # Initialize model manager
    model_manager = ModelManager(db)
    
    # Initialize analysis engine
    analysis_engine = AnalysisEngine(db, model_manager)
    
    # Initialize trading engine
    trading_engine = TradingEngine(db, security_manager)
    
    # Initialize advanced risk manager
    risk_manager = AdvancedRiskManager(security_manager, security_manager.risk_manager, db)
    
    # Initialize learning system
    learning_system = LearningSystem(model_manager, db)
    
    # Initialize AI strategy manager
    ai_strategy_manager = AIStrategyManager(db, model_manager, learning_system)
    
    # Initialize core
    core = GenesisCore(
        db=db,
        security_manager=security_manager,
        model_manager=model_manager,
        analysis_engine=analysis_engine,
        trading_engine=trading_engine,
        risk_manager=risk_manager,
        learning_system=learning_system,
        ai_strategy_manager=ai_strategy_manager
    )
    
    # Start core
    core.start()
    
    # Start web interface
    web_url = f"http://{config.WEB_HOST}:{config.WEB_PORT}"
    logger.info(f"Web interface available at {web_url}")
    print(f"Genesis Agent started. Web interface available at {web_url}")
    
    # Open browser
    if not args.no_browser:
        webbrowser.open(web_url)
    
    # Keep running
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nShutting down Genesis Agent...")
    finally:
        core.stop()

if __name__ == "__main__":
    main()
