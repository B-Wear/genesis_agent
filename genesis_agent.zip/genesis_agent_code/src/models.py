"""
Genesis Agent Models Module
------------------------
This module handles AI models and machine learning functionality for the Genesis Agent.
"""

import os
import logging
import datetime
import json
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Union

import tensorflow as tf
from tensorflow import keras
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.svm import SVC, SVR
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, mean_squared_error, r2_score

from . import config
from .utils import generate_id

# Configure logging
logger = logging.getLogger('genesis_agent.models')

class ModelManager:
    """
    Manages machine learning models for the Genesis Agent.
    
    This class handles loading, training, and inference for various models
    used in market analysis and prediction.
    """
    
    def __init__(self):
        """Initialize the model manager."""
        self.models = {}
        self.model_configs = {}
        self.scalers = {}
        self.count = 0
        
        # Create models directory if it doesn't exist
        os.makedirs(config.MODELS_DIR, exist_ok=True)
        
        # Load pre-trained models if available
        self._load_pretrained_models()
        
        logger.info(f"Model manager initialized with {self.count} models")
    
    def _load_pretrained_models(self):
        """Load pre-trained models from the models directory."""
        try:
            # Check for model config file
            config_path = os.path.join(config.MODELS_DIR, 'model_configs.json')
            if os.path.exists(config_path):
                with open(config_path, 'r') as f:
                    self.model_configs = json.load(f)
                
                # Load each model
                for model_id, model_config in self.model_configs.items():
                    try:
                        model_type = model_config.get('type', 'unknown')
                        model_path = os.path.join(config.MODELS_DIR, model_id)
                        
                        if model_type == 'tensorflow':
                            if os.path.exists(model_path):
                                self.models[model_id] = tf.keras.models.load_model(model_path)
                                logger.info(f"Loaded TensorFlow model: {model_id}")
                                self.count += 1
                        
                        elif model_type == 'sklearn':
                            model_file = os.path.join(model_path, 'model.pkl')
                            scaler_file = os.path.join(model_path, 'scaler.pkl')
                            
                            if os.path.exists(model_file):
                                import pickle
                                with open(model_file, 'rb') as f:
                                    self.models[model_id] = pickle.load(f)
                                
                                if os.path.exists(scaler_file):
                                    with open(scaler_file, 'rb') as f:
                                        self.scalers[model_id] = pickle.load(f)
                                
                                logger.info(f"Loaded scikit-learn model: {model_id}")
                                self.count += 1
                        
                        else:
                            logger.warning(f"Unknown model type: {model_type} for model {model_id}")
                    
                    except Exception as e:
                        logger.error(f"Error loading model {model_id}: {str(e)}")
            
            else:
                logger.info("No pre-trained models found, initializing with default models")
                self._initialize_default_models()
        
        except Exception as e:
            logger.error(f"Error loading pre-trained models: {str(e)}")
            self._initialize_default_models()
    
    def _initialize_default_models(self):
        """Initialize default models if no pre-trained models are available."""
        try:
            # Create a simple price prediction model
            model_id = generate_id()
            model_config = {
                'type': 'tensorflow',
                'name': 'price_prediction',
                'description': 'Simple LSTM model for price prediction',
                'features': ['close', 'volume', 'open', 'high', 'low'],
                'target': 'close',
                'sequence_length': 10,
                'created_at': datetime.datetime.now().isoformat()
            }
            
            # Create a simple LSTM model
            model = keras.Sequential([
                keras.layers.LSTM(50, return_sequences=True, input_shape=(10, 5)),
                keras.layers.LSTM(50, return_sequences=False),
                keras.layers.Dense(25),
                keras.layers.Dense(1)
            ])
            
            model.compile(optimizer='adam', loss='mean_squared_error')
            
            # Save the model
            self.models[model_id] = model
            self.model_configs[model_id] = model_config
            self.count += 1
            
            # Create a simple market sentiment model
            model_id = generate_id()
            model_config = {
                'type': 'sklearn',
                'name': 'market_sentiment',
                'description': 'Random Forest model for market sentiment classification',
                'features': ['price_change', 'volume_change', 'volatility', 'rsi', 'macd'],
                'target': 'sentiment',
                'created_at': datetime.datetime.now().isoformat()
            }
            
            # Create a simple Random Forest model
            model = RandomForestClassifier(n_estimators=100, random_state=42)
            scaler = StandardScaler()
            
            # Save the model
            self.models[model_id] = model
            self.scalers[model_id] = scaler
            self.model_configs[model_id] = model_config
            self.count += 1
            
            # Save model configurations
            self._save_model_configs()
            
            logger.info(f"Initialized {self.count} default models")
        
        except Exception as e:
            logger.error(f"Error initializing default models: {str(e)}")
    
    def _save_model_configs(self):
        """Save model configurations to file."""
        try:
            config_path = os.path.join(config.MODELS_DIR, 'model_configs.json')
            with open(config_path, 'w') as f:
                json.dump(self.model_configs, f, indent=2)
            
            logger.debug("Saved model configurations")
        
        except Exception as e:
            logger.error(f"Error saving model configurations: {str(e)}")
    
    def get_model(self, model_id: str) -> Optional[Any]:
        """
        Get a model by ID.
        
        Args:
            model_id: ID of the model to retrieve
            
        Returns:
            Model object or None if not found
        """
        return self.models.get(model_id)
    
    def get_model_config(self, model_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a model's configuration by ID.
        
        Args:
            model_id: ID of the model configuration to retrieve
            
        Returns:
            Model configuration dictionary or None if not found
        """
        return self.model_configs.get(model_id)
    
    def get_models_by_type(self, model_type: str) -> Dict[str, Any]:
        """
        Get all models of a specific type.
        
        Args:
            model_type: Type of models to retrieve
            
        Returns:
            Dictionary of models with their IDs as keys
        """
        return {
            model_id: model
            for model_id, model in self.models.items()
            if self.model_configs.get(model_id, {}).get('type') == model_type
        }
    
    def get_models_by_name(self, name: str) -> Dict[str, Any]:
        """
        Get all models with a specific name.
        
        Args:
            name: Name of models to retrieve
            
        Returns:
            Dictionary of models with their IDs as keys
        """
        return {
            model_id: model
            for model_id, model in self.models.items()
            if self.model_configs.get(model_id, {}).get('name') == name
        }
    
    def create_model(self, model_config: Dict[str, Any]) -> str:
        """
        Create a new model.
        
        Args:
            model_config: Configuration for the new model
            
        Returns:
            ID of the created model
        """
        model_id = generate_id()
        model_type = model_config.get('type', 'unknown')
        model_name = model_config.get('name', 'unnamed_model')
        
        logger.info(f"Creating new {model_type} model: {model_name}")
        
        try:
            if model_type == 'tensorflow':
                model = self._create_tensorflow_model(model_config)
            elif model_type == 'sklearn':
                model, scaler = self._create_sklearn_model(model_config)
                self.scalers[model_id] = scaler
            else:
                logger.error(f"Unknown model type: {model_type}")
                return None
            
            # Save the model
            self.models[model_id] = model
            self.model_configs[model_id] = {
                **model_config,
                'created_at': datetime.datetime.now().isoformat()
            }
            self.count += 1
            
            # Save model configurations
            self._save_model_configs()
            
            logger.info(f"Created model {model_id}")
            return model_id
        
        except Exception as e:
            logger.error(f"Error creating model: {str(e)}")
            return None
    
    def _create_tensorflow_model(self, model_config: Dict[str, Any]) -> tf.keras.Model:
        """
        Create a TensorFlow model based on configuration.
        
        Args:
            model_config: Configuration for the model
            
        Returns:
            TensorFlow model
        """
        model_architecture = model_config.get('architecture', 'lstm')
        input_shape = model_config.get('input_shape', (10, 5))
        output_units = model_config.get('output_units', 1)
        
        if model_architecture == 'lstm':
            model = keras.Sequential([
                keras.layers.LSTM(50, return_sequences=True, input_shape=input_shape),
                keras.layers.LSTM(50, return_sequences=False),
                keras.layers.Dense(25),
                keras.layers.Dense(output_units)
            ])
        
        elif model_architecture == 'gru':
            model = keras.Sequential([
                keras.layers.GRU(50, return_sequences=True, input_shape=input_shape),
                keras.layers.GRU(50, return_sequences=False),
                keras.layers.Dense(25),
                keras.layers.Dense(output_units)
            ])
        
        elif model_architecture == 'cnn':
            model = keras.Sequential([
                keras.layers.Conv1D(64, 3, activation='relu', input_shape=input_shape),
                keras.layers.MaxPooling1D(2),
                keras.layers.Conv1D(128, 3, activation='relu'),
                keras.layers.MaxPooling1D(2),
                keras.layers.Flatten(),
                keras.layers.Dense(50, activation='relu'),
                keras.layers.Dense(output_units)
            ])
        
        elif model_architecture == 'mlp':
            model = keras.Sequential([
                keras.layers.Flatten(input_shape=input_shape),
                keras.layers.Dense(100, activation='relu'),
                keras.layers.Dense(50, activation='relu'),
                keras.layers.Dense(output_units)
            ])
        
        else:
            raise ValueError(f"Unknown model architecture: {model_architecture}")
        
        # Compile the model
        loss = model_config.get('loss', 'mean_squared_error')
        optimizer = model_config.get('optimizer', 'adam')
        metrics = model_config.get('metrics', ['mae'])
        
        model.compile(loss=loss, optimizer=optimizer, metrics=metrics)
        return model
    
    def _create_sklearn_model(self, model_config: Dict[str, Any]) -> tuple:
        """
        Create a scikit-learn model based on configuration.
        
        Args:
            model_config: Configuration for the model
            
        Returns:
            Tuple of (model, scaler)
        """
        model_algorithm = model_config.get('algorithm', 'random_forest')
        problem_type = model_config.get('problem_type', 'classification')
        scaler_type = model_config.get('scaler', 'standard')
        
        # Create the scaler
        if scaler_type == 'standard':
            scaler = StandardScaler()
        elif scaler_type == 'minmax':
            scaler = MinMaxScaler()
        else:
            scaler = None
        
        # Create the model
        if problem_type == 'classification':
            if model_algorithm == 'random_forest':
                n_estimators = model_config.get('n_estimators', 100)
                model = RandomForestClassifier(n_estimators=n_estimators, random_state=42)
            
            elif model_algorithm == 'logistic_regression':
                C = model_config.get('C', 1.0)
                model = LogisticRegression(C=C, random_state=42)
            
            elif model_algorithm == 'svm':
                C = model_config.get('C', 1.0)
                kernel = model_config.get('kernel', 'rbf')
                model = SVC(C=C, kernel=kernel, probability=True, random_state=42)
            
            else:
                raise ValueError(f"Unknown classification algorithm: {model_algorithm}")
        
        elif problem_type == 'regression':
            if model_algorithm == 'random_forest':
                n_estimators = model_config.get('n_estimators', 100)
                model = RandomForestRegressor(n_estimators=n_estimators, random_state=42)
            
            elif model_algorithm == 'linear_regression':
                model = LinearRegression()
            
            elif model_algorithm == 'svm':
                C = model_config.get('C', 1.0)
                kernel = model_config.get('kernel', 'rbf')
                model = SVR(C=C, kernel=kernel)
            
            else:
                raise ValueError(f"Unknown regression algorithm: {model_algorithm}")
        
        else:
            raise ValueError(f"Unknown problem type: {problem_type}")
        
        return model, scaler
    
    def train_model(self, model_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Train a model with provided data.
        
        Args:
            model_id: ID of the model to train
            data: Training data and parameters
            
        Returns:
            Dictionary with training results
        """
        if model_id not in self.models:
            logger.error(f"Model {model_id} not found")
            return {"error": f"Model {model_id} not found"}
        
        model = self.models[model_id]
        model_config = self.model_configs.get(model_id, {})
        model_type = model_config.get('type', 'unknown')
        
        logger.info(f"Training {model_type} model {model_id}")
        
        try:
            if model_type == 'tensorflow':
                return self._train_tensorflow_model(model_id, model, model_config, data)
            elif model_type == 'sklearn':
                return self._train_sklearn_model(model_id, model, model_config, data)
            else:
                logger.error(f"Unknown model type: {model_type}")
                return {"error": f"Unknown model type: {model_type}"}
        
        except Exception as e:
            logger.error(f"Error training model {model_id}: {str(e)}")
            return {"error": str(e)}
    
    def _train_tensorflow_model(self, model_id: str, model: tf.keras.Model, model_config: Dict[str, Any], data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Train a TensorFlow model.
        
        Args:
            model_id: ID of the model
            model: TensorFlow model to train
            model_config: Configuration for the model
            data: Training data and parameters
            
        Returns:
            Dictionary with training results
        """
        X_train = data.get('X_train')
        y_train = data.get('y_train')
        X_val = data.get('X_val')
        y_val = data.get('y_val')
        
        if X_train is None or y_train is None:
            return {"error": "Training data not provided"}
        
        # Convert to numpy arrays if needed
        if isinstance(X_train, list):
            X_train = np.array(X_train)
        if isinstance(y_train, list):
            y_train = np.array(y_train)
        if isinstance(X_val, list):
            X_val = np.array(X_val)
        if isinstance(y_val, list):
            y_val = np.array(y_val)
        
        # Get training parameters
        epochs = data.get('epochs', 10)
        batch_size = data.get('batch_size', 32)
        validation_split = data.get('validation_split', 0.2)
        
        # Prepare validation data
        validation_data = None
        if X_val is not None and y_val is not None:
            validation_data = (X_val, y_val)
        
        # Train the model
        history = model.fit(
            X_train, y_train,
            epochs=epochs,
            batch_size=batch_size,
            validation_split=validation_split if validation_data is None else 0,
            validation_data=validation_data,
            verbose=0
        )
        
        # Save the model
        model_path = os.path.join(config.MODELS_DIR, model_id)
        model.save(model_path)
        
        # Update model config with training info
        self.model_configs[model_id]['last_trained'] = datetime.datetime.now().isoformat()
        self.model_configs[model_id]['training_samples'] = len(X_train)
        self._save_model_configs()
        
        # Return training history
        return {
            "model_id": model_id,
            "epochs": epochs,
            "training_samples": len(X_train),
            "validation_samples": len(X_val) if X_val is not None else int(len(X_train) * validation_split),
            "loss": history.history['loss'][-1],
            "val_loss": history.history['val_loss'][-1] if 'val_loss' in history.history else None,
            "metrics": {
                metric: history.history[metric][-1]
                for metric in history.history
                if metric not in ['loss', 'val_loss']
            }
        }
    
    def _train_sklearn_model(self, model_id: str, model: Any, model_config: Dict[str, Any], data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Train a scikit-learn model.
        
        Args:
            model_id: ID of the model
            model: scikit-learn model to train
            model_config: Configuration for the model
            data: Training data and parameters
            
        Returns:
            Dictionary with training results
        """
        X_train = data.get('X_train')
        y_train = data.get('y_train')
        X_val = data.get('X_val')
        y_val = data.get('y_val')
        
        if X_train is None or y_train is None:
            return {"error": "Training data not provided"}
        
        # Convert to numpy arrays if needed
        if isinstance(X_train, list):
            X_train = np.array(X_train)
        if isinstance(y_train, list):
            y_train = np.array(y_train)
        if isinstance(X_val, list):
            X_val = np.array(X_val)
        if isinstance(y_val, list):
            y_val = np.array(y_val)
        
        # Scale the data if a scaler is available
        scaler = self.scalers.get(model_id)
        if scaler is not None:
            X_train = scaler.fit_transform(X_train)
            if X_val is not None:
                X_val = scaler.transform(X_val)
        
        # Train the model
        model.fit(X_train, y_train)
        
        # Evaluate the model
        train_score = model.score(X_train, y_train)
        val_score = None
        if X_val is not None and y_val is not None:
            val_score = model.score(X_val, y_val)
        
        # Save the model
        model_path = os.path.join(config.MODELS_DIR, model_id)
        os.makedirs(model_path, exist_ok=True)
        
        import pickle
        with open(os.path.join(model_path, 'model.pkl'), 'wb') as f:
            pickle.dump(model, f)
        
        if scaler is not None:
            with open(os.path.join(model_path, 'scaler.pkl'), 'wb') as f:
                pickle.dump(scaler, f)
        
        # Update model config with training info
        self.model_configs[model_id]['last_trained'] = datetime.datetime.now().isoformat()
        self.model_configs[model_id]['training_samples'] = len(X_train)
        self._save_model_configs()
        
        # Get detailed metrics
        problem_type = model_config.get('problem_type', 'classification')
        detailed_metrics = {}
        
        if X_val is not None and y_val is not None:
            y_pred = model.predict(X_val)
            
            if problem_type == 'classification':
                detailed_metrics = {
                    "accuracy": accuracy_score(y_val, y_pred),
                    "precision": precision_score(y_val, y_pred, average='weighted') if len(np.unique(y_val)) > 1 else None,
                    "recall": recall_score(y_val, y_pred, average='weighted') if len(np.unique(y_val)) > 1 else None,
                    "f1": f1_score(y_val, y_pred, average='weighted') if len(np.unique(y_val)) > 1 else None
                }
            elif problem_type == 'regression':
                detailed_metrics = {
                    "mse": mean_squared_error(y_val, y_pred),
                    "rmse": np.sqrt(mean_squared_error(y_val, y_pred)),
                    "r2": r2_score(y_val, y_pred)
                }
        
        # Return training results
        return {
            "model_id": model_id,
            "training_samples": len(X_train),
            "validation_samples": len(X_val) if X_val is not None else 0,
            "train_score": train_score,
            "val_score": val_score,
            "detailed_metrics": detailed_metrics
        }
    
    def predict(self, model_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Make predictions with a model.
        
        Args:
            model_id: ID of the model to use
            data: Input data for prediction
            
        Returns:
            Dictionary with prediction results
        """
        if model_id not in self.models:
            logger.error(f"Model {model_id} not found")
            return {"error": f"Model {model_id} not found"}
        
        model = self.models[model_id]
        model_config = self.model_configs.get(model_id, {})
        model_type = model_config.get('type', 'unknown')
        
        logger.info(f"Making predictions with {model_type} model {model_id}")
        
        try:
            X = data.get('X')
            if X is None:
                return {"error": "Input data not provided"}
            
            # Convert to numpy array if needed
            if isinstance(X, list):
                X = np.array(X)
            
            if model_type == 'tensorflow':
                # Make predictions
                predictions = model.predict(X)
                
                # Convert to list for JSON serialization
                predictions = predictions.tolist()
                
                return {
                    "model_id": model_id,
                    "predictions": predictions
                }
            
            elif model_type == 'sklearn':
                # Scale the data if a scaler is available
                scaler = self.scalers.get(model_id)
                if scaler is not None:
                    X = scaler.transform(X)
                
                # Make predictions
                predictions = model.predict(X)
                
                # Get prediction probabilities if available (for classification)
                probabilities = None
                if hasattr(model, 'predict_proba'):
                    try:
                        probabilities = model.predict_proba(X).tolist()
                    except:
                        pass
                
                # Convert to list for JSON serialization
                predictions = predictions.tolist()
                
                return {
                    "model_id": model_id,
                    "predictions": predictions,
                    "probabilities": probabilities
                }
            
            else:
                logger.error(f"Unknown model type: {model_type}")
                return {"error": f"Unknown model type: {model_type}"}
        
        except Exception as e:
            logger.error(f"Error making predictions with model {model_id}: {str(e)}")
            return {"error": str(e)}
    
    def delete_model(self, model_id: str) -> bool:
        """
        Delete a model.
        
        Args:
            model_id: ID of the model to delete
            
        Returns:
            True if successful, False otherwise
        """
        if model_id not in self.models:
            logger.error(f"Model {model_id} not found")
            return False
        
        try:
            # Remove from memory
            del self.models[model_id]
            if model_id in self.scalers:
                del self.scalers[model_id]
            
            # Remove from configurations
            if model_id in self.model_configs:
                del self.model_configs[model_id]
                self._save_model_configs()
            
            # Remove from disk
            model_path = os.path.join(config.MODELS_DIR, model_id)
            if os.path.exists(model_path):
                import shutil
                shutil.rmtree(model_path)
            
            self.count -= 1
            logger.info(f"Deleted model {model_id}")
            return True
        
        except Exception as e:
            logger.error(f"Error deleting model {model_id}: {str(e)}")
            return False
    
    def check_health(self) -> bool:
        """
        Check if the model manager is healthy.
        
        Returns:
            True if healthy, False otherwise
        """
        try:
            # Check if models directory exists
            if not os.path.exists(config.MODELS_DIR):
                logger.error("Models directory does not exist")
                return False
            
            # Check if at least one model is loaded
            if len(self.models) == 0:
                logger.warning("No models are loaded")
                return False
            
            # Try to make a simple prediction with each model
            for model_id, model in self.models.items():
                model_config = self.model_configs.get(model_id, {})
                model_type = model_config.get('type', 'unknown')
                
                if model_type == 'tensorflow':
                    # Get input shape from model
                    input_shape = model.input_shape[1:]
                    # Create a dummy input
                    dummy_input = np.zeros((1,) + input_shape)
                    # Try to predict
                    model.predict(dummy_input)
                
                elif model_type == 'sklearn':
                    # Get number of features
                    if hasattr(model, 'n_features_in_'):
                        n_features = model.n_features_in_
                    else:
                        n_features = 5  # Default
                    
                    # Create a dummy input
                    dummy_input = np.zeros((1, n_features))
                    
                    # Scale if needed
                    if model_id in self.scalers:
                        dummy_input = self.scalers[model_id].transform(dummy_input)
                    
                    # Try to predict
                    model.predict(dummy_input)
            
            return True
        
        except Exception as e:
            logger.error(f"Model health check failed: {str(e)}")
            return False
