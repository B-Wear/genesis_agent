"""
Genesis Agent Configuration Module
---------------------------------
This module contains configuration settings for the Genesis Agent system.
"""

import os
from dotenv import load_dotenv

# Load environment variables from .env file if present
load_dotenv()

# Core Configuration
DEBUG = os.getenv('DEBUG', 'False').lower() == 'true'
SECRET_KEY = os.getenv('SECRET_KEY', 'genesis-agent-default-secret-key-change-in-production')
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')

# Database Configuration
DB_TYPE = os.getenv('DB_TYPE', 'sqlite')  # Options: sqlite, postgresql, mongodb
DB_HOST = os.getenv('DB_HOST', 'localhost')
DB_PORT = int(os.getenv('DB_PORT', '27017'))
DB_NAME = os.getenv('DB_NAME', 'genesis_agent')
DB_USER = os.getenv('DB_USER', '')
DB_PASSWORD = os.getenv('DB_PASSWORD', '')
SQLITE_PATH = os.getenv('SQLITE_PATH', 'genesis_agent.db')

# API Configuration
API_VERSION = 'v1'
API_PREFIX = f'/api/{API_VERSION}'
JWT_EXPIRATION_HOURS = int(os.getenv('JWT_EXPIRATION_HOURS', '24'))
RATE_LIMIT = int(os.getenv('RATE_LIMIT', '100'))  # Requests per minute

# Web Interface Configuration
WEB_HOST = os.getenv('WEB_HOST', '0.0.0.0')
WEB_PORT = int(os.getenv('WEB_PORT', '5000'))
ENABLE_CORS = os.getenv('ENABLE_CORS', 'True').lower() == 'true'
CORS_ORIGINS = os.getenv('CORS_ORIGINS', '*').split(',')

# Financial API Keys
ALPACA_API_KEY = os.getenv('ALPACA_API_KEY', '')
ALPACA_API_SECRET = os.getenv('ALPACA_API_SECRET', '')
ALPACA_BASE_URL = os.getenv('ALPACA_BASE_URL', 'https://paper-api.alpaca.markets')

BINANCE_API_KEY = os.getenv('BINANCE_API_KEY', '')
BINANCE_API_SECRET = os.getenv('BINANCE_API_SECRET', '')

YAHOO_FINANCE_RAPID_API_KEY = os.getenv('YAHOO_FINANCE_RAPID_API_KEY', '')

# AI Model Configuration
MODEL_PATH = os.getenv('MODEL_PATH', 'models')
USE_GPU = os.getenv('USE_GPU', 'False').lower() == 'true'
MAX_SEQUENCE_LENGTH = int(os.getenv('MAX_SEQUENCE_LENGTH', '512'))
BATCH_SIZE = int(os.getenv('BATCH_SIZE', '32'))

# Security Configuration
ENCRYPTION_KEY = os.getenv('ENCRYPTION_KEY', SECRET_KEY)
PASSWORD_SALT = os.getenv('PASSWORD_SALT', 'genesis-agent-salt-change-in-production')
HASH_ALGORITHM = os.getenv('HASH_ALGORITHM', 'sha256')
MIN_PASSWORD_LENGTH = int(os.getenv('MIN_PASSWORD_LENGTH', '12'))

# Monitoring Configuration
ENABLE_MONITORING = os.getenv('ENABLE_MONITORING', 'True').lower() == 'true'
MONITORING_INTERVAL = int(os.getenv('MONITORING_INTERVAL', '60'))  # Seconds
LOG_FILE_PATH = os.getenv('LOG_FILE_PATH', 'logs')

# Trading Configuration
TRADING_ENABLED = os.getenv('TRADING_ENABLED', 'False').lower() == 'true'
MAX_POSITION_SIZE = float(os.getenv('MAX_POSITION_SIZE', '0.1'))  # Percentage of portfolio
RISK_TOLERANCE = float(os.getenv('RISK_TOLERANCE', '0.02'))  # Maximum loss per trade
DEFAULT_STOP_LOSS = float(os.getenv('DEFAULT_STOP_LOSS', '0.05'))  # 5% stop loss
DEFAULT_TAKE_PROFIT = float(os.getenv('DEFAULT_TAKE_PROFIT', '0.1'))  # 10% take profit

# Paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, 'data')
MODELS_DIR = os.path.join(BASE_DIR, 'models')
LOGS_DIR = os.path.join(BASE_DIR, 'logs')

# Create necessary directories if they don't exist
for directory in [DATA_DIR, MODELS_DIR, LOGS_DIR]:
    os.makedirs(directory, exist_ok=True)
