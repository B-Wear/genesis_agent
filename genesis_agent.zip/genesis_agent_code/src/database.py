"""
Genesis Agent Database Module
---------------------------
This module handles database operations for the Genesis Agent system.
"""

import os
import logging
import datetime
import json
import sqlite3
from typing import Dict, List, Any, Optional, Union

try:
    import pymongo
    MONGODB_AVAILABLE = True
except ImportError:
    MONGODB_AVAILABLE = False

try:
    import sqlalchemy
    from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Text, JSON
    from sqlalchemy.ext.declarative import declarative_base
    from sqlalchemy.orm import sessionmaker
    SQLALCHEMY_AVAILABLE = True
except ImportError:
    SQLALCHEMY_AVAILABLE = False

from . import config
from .utils import generate_id

# Configure logging
logger = logging.getLogger('genesis_agent.database')

class DatabaseManager:
    """
    Manages database operations for the Genesis Agent.
    
    Supports multiple database backends (SQLite, PostgreSQL, MongoDB)
    based on configuration settings.
    """
    
    def __init__(self):
        """Initialize the database connection based on configuration."""
        self.db_type = config.DB_TYPE.lower()
        
        if self.db_type == 'sqlite':
            self._init_sqlite()
        elif self.db_type == 'postgresql':
            if not SQLALCHEMY_AVAILABLE:
                logger.error("SQLAlchemy not available, falling back to SQLite")
                self.db_type = 'sqlite'
                self._init_sqlite()
            else:
                self._init_postgresql()
        elif self.db_type == 'mongodb':
            if not MONGODB_AVAILABLE:
                logger.error("PyMongo not available, falling back to SQLite")
                self.db_type = 'sqlite'
                self._init_sqlite()
            else:
                self._init_mongodb()
        else:
            logger.warning(f"Unknown database type: {self.db_type}, falling back to SQLite")
            self.db_type = 'sqlite'
            self._init_sqlite()
        
        logger.info(f"Database initialized with type: {self.db_type}")
    
    def _init_sqlite(self):
        """Initialize SQLite database connection."""
        self.db_path = os.path.join(config.DATA_DIR, config.SQLITE_PATH)
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        
        # Create tables if they don't exist
        cursor = self.conn.cursor()
        
        # Metrics table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS metrics (
            id TEXT PRIMARY KEY,
            agent_id TEXT,
            timestamp TEXT,
            data TEXT
        )
        ''')
        
        # Analysis table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS analysis (
            id TEXT PRIMARY KEY,
            agent_id TEXT,
            market_id TEXT,
            timestamp TEXT,
            data TEXT
        )
        ''')
        
        # Strategies table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS strategies (
            id TEXT PRIMARY KEY,
            agent_id TEXT,
            timestamp TEXT,
            data TEXT
        )
        ''')
        
        # Executions table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS executions (
            id TEXT PRIMARY KEY,
            agent_id TEXT,
            strategy_id TEXT,
            timestamp TEXT,
            data TEXT
        )
        ''')
        
        # Reports table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS reports (
            id TEXT PRIMARY KEY,
            agent_id TEXT,
            timestamp TEXT,
            data TEXT
        )
        ''')
        
        # Users table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            username TEXT UNIQUE,
            password_hash TEXT,
            email TEXT,
            created_at TEXT,
            last_login TEXT,
            settings TEXT
        )
        ''')
        
        # Commit changes
        self.conn.commit()
    
    def _init_postgresql(self):
        """Initialize PostgreSQL database connection using SQLAlchemy."""
        connection_string = f"postgresql://{config.DB_USER}:{config.DB_PASSWORD}@{config.DB_HOST}:{config.DB_PORT}/{config.DB_NAME}"
        self.engine = create_engine(connection_string)
        self.Base = declarative_base()
        
        # Define models
        class Metric(self.Base):
            __tablename__ = 'metrics'
            id = Column(String, primary_key=True)
            agent_id = Column(String)
            timestamp = Column(DateTime)
            data = Column(JSON)
        
        class Analysis(self.Base):
            __tablename__ = 'analysis'
            id = Column(String, primary_key=True)
            agent_id = Column(String)
            market_id = Column(String)
            timestamp = Column(DateTime)
            data = Column(JSON)
        
        class Strategy(self.Base):
            __tablename__ = 'strategies'
            id = Column(String, primary_key=True)
            agent_id = Column(String)
            timestamp = Column(DateTime)
            data = Column(JSON)
        
        class Execution(self.Base):
            __tablename__ = 'executions'
            id = Column(String, primary_key=True)
            agent_id = Column(String)
            strategy_id = Column(String)
            timestamp = Column(DateTime)
            data = Column(JSON)
        
        class Report(self.Base):
            __tablename__ = 'reports'
            id = Column(String, primary_key=True)
            agent_id = Column(String)
            timestamp = Column(DateTime)
            data = Column(JSON)
        
        class User(self.Base):
            __tablename__ = 'users'
            id = Column(String, primary_key=True)
            username = Column(String, unique=True)
            password_hash = Column(String)
            email = Column(String)
            created_at = Column(DateTime)
            last_login = Column(DateTime)
            settings = Column(JSON)
        
        # Create tables
        self.Base.metadata.create_all(self.engine)
        
        # Create session
        Session = sessionmaker(bind=self.engine)
        self.session = Session()
        
        # Store model classes for later use
        self.models = {
            'Metric': Metric,
            'Analysis': Analysis,
            'Strategy': Strategy,
            'Execution': Execution,
            'Report': Report,
            'User': User
        }
    
    def _init_mongodb(self):
        """Initialize MongoDB database connection."""
        self.client = pymongo.MongoClient(
            host=config.DB_HOST,
            port=config.DB_PORT,
            username=config.DB_USER if config.DB_USER else None,
            password=config.DB_PASSWORD if config.DB_PASSWORD else None
        )
        self.db = self.client[config.DB_NAME]
        
        # Create collections (they are created automatically when first used)
        self.metrics = self.db.metrics
        self.analysis = self.db.analysis
        self.strategies = self.db.strategies
        self.executions = self.db.executions
        self.reports = self.db.reports
        self.users = self.db.users
        
        # Create indexes
        self.metrics.create_index([("agent_id", pymongo.ASCENDING), ("timestamp", pymongo.DESCENDING)])
        self.analysis.create_index([("agent_id", pymongo.ASCENDING), ("market_id", pymongo.ASCENDING), ("timestamp", pymongo.DESCENDING)])
        self.strategies.create_index([("agent_id", pymongo.ASCENDING)])
        self.executions.create_index([("agent_id", pymongo.ASCENDING), ("strategy_id", pymongo.ASCENDING), ("timestamp", pymongo.DESCENDING)])
        self.reports.create_index([("agent_id", pymongo.ASCENDING), ("timestamp", pymongo.DESCENDING)])
        self.users.create_index([("username", pymongo.ASCENDING)], unique=True)
    
    def save_metrics(self, agent_id: str, metrics: Dict[str, Any]) -> str:
        """
        Save performance metrics to the database.
        
        Args:
            agent_id: ID of the agent
            metrics: Dictionary of metrics to save
            
        Returns:
            ID of the saved metrics record
        """
        record_id = generate_id()
        timestamp = datetime.datetime.now()
        
        try:
            if self.db_type == 'sqlite':
                cursor = self.conn.cursor()
                cursor.execute(
                    "INSERT INTO metrics (id, agent_id, timestamp, data) VALUES (?, ?, ?, ?)",
                    (record_id, agent_id, timestamp.isoformat(), json.dumps(metrics))
                )
                self.conn.commit()
            
            elif self.db_type == 'postgresql':
                metric = self.models['Metric'](
                    id=record_id,
                    agent_id=agent_id,
                    timestamp=timestamp,
                    data=metrics
                )
                self.session.add(metric)
                self.session.commit()
            
            elif self.db_type == 'mongodb':
                self.metrics.insert_one({
                    "_id": record_id,
                    "agent_id": agent_id,
                    "timestamp": timestamp,
                    "data": metrics
                })
            
            logger.debug(f"Saved metrics for agent {agent_id}")
            return record_id
        
        except Exception as e:
            logger.error(f"Error saving metrics: {str(e)}")
            if self.db_type == 'postgresql':
                self.session.rollback()
            return None
    
    def save_analysis(self, agent_id: str, market_id: str, analysis_data: Dict[str, Any]) -> str:
        """
        Save market analysis results to the database.
        
        Args:
            agent_id: ID of the agent
            market_id: ID of the market analyzed
            analysis_data: Analysis results
            
        Returns:
            ID of the saved analysis record
        """
        record_id = generate_id()
        timestamp = datetime.datetime.now()
        
        try:
            if self.db_type == 'sqlite':
                cursor = self.conn.cursor()
                cursor.execute(
                    "INSERT INTO analysis (id, agent_id, market_id, timestamp, data) VALUES (?, ?, ?, ?, ?)",
                    (record_id, agent_id, market_id, timestamp.isoformat(), json.dumps(analysis_data))
                )
                self.conn.commit()
            
            elif self.db_type == 'postgresql':
                analysis = self.models['Analysis'](
                    id=record_id,
                    agent_id=agent_id,
                    market_id=market_id,
                    timestamp=timestamp,
                    data=analysis_data
                )
                self.session.add(analysis)
                self.session.commit()
            
            elif self.db_type == 'mongodb':
                self.analysis.insert_one({
                    "_id": record_id,
                    "agent_id": agent_id,
                    "market_id": market_id,
                    "timestamp": timestamp,
                    "data": analysis_data
                })
            
            logger.debug(f"Saved analysis for market {market_id}")
            return record_id
        
        except Exception as e:
            logger.error(f"Error saving analysis: {str(e)}")
            if self.db_type == 'postgresql':
                self.session.rollback()
            return None
    
    def save_strategy(self, agent_id: str, strategy_id: str, strategy_data: Dict[str, Any]) -> bool:
        """
        Save a strategy to the database.
        
        Args:
            agent_id: ID of the agent
            strategy_id: ID of the strategy
            strategy_data: Strategy configuration and metadata
            
        Returns:
            True if successful, False otherwise
        """
        timestamp = datetime.datetime.now()
        
        try:
            if self.db_type == 'sqlite':
                cursor = self.conn.cursor()
                cursor.execute(
                    "INSERT INTO strategies (id, agent_id, timestamp, data) VALUES (?, ?, ?, ?)",
                    (strategy_id, agent_id, timestamp.isoformat(), json.dumps(strategy_data))
                )
                self.conn.commit()
            
            elif self.db_type == 'postgresql':
                strategy = self.models['Strategy'](
                    id=strategy_id,
                    agent_id=agent_id,
                    timestamp=timestamp,
                    data=strategy_data
                )
                self.session.add(strategy)
                self.session.commit()
            
            elif self.db_type == 'mongodb':
                self.strategies.insert_one({
                    "_id": strategy_id,
                    "agent_id": agent_id,
                    "timestamp": timestamp,
                    "data": strategy_data
                })
            
            logger.debug(f"Saved strategy {strategy_id}")
            return True
        
        except Exception as e:
            logger.error(f"Error saving strategy: {str(e)}")
            if self.db_type == 'postgresql':
                self.session.rollback()
            return False
    
    def save_execution(self, agent_id: str, strategy_id: str, execution_data: Dict[str, Any]) -> str:
        """
        Save strategy execution results to the database.
        
        Args:
            agent_id: ID of the agent
            strategy_id: ID of the strategy executed
            execution_data: Execution results
            
        Returns:
            ID of the saved execution record
        """
        record_id = generate_id()
        timestamp = datetime.datetime.now()
        
        try:
            if self.db_type == 'sqlite':
                cursor = self.conn.cursor()
                cursor.execute(
                    "INSERT INTO executions (id, agent_id, strategy_id, timestamp, data) VALUES (?, ?, ?, ?, ?)",
                    (record_id, agent_id, strategy_id, timestamp.isoformat(), json.dumps(execution_data))
                )
                self.conn.commit()
            
            elif self.db_type == 'postgresql':
                execution = self.models['Execution'](
                    id=record_id,
                    agent_id=agent_id,
                    strategy_id=strategy_id,
                    timestamp=timestamp,
                    data=execution_data
                )
                self.session.add(execution)
                self.session.commit()
            
            elif self.db_type == 'mongodb':
                self.executions.insert_one({
                    "_id": record_id,
                    "agent_id": agent_id,
                    "strategy_id": strategy_id,
                    "timestamp": timestamp,
                    "data": execution_data
                })
            
            logger.debug(f"Saved execution for strategy {strategy_id}")
            return record_id
        
        except Exception as e:
            logger.error(f"Error saving execution: {str(e)}")
            if self.db_type == 'postgresql':
                self.session.rollback()
            return None
    
    def save_report(self, agent_id: str, report_id: str, report_data: Dict[str, Any]) -> bool:
        """
        Save a report to the database.
        
        Args:
            agent_id: ID of the agent
            report_id: ID of the report
            report_data: Report content and metadata
            
        Returns:
            True if successful, False otherwise
        """
        timestamp = datetime.datetime.now()
        
        try:
            if self.db_type == 'sqlite':
                cursor = self.conn.cursor()
                cursor.execute(
                    "INSERT INTO reports (id, agent_id, timestamp, data) VALUES (?, ?, ?, ?)",
                    (report_id, agent_id, timestamp.isoformat(), json.dumps(report_data))
                )
                self.conn.commit()
            
            elif self.db_type == 'postgresql':
                report = self.models['Report'](
                    id=report_id,
                    agent_id=agent_id,
                    timestamp=timestamp,
                    data=report_data
                )
                self.session.add(report)
                self.session.commit()
            
            elif self.db_type == 'mongodb':
                self.reports.insert_one({
                    "_id": report_id,
                    "agent_id": agent_id,
                    "timestamp": timestamp,
                    "data": report_data
                })
            
            logger.debug(f"Saved report {report_id}")
            return True
        
        except Exception as e:
            logger.error(f"Error saving report: {str(e)}")
            if self.db_type == 'postgresql':
                self.session.rollback()
            return False
    
    def get_metrics(self, agent_id: str, start_date: str = None, end_date: str = None) -> List[Dict[str, Any]]:
        """
        Retrieve metrics from the database.
        
        Args:
            agent_id: ID of the agent
            start_date: Start date for filtering (ISO format)
            end_date: End date for filtering (ISO format)
            
        Returns:
            List of metrics records
        """
        try:
            if start_date is None:
                start_date = (datetime.datetime.now() - datetime.timedelta(days=30)).isoformat()
            
            if end_date is None:
                end_date = datetime.datetime.now().isoformat()
            
            if self.db_type == 'sqlite':
                cursor = self.conn.cursor()
                cursor.execute(
                    "SELECT * FROM metrics WHERE agent_id = ? AND timestamp >= ? AND timestamp <= ? ORDER BY timestamp",
                    (agent_id, start_date, end_date)
                )
                rows = cursor.fetchall()
                return [{"id": row["id"], "timestamp": row["timestamp"], **json.loads(row["data"])} for row in rows]
            
            elif self.db_type == 'postgresql':
                start = datetime.datetime.fromisoformat(start_date)
                end = datetime.datetime.fromisoformat(end_date)
                
                metrics = self.session.query(self.models['Metric']).filter(
                    self.models['Metric'].agent_id == agent_id,
                    self.models['Metric'].timestamp >= start,
                    self.models['Metric'].timestamp <= end
                ).order_by(self.models['Metric'].timestamp).all()
                
                return [{"id": metric.id, "timestamp": metric.timestamp.isoformat(), **metric.data} for metric in metrics]
            
            elif self.db_type == 'mongodb':
                metrics = self.metrics.find({
                    "agent_id": agent_id,
                    "timestamp": {
                        "$gte": datetime.datetime.fromisoformat(start_date),
                        "$lte": datetime.datetime.fromisoformat(end_date)
                    }
                }).sort("timestamp", 1)
                
                return [{"id": str(metric["_id"]), "timestamp": metric["timestamp"].isoformat(), **metric["data"]} for metric in metrics]
            
            return []
        
        except Exception as e:
            logger.error(f"Error retrieving metrics: {str(e)}")
            return []
    
    def get_analysis(self, agent_id: str, market_id: str = None, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Retrieve analysis records from the database.
        
        Args:
            agent_id: ID of the agent
            market_id: Optional market ID to filter by
            limit: Maximum number of records to return
            
        Returns:
            List of analysis records
        """
        try:
            if self.db_type == 'sqlite':
                cursor = self.conn.cursor()
                
                if market_id:
                    cursor.execute(
                        "SELECT * FROM analysis WHERE agent_id = ? AND market_id = ? ORDER BY timestamp DESC LIMIT ?",
                        (agent_id, market_id, limit)
                    )
                else:
                    cursor.execute(
                        "SELECT * FROM analysis WHERE agent_id = ? ORDER BY timestamp DESC LIMIT ?",
                        (agent_id, limit)
                    )
                
                rows = cursor.fetchall()
                return [{"id": row["id"], "market_id": row["market_id"], "timestamp": row["timestamp"], **json.loads(row["data"])} for row in rows]
            
            elif self.db_type == 'postgresql':
                query = self.session.query(self.models['Analysis']).filter(self.models['Analysis'].agent_id == agent_id)
                
                if market_id:
                    query = query.filter(self.models['Analysis'].market_id == market_id)
                
                analyses = query.order_by(self.models['Analysis'].timestamp.desc()).limit(limit).all()
                
                return [{"id": analysis.id, "market_id": analysis.market_id, "timestamp": analysis.timestamp.isoformat(), **analysis.data} for analysis in analyses]
            
            elif self.db_type == 'mongodb':
                query = {"agent_id": agent_id}
                
                if market_id:
                    query["market_id"] = market_id
                
                analyses = self.analysis.find(query).sort("timestamp", -1).limit(limit)
                
                return [{"id": str(analysis["_id"]), "market_id": analysis["market_id"], "timestamp": analysis["timestamp"].isoformat(), **analysis["data"]} for analysis in analyses]
            
            return []
        
        except Exception as e:
            logger.error(f"Error retrieving analysis: {str(e)}")
            return []
    
    def check_health(self) -> bool:
        """
        Check if the database connection is healthy.
        
        Returns:
            True if healthy, False otherwise
        """
        try:
            if self.db_type == 'sqlite':
                cursor = self.conn.cursor()
                cursor.execute("SELECT 1")
                return cursor.fetchone() is not None
            
            elif self.db_type == 'postgresql':
                result = self.session.execute("SELECT 1").scalar()
                return result == 1
            
            elif self.db_type == 'mongodb':
                return self.client.admin.command('ping')['ok'] == 1
            
            return False
        
        except Exception as e:
            logger.error(f"Database health check failed: {str(e)}")
            return False
    
    def close(self):
        """Close the database connection."""
        try:
            if self.db_type == 'sqlite':
                self.conn.close()
            
            elif self.db_type == 'postgresql':
                self.session.close()
                self.engine.dispose()
            
            elif self.db_type == 'mongodb':
                self.client.close()
            
            logger.info("Database connection closed")
        
        except Exception as e:
            logger.error(f"Error closing database connection: {str(e)}")
