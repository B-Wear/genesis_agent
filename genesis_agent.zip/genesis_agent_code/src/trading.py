"""
Genesis Agent Trading Module
-------------------------
This module handles trading operations for the Genesis Agent.
"""

import os
import logging
import datetime
import json
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Union
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

from . import config
from .analysis import AnalysisEngine
from .database import DatabaseManager
from .utils import generate_id, format_currency, safe_divide

# Configure logging
logger = logging.getLogger('genesis_agent.trading')

class TradingEngine:
    """
    Handles trading operations for the Genesis Agent.
    
    This class provides methods for executing trades, managing portfolios,
    and implementing trading strategies.
    """
    
    def __init__(self, analysis_engine: AnalysisEngine = None, database: DatabaseManager = None):
        """
        Initialize the trading engine.
        
        Args:
            analysis_engine: AnalysisEngine instance for market analysis
            database: DatabaseManager instance for data storage
        """
        self.analysis_engine = analysis_engine
        self.database = database
        self.trading_platforms = self._initialize_trading_platforms()
        self.strategies = {}
        self.active_trades = {}
        self.portfolio = self._initialize_portfolio()
        self.trade_history = []
        self.performance_metrics = {
            "trades_executed": 0,
            "successful_trades": 0,
            "total_profit_loss": 0.0,
            "win_rate": 0.0,
            "average_return": 0.0
        }
        
        logger.info("Trading engine initialized")
    
    def _initialize_trading_platforms(self) -> Dict[str, Any]:
        """Initialize connections to trading platforms."""
        trading_platforms = {
            "alpaca": {
                "name": "Alpaca",
                "type": "stock",
                "enabled": True,
                "paper_trading": True,
                "api_key": config.ALPACA_API_KEY if hasattr(config, 'ALPACA_API_KEY') else None,
                "api_secret": config.ALPACA_API_SECRET if hasattr(config, 'ALPACA_API_SECRET') else None,
                "base_url": config.ALPACA_BASE_URL if hasattr(config, 'ALPACA_BASE_URL') else "https://paper-api.alpaca.markets"
            },
            "binance": {
                "name": "Binance",
                "type": "crypto",
                "enabled": True,
                "paper_trading": True,
                "api_key": config.BINANCE_API_KEY if hasattr(config, 'BINANCE_API_KEY') else None,
                "api_secret": config.BINANCE_API_SECRET if hasattr(config, 'BINANCE_API_SECRET') else None
            },
            "simulated": {
                "name": "Simulated Trading",
                "type": "simulated",
                "enabled": True,
                "paper_trading": True
            }
        }
        
        # Initialize connections to enabled platforms
        for platform_id, platform_info in trading_platforms.items():
            if platform_info["enabled"]:
                try:
                    if platform_id == "alpaca" and platform_info["api_key"] and platform_info["api_secret"]:
                        import alpaca_trade_api as tradeapi
                        platform_info["client"] = tradeapi.REST(
                            platform_info["api_key"],
                            platform_info["api_secret"],
                            base_url=platform_info["base_url"]
                        )
                        logger.info(f"Connected to Alpaca API")
                    
                    elif platform_id == "binance" and platform_info["api_key"] and platform_info["api_secret"]:
                        from binance.client import Client
                        platform_info["client"] = Client(
                            platform_info["api_key"],
                            platform_info["api_secret"],
                            testnet=platform_info["paper_trading"]
                        )
                        logger.info(f"Connected to Binance API")
                    
                    elif platform_id == "simulated":
                        platform_info["client"] = SimulatedTradingClient()
                        logger.info(f"Initialized simulated trading client")
                
                except Exception as e:
                    logger.error(f"Error connecting to {platform_info['name']}: {str(e)}")
                    platform_info["enabled"] = False
        
        return trading_platforms
    
    def _initialize_portfolio(self) -> Dict[str, Any]:
        """Initialize portfolio structure."""
        return {
            "cash": 10000.0,  # Default starting cash
            "assets": [],
            "total_value": 10000.0,
            "last_updated": datetime.datetime.now().isoformat()
        }
    
    def get_portfolio(self) -> Dict[str, Any]:
        """
        Get the current portfolio status.
        
        Returns:
            Dictionary with portfolio information
        """
        try:
            # Update portfolio with latest market data
            self._update_portfolio()
            
            # Calculate total value
            total_value = self.portfolio["cash"]
            for asset in self.portfolio["assets"]:
                total_value += asset["current_value"]
            
            self.portfolio["total_value"] = total_value
            self.portfolio["last_updated"] = datetime.datetime.now().isoformat()
            
            return self.portfolio
        
        except Exception as e:
            logger.error(f"Error getting portfolio: {str(e)}")
            return {"error": str(e)}
    
    def _update_portfolio(self):
        """Update portfolio with latest market data."""
        try:
            # Update each asset with current market price
            for asset in self.portfolio["assets"]:
                market_id = asset["market_id"]
                
                # Get latest price
                if self.analysis_engine:
                    # Use analysis engine to get latest price
                    data = self.analysis_engine.get_market_data(market_id, "1d", 1)
                    if not data.empty and "close" in data:
                        current_price = float(data["close"].iloc[-1])
                    else:
                        logger.warning(f"Could not get latest price for {market_id}")
                        continue
                else:
                    # Use a placeholder price (in a real implementation, we would fetch the price)
                    current_price = asset["purchase_price"] * (1 + np.random.normal(0, 0.01))
                
                # Update asset information
                asset["current_price"] = current_price
                asset["current_value"] = current_price * asset["quantity"]
                asset["profit_loss"] = asset["current_value"] - asset["purchase_value"]
                asset["profit_loss_percent"] = (asset["current_price"] / asset["purchase_price"] - 1) * 100
            
            logger.debug("Portfolio updated with latest market data")
        
        except Exception as e:
            logger.error(f"Error updating portfolio: {str(e)}")
    
    def execute_trade(self, trade_params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a trade.
        
        Args:
            trade_params: Parameters for the trade
            
        Returns:
            Dictionary with trade results
        """
        trade_id = generate_id()
        trade_type = trade_params.get("type", "unknown")
        market_id = trade_params.get("market_id")
        platform_id = trade_params.get("platform_id", "simulated")
        quantity = trade_params.get("quantity")
        price = trade_params.get("price")
        
        logger.info(f"Executing {trade_type} trade for {market_id} on {platform_id}")
        
        try:
            # Validate trade parameters
            if not market_id:
                return {"error": "Market ID not provided"}
            
            if not quantity:
                return {"error": "Quantity not provided"}
            
            if platform_id not in self.trading_platforms:
                return {"error": f"Unknown trading platform: {platform_id}"}
            
            if not self.trading_platforms[platform_id]["enabled"]:
                return {"error": f"Trading platform {platform_id} is not enabled"}
            
            # Get platform client
            platform = self.trading_platforms[platform_id]
            client = platform.get("client")
            
            if not client:
                return {"error": f"No client available for platform {platform_id}"}
            
            # Execute the trade based on platform type
            if platform_id == "alpaca":
                result = self._execute_alpaca_trade(client, trade_params)
            elif platform_id == "binance":
                result = self._execute_binance_trade(client, trade_params)
            elif platform_id == "simulated":
                result = self._execute_simulated_trade(client, trade_params)
            else:
                return {"error": f"Unsupported trading platform: {platform_id}"}
            
            # If trade was successful, update portfolio
            if result.get("success"):
                self._update_portfolio_after_trade(trade_params, result)
                
                # Update performance metrics
                self.performance_metrics["trades_executed"] += 1
                
                # Save trade to history
                trade_record = {
                    "id": trade_id,
                    "type": trade_type,
                    "market_id": market_id,
                    "platform_id": platform_id,
                    "quantity": quantity,
                    "price": result.get("price"),
                    "value": result.get("value"),
                    "timestamp": datetime.datetime.now().isoformat(),
                    "status": "completed",
                    "details": result
                }
                
                self.trade_history.append(trade_record)
                
                # Save to database if available
                if self.database:
                    self.database.save_execution(
                        "trading_engine",
                        trade_id,
                        trade_record
                    )
                
                logger.info(f"Trade {trade_id} executed successfully")
                
                return {
                    "trade_id": trade_id,
                    "success": True,
                    "market_id": market_id,
                    "type": trade_type,
                    "quantity": quantity,
                    "price": result.get("price"),
                    "value": result.get("value"),
                    "timestamp": datetime.datetime.now().isoformat()
                }
            
            else:
                logger.error(f"Trade execution failed: {result.get('error')}")
                return {
                    "trade_id": trade_id,
                    "success": False,
                    "error": result.get("error")
                }
        
        except Exception as e:
            logger.error(f"Error executing trade: {str(e)}")
            return {
                "trade_id": trade_id,
                "success": False,
                "error": str(e)
            }
    
    def _execute_alpaca_trade(self, client: Any, trade_params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a trade on Alpaca.
        
        Args:
            client: Alpaca API client
            trade_params: Parameters for the trade
            
        Returns:
            Dictionary with trade results
        """
        try:
            trade_type = trade_params.get("type")
            market_id = trade_params.get("market_id")
            quantity = trade_params.get("quantity")
            price = trade_params.get("price")
            order_type = trade_params.get("order_type", "market")
            time_in_force = trade_params.get("time_in_force", "day")
            
            # Convert trade type to Alpaca side
            side = "buy" if trade_type == "buy" else "sell"
            
            # Submit order
            if order_type == "market":
                order = client.submit_order(
                    symbol=market_id,
                    qty=quantity,
                    side=side,
                    type="market",
                    time_in_force=time_in_force
                )
            elif order_type == "limit":
                order = client.submit_order(
                    symbol=market_id,
                    qty=quantity,
                    side=side,
                    type="limit",
                    limit_price=price,
                    time_in_force=time_in_force
                )
            else:
                return {"error": f"Unsupported order type: {order_type}"}
            
            # Wait for order to fill
            filled_order = self._wait_for_alpaca_order(client, order.id)
            
            if filled_order.status == "filled":
                return {
                    "success": True,
                    "order_id": filled_order.id,
                    "price": float(filled_order.filled_avg_price),
                    "quantity": float(filled_order.filled_qty),
                    "value": float(filled_order.filled_avg_price) * float(filled_order.filled_qty)
                }
            else:
                return {
                    "success": False,
                    "error": f"Order not filled: {filled_order.status}"
                }
        
        except Exception as e:
            logger.error(f"Error executing Alpaca trade: {str(e)}")
            return {"error": str(e)}
    
    def _wait_for_alpaca_order(self, client: Any, order_id: str, timeout: int = 60) -> Any:
        """
        Wait for an Alpaca order to fill.
        
        Args:
            client: Alpaca API client
            order_id: ID of the order to wait for
            timeout: Timeout in seconds
            
        Returns:
            Filled order object
        """
        start_time = time.time()
        while time.time() - start_time < timeout:
            order = client.get_order(order_id)
            if order.status in ["filled", "canceled", "rejected"]:
                return order
            time.sleep(1)
        
        # If we reach here, the order didn't fill within the timeout
        return client.get_order(order_id)
    
    def _execute_binance_trade(self, client: Any, trade_params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a trade on Binance.
        
        Args:
            client: Binance API client
            trade_params: Parameters for the trade
            
        Returns:
            Dictionary with trade results
        """
        try:
            trade_type = trade_params.get("type")
            market_id = trade_params.get("market_id")
            quantity = trade_params.get("quantity")
            price = trade_params.get("price")
            order_type = trade_params.get("order_type", "market")
            
            # Convert trade type to Binance side
            side = "BUY" if trade_type == "buy" else "SELL"
            
            # Submit order
            if order_type == "market":
                order = client.create_order(
                    symbol=market_id,
                    side=side,
                    type="MARKET",
                    quantity=quantity
                )
            elif order_type == "limit":
                order = client.create_order(
                    symbol=market_id,
                    side=side,
                    type="LIMIT",
                    timeInForce="GTC",
                    quantity=quantity,
                    price=price
                )
            else:
                return {"error": f"Unsupported order type: {order_type}"}
            
            # Check if order was filled
            if order["status"] == "FILLED":
                # Calculate average fill price
                fills = order.get("fills", [])
                if fills:
                    total_cost = sum(float(fill["price"]) * float(fill["qty"]) for fill in fills)
                    total_qty = sum(float(fill["qty"]) for fill in fills)
                    avg_price = total_cost / total_qty if total_qty > 0 else 0
                else:
                    avg_price = float(order.get("price", 0))
                
                return {
                    "success": True,
                    "order_id": order["orderId"],
                    "price": avg_price,
                    "quantity": float(order["executedQty"]),
                    "value": avg_price * float(order["executedQty"])
                }
            else:
                return {
                    "success": False,
                    "error": f"Order not filled: {order['status']}"
                }
        
        except Exception as e:
            logger.error(f"Error executing Binance trade: {str(e)}")
            return {"error": str(e)}
    
    def _execute_simulated_trade(self, client: Any, trade_params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a simulated trade.
        
        Args:
            client: Simulated trading client
            trade_params: Parameters for the trade
            
        Returns:
            Dictionary with trade results
        """
        try:
            trade_type = trade_params.get("type")
            market_id = trade_params.get("market_id")
            quantity = float(trade_params.get("quantity"))
            price = trade_params.get("price")
            
            # If price is not provided, get current market price
            if not price and self.analysis_engine:
                data = self.analysis_engine.get_market_data(market_id, "1d", 1)
                if not data.empty and "close" in data:
                    price = float(data["close"].iloc[-1])
                else:
                    # Use a placeholder price
                    price = 100.0
            elif not price:
                # Use a placeholder price
                price = 100.0
            else:
                price = float(price)
            
            # Add some simulated slippage
            slippage = price * np.random.uniform(-0.005, 0.005)
            executed_price = price + slippage
            
            # Calculate trade value
            value = executed_price * quantity
            
            # Check if we have enough cash for a buy
            if trade_type == "buy" and value > self.portfolio["cash"]:
                return {
                    "success": False,
                    "error": "Insufficient funds"
                }
            
            # Check if we have enough of the asset for a sell
            if trade_type == "sell":
                asset_found = False
                for asset in self.portfolio["assets"]:
                    if asset["market_id"] == market_id:
                        if asset["quantity"] < quantity:
                            return {
                                "success": False,
                                "error": "Insufficient assets"
                            }
                        asset_found = True
                        break
                
                if not asset_found:
                    return {
                        "success": False,
                        "error": f"Asset {market_id} not found in portfolio"
                    }
            
            # Simulate order execution
            order_id = str(uuid.uuid4())
            
            return {
                "success": True,
                "order_id": order_id,
                "price": executed_price,
                "quantity": quantity,
                "value": value
            }
        
        except Exception as e:
            logger.error(f"Error executing simulated trade: {str(e)}")
            return {"error": str(e)}
    
    def _update_portfolio_after_trade(self, trade_params: Dict[str, Any], trade_result: Dict[str, Any]):
        """
        Update portfolio after a successful trade.
        
        Args:
            trade_params: Parameters of the trade
            trade_result: Results of the trade
        """
        try:
            trade_type = trade_params.get("type")
            market_id = trade_params.get("market_id")
            quantity = float(trade_result.get("quantity"))
            price = float(trade_result.get("price"))
            value = float(trade_result.get("value"))
            
            if trade_type == "buy":
                # Deduct cash
                self.portfolio["cash"] -= value
                
                # Add or update asset
                asset_found = False
                for asset in self.portfolio["assets"]:
                    if asset["market_id"] == market_id:
                        # Update existing asset
                        total_value = asset["purchase_value"] + value
                        total_quantity = asset["quantity"] + quantity
                        asset["purchase_price"] = total_value / total_quantity
                        asset["purchase_value"] = total_value
                        asset["quantity"] = total_quantity
                        asset["current_price"] = price
                        asset["current_value"] = price * total_quantity
                        asset["profit_loss"] = asset["current_value"] - asset["purchase_value"]
                        asset["profit_loss_percent"] = (asset["current_price"] / asset["purchase_price"] - 1) * 100
                        asset_found = True
                        break
                
                if not asset_found:
                    # Add new asset
                    self.portfolio["assets"].append({
                        "market_id": market_id,
                        "quantity": quantity,
                        "purchase_price": price,
                        "purchase_value": value,
                        "current_price": price,
                        "current_value": value,
                        "profit_loss": 0.0,
                        "profit_loss_percent": 0.0,
                        "last_updated": datetime.datetime.now().isoformat()
                    })
            
            elif trade_type == "sell":
                # Add cash
                self.portfolio["cash"] += value
                
                # Update asset
                for i, asset in enumerate(self.portfolio["assets"]):
                    if asset["market_id"] == market_id:
                        # Update quantity
                        asset["quantity"] -= quantity
                        
                        # If quantity is zero, remove the asset
                        if asset["quantity"] <= 0:
                            self.portfolio["assets"].pop(i)
                        else:
                            # Update values
                            asset["current_price"] = price
                            asset["current_value"] = price * asset["quantity"]
                            asset["profit_loss"] = asset["current_value"] - (asset["purchase_price"] * asset["quantity"])
                            asset["profit_loss_percent"] = (asset["current_price"] / asset["purchase_price"] - 1) * 100
                        
                        break
            
            # Update total value
            total_value = self.portfolio["cash"]
            for asset in self.portfolio["assets"]:
                total_value += asset["current_value"]
            
            self.portfolio["total_value"] = total_value
            self.portfolio["last_updated"] = datetime.datetime.now().isoformat()
            
            logger.debug(f"Portfolio updated after {trade_type} trade for {market_id}")
        
        except Exception as e:
            logger.error(f"Error updating portfolio after trade: {str(e)}")
    
    def create_strategy(self, strategy_config: Dict[str, Any]) -> Any:
        """
        Create a new trading strategy.
        
        Args:
            strategy_config: Configuration for the strategy
            
        Returns:
            Strategy object
        """
        strategy_id = generate_id()
        strategy_type = strategy_config.get("type", "unknown")
        
        logger.info(f"Creating trading strategy {strategy_id} of type {strategy_type}")
        
        try:
            if strategy_type == "trend_following":
                strategy = TrendFollowingStrategy(strategy_config, self.analysis_engine)
            elif strategy_type == "mean_reversion":
                strategy = MeanReversionStrategy(strategy_config, self.analysis_engine)
            elif strategy_type == "breakout":
                strategy = BreakoutStrategy(strategy_config, self.analysis_engine)
            elif strategy_type == "multi_factor":
                strategy = MultiFactorStrategy(strategy_config, self.analysis_engine)
            elif strategy_type == "custom":
                strategy = CustomStrategy(strategy_config, self.analysis_engine)
            else:
                logger.error(f"Unknown strategy type: {strategy_type}")
                return None
            
            # Store the strategy
            self.strategies[strategy_id] = {
                "id": strategy_id,
                "type": strategy_type,
                "config": strategy_config,
                "created_at": datetime.datetime.now().isoformat(),
                "strategy": strategy
            }
            
            logger.info(f"Created trading strategy {strategy_id}")
            return strategy
        
        except Exception as e:
            logger.error(f"Error creating trading strategy: {str(e)}")
            return None
    
    def execute_strategy(self, strategy: Any, parameters: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Execute a trading strategy.
        
        Args:
            strategy: Strategy object to execute
            parameters: Additional parameters for execution
            
        Returns:
            Dictionary with execution results
        """
        if parameters is None:
            parameters = {}
        
        try:
            # Get strategy signals
            signals = strategy.generate_signals(parameters)
            
            # Execute trades based on signals
            trades = []
            for signal in signals:
                trade_params = {
                    "type": signal["action"],
                    "market_id": signal["market_id"],
                    "quantity": signal["quantity"],
                    "platform_id": parameters.get("platform_id", "simulated"),
                    "order_type": signal.get("order_type", "market"),
                    "price": signal.get("price")
                }
                
                trade_result = self.execute_trade(trade_params)
                trades.append(trade_result)
            
            return {
                "strategy_id": strategy.id if hasattr(strategy, "id") else None,
                "signals": signals,
                "trades": trades,
                "timestamp": datetime.datetime.now().isoformat()
            }
        
        except Exception as e:
            logger.error(f"Error executing trading strategy: {str(e)}")
            return {"error": str(e)}
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """
        Get performance metrics for the trading engine.
        
        Returns:
            Dictionary with performance metrics
        """
        try:
            # Update win rate
            if self.performance_metrics["trades_executed"] > 0:
                self.performance_metrics["win_rate"] = (
                    self.performance_metrics["successful_trades"] / 
                    self.performance_metrics["trades_executed"]
                )
            
            # Get portfolio performance
            portfolio = self.get_portfolio()
            initial_value = 10000.0  # Default starting value
            current_value = portfolio.get("total_value", initial_value)
            
            # Calculate returns
            total_return = (current_value / initial_value - 1) * 100
            
            # Add to metrics
            metrics = {
                **self.performance_metrics,
                "portfolio_value": current_value,
                "total_return": total_return
            }
            
            return metrics
        
        except Exception as e:
            logger.error(f"Error getting performance metrics: {str(e)}")
            return {"error": str(e)}
    
    def shutdown(self):
        """Shutdown the trading engine and close connections."""
        logger.info("Shutting down trading engine")
        
        # Close connections to trading platforms
        for platform_id, platform_info in self.trading_platforms.items():
            if platform_info.get("client"):
                try:
                    # Some clients might have a close method
                    if hasattr(platform_info["client"], "close"):
                        platform_info["client"].close()
                except:
                    pass
        
        logger.info("Trading engine shutdown complete")


class TradingStrategy:
    """Base class for trading strategies."""
    
    def __init__(self, config: Dict[str, Any], analysis_engine: AnalysisEngine = None):
        """
        Initialize the strategy.
        
        Args:
            config: Strategy configuration
            analysis_engine: Analysis engine for market data
        """
        self.config = config
        self.analysis_engine = analysis_engine
        self.id = generate_id()
        self.name = config.get("name", "Unnamed Strategy")
        self.description = config.get("description", "")
        self.risk_tolerance = config.get("risk_tolerance", config.RISK_TOLERANCE if hasattr(config, 'RISK_TOLERANCE') else 0.02)
        self.max_position_size = config.get("max_position_size", config.MAX_POSITION_SIZE if hasattr(config, 'MAX_POSITION_SIZE') else 0.1)
    
    def generate_signals(self, parameters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """
        Generate trading signals.
        
        Args:
            parameters: Additional parameters
            
        Returns:
            List of trading signals
        """
        raise NotImplementedError("Subclasses must implement generate_signals method")
    
    def calculate_position_size(self, market_id: str, price: float, portfolio_value: float) -> float:
        """
        Calculate position size based on risk management rules.
        
        Args:
            market_id: Market identifier
            price: Current price
            portfolio_value: Total portfolio value
            
        Returns:
            Quantity to trade
        """
        # Get risk per trade
        risk_per_trade = portfolio_value * self.risk_tolerance
        
        # Get stop loss percentage
        stop_loss_percent = self.config.get("stop_loss_percent", 0.05)
        
        # Calculate maximum quantity based on risk
        max_quantity = risk_per_trade / (price * stop_loss_percent)
        
        # Limit by maximum position size
        max_position_value = portfolio_value * self.max_position_size
        max_quantity_by_position = max_position_value / price
        
        # Take the smaller of the two
        quantity = min(max_quantity, max_quantity_by_position)
        
        # Round to appropriate precision
        if market_id.endswith("USD") or market_id.endswith("USDT"):
            # For crypto, use more decimal places
            quantity = round(quantity, 6)
        else:
            # For stocks, round to whole shares
            quantity = int(quantity)
        
        return quantity


class TrendFollowingStrategy(TradingStrategy):
    """Strategy that follows market trends."""
    
    def generate_signals(self, parameters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """
        Generate trading signals based on trend following.
        
        Args:
            parameters: Additional parameters
            
        Returns:
            List of trading signals
        """
        if parameters is None:
            parameters = {}
        
        signals = []
        
        # Get market data
        market_id = parameters.get("market_id")
        if not market_id:
            return signals
        
        # Get portfolio value
        portfolio_value = parameters.get("portfolio_value", 10000.0)
        
        # Get market data
        if self.analysis_engine:
            data = self.analysis_engine.get_market_data(
                market_id,
                parameters.get("timeframe", "1d"),
                parameters.get("limit", 50)
            )
            
            if data.empty:
                return signals
            
            # Calculate moving averages
            fast_ma_window = self.config.get("fast_ma_window", 10)
            slow_ma_window = self.config.get("slow_ma_window", 30)
            
            fast_ma = data["close"].rolling(window=fast_ma_window).mean()
            slow_ma = data["close"].rolling(window=slow_ma_window).mean()
            
            # Check for crossover
            if len(fast_ma) > 1 and len(slow_ma) > 1:
                # Current values
                current_fast = fast_ma.iloc[-1]
                current_slow = slow_ma.iloc[-1]
                
                # Previous values
                prev_fast = fast_ma.iloc[-2]
                prev_slow = slow_ma.iloc[-2]
                
                # Current price
                current_price = data["close"].iloc[-1]
                
                # Check for buy signal (fast MA crosses above slow MA)
                if prev_fast <= prev_slow and current_fast > current_slow:
                    # Calculate position size
                    quantity = self.calculate_position_size(market_id, current_price, portfolio_value)
                    
                    signals.append({
                        "market_id": market_id,
                        "action": "buy",
                        "price": current_price,
                        "quantity": quantity,
                        "reason": "MA crossover (bullish)",
                        "confidence": 0.7
                    })
                
                # Check for sell signal (fast MA crosses below slow MA)
                elif prev_fast >= prev_slow and current_fast < current_slow:
                    # For sell signals, we would typically sell all holdings
                    # In a real implementation, we would check the current portfolio
                    
                    signals.append({
                        "market_id": market_id,
                        "action": "sell",
                        "price": current_price,
                        "quantity": parameters.get("current_quantity", 1.0),
                        "reason": "MA crossover (bearish)",
                        "confidence": 0.7
                    })
        
        return signals


class MeanReversionStrategy(TradingStrategy):
    """Strategy that trades mean reversion."""
    
    def generate_signals(self, parameters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """
        Generate trading signals based on mean reversion.
        
        Args:
            parameters: Additional parameters
            
        Returns:
            List of trading signals
        """
        if parameters is None:
            parameters = {}
        
        signals = []
        
        # Get market data
        market_id = parameters.get("market_id")
        if not market_id:
            return signals
        
        # Get portfolio value
        portfolio_value = parameters.get("portfolio_value", 10000.0)
        
        # Get market data
        if self.analysis_engine:
            data = self.analysis_engine.get_market_data(
                market_id,
                parameters.get("timeframe", "1d"),
                parameters.get("limit", 50)
            )
            
            if data.empty:
                return signals
            
            # Calculate Bollinger Bands
            window = self.config.get("window", 20)
            num_std = self.config.get("num_std", 2)
            
            ma = data["close"].rolling(window=window).mean()
            std = data["close"].rolling(window=window).std()
            upper_band = ma + (std * num_std)
            lower_band = ma - (std * num_std)
            
            # Current price
            current_price = data["close"].iloc[-1]
            
            # Check for buy signal (price below lower band)
            if current_price < lower_band.iloc[-1]:
                # Calculate position size
                quantity = self.calculate_position_size(market_id, current_price, portfolio_value)
                
                signals.append({
                    "market_id": market_id,
                    "action": "buy",
                    "price": current_price,
                    "quantity": quantity,
                    "reason": "Price below lower Bollinger Band",
                    "confidence": 0.6
                })
            
            # Check for sell signal (price above upper band)
            elif current_price > upper_band.iloc[-1]:
                # For sell signals, we would typically sell all holdings
                # In a real implementation, we would check the current portfolio
                
                signals.append({
                    "market_id": market_id,
                    "action": "sell",
                    "price": current_price,
                    "quantity": parameters.get("current_quantity", 1.0),
                    "reason": "Price above upper Bollinger Band",
                    "confidence": 0.6
                })
        
        return signals


class BreakoutStrategy(TradingStrategy):
    """Strategy that trades breakouts."""
    
    def generate_signals(self, parameters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """
        Generate trading signals based on breakouts.
        
        Args:
            parameters: Additional parameters
            
        Returns:
            List of trading signals
        """
        if parameters is None:
            parameters = {}
        
        signals = []
        
        # Get market data
        market_id = parameters.get("market_id")
        if not market_id:
            return signals
        
        # Get portfolio value
        portfolio_value = parameters.get("portfolio_value", 10000.0)
        
        # Get market data
        if self.analysis_engine:
            data = self.analysis_engine.get_market_data(
                market_id,
                parameters.get("timeframe", "1d"),
                parameters.get("limit", 50)
            )
            
            if data.empty:
                return signals
            
            # Calculate recent high and low
            window = self.config.get("window", 20)
            high_max = data["high"].rolling(window=window).max()
            low_min = data["low"].rolling(window=window).min()
            
            # Current price
            current_price = data["close"].iloc[-1]
            
            # Check for buy signal (price breaks above recent high)
            if current_price > high_max.iloc[-2]:
                # Calculate position size
                quantity = self.calculate_position_size(market_id, current_price, portfolio_value)
                
                signals.append({
                    "market_id": market_id,
                    "action": "buy",
                    "price": current_price,
                    "quantity": quantity,
                    "reason": "Breakout above recent high",
                    "confidence": 0.65
                })
            
            # Check for sell signal (price breaks below recent low)
            elif current_price < low_min.iloc[-2]:
                # For sell signals, we would typically sell all holdings
                # In a real implementation, we would check the current portfolio
                
                signals.append({
                    "market_id": market_id,
                    "action": "sell",
                    "price": current_price,
                    "quantity": parameters.get("current_quantity", 1.0),
                    "reason": "Breakdown below recent low",
                    "confidence": 0.65
                })
        
        return signals


class MultiFactorStrategy(TradingStrategy):
    """Strategy that combines multiple factors."""
    
    def generate_signals(self, parameters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """
        Generate trading signals based on multiple factors.
        
        Args:
            parameters: Additional parameters
            
        Returns:
            List of trading signals
        """
        if parameters is None:
            parameters = {}
        
        signals = []
        
        # Get market data
        market_id = parameters.get("market_id")
        if not market_id:
            return signals
        
        # Get portfolio value
        portfolio_value = parameters.get("portfolio_value", 10000.0)
        
        # Get market data
        if self.analysis_engine:
            data = self.analysis_engine.get_market_data(
                market_id,
                parameters.get("timeframe", "1d"),
                parameters.get("limit", 50)
            )
            
            if data.empty:
                return signals
            
            # Calculate indicators
            # Moving average
            ma_window = self.config.get("ma_window", 20)
            ma = data["close"].rolling(window=ma_window).mean()
            
            # RSI
            rsi_window = self.config.get("rsi_window", 14)
            delta = data["close"].diff()
            gain = delta.where(delta > 0, 0)
            loss = -delta.where(delta < 0, 0)
            avg_gain = gain.rolling(window=rsi_window).mean()
            avg_loss = loss.rolling(window=rsi_window).mean()
            rs = avg_gain / avg_loss
            rsi = 100 - (100 / (1 + rs))
            
            # Current price
            current_price = data["close"].iloc[-1]
            
            # Calculate scores for each factor
            trend_score = 1 if current_price > ma.iloc[-1] else -1
            momentum_score = 1 if rsi.iloc[-1] < 30 else (-1 if rsi.iloc[-1] > 70 else 0)
            
            # Combine scores
            total_score = trend_score + momentum_score
            
            # Generate signals based on combined score
            if total_score >= 1:
                # Calculate position size
                quantity = self.calculate_position_size(market_id, current_price, portfolio_value)
                
                signals.append({
                    "market_id": market_id,
                    "action": "buy",
                    "price": current_price,
                    "quantity": quantity,
                    "reason": "Positive multi-factor score",
                    "confidence": 0.6 + (total_score * 0.1)
                })
            
            elif total_score <= -1:
                # For sell signals, we would typically sell all holdings
                # In a real implementation, we would check the current portfolio
                
                signals.append({
                    "market_id": market_id,
                    "action": "sell",
                    "price": current_price,
                    "quantity": parameters.get("current_quantity", 1.0),
                    "reason": "Negative multi-factor score",
                    "confidence": 0.6 + (abs(total_score) * 0.1)
                })
        
        return signals


class CustomStrategy(TradingStrategy):
    """Custom strategy that can be defined with flexible rules."""
    
    def generate_signals(self, parameters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """
        Generate trading signals based on custom rules.
        
        Args:
            parameters: Additional parameters
            
        Returns:
            List of trading signals
        """
        if parameters is None:
            parameters = {}
        
        signals = []
        
        # Get market data
        market_id = parameters.get("market_id")
        if not market_id:
            return signals
        
        # Get portfolio value
        portfolio_value = parameters.get("portfolio_value", 10000.0)
        
        # Get custom rules
        rules = self.config.get("rules", [])
        
        # Get market data
        if self.analysis_engine and rules:
            data = self.analysis_engine.get_market_data(
                market_id,
                parameters.get("timeframe", "1d"),
                parameters.get("limit", 100)
            )
            
            if data.empty:
                return signals
            
            # Current price
            current_price = data["close"].iloc[-1]
            
            # Evaluate each rule
            for rule in rules:
                rule_type = rule.get("type")
                
                if rule_type == "indicator":
                    # Get indicator values
                    indicator = rule.get("indicator")
                    condition = rule.get("condition")
                    threshold = rule.get("threshold")
                    
                    # Calculate indicator
                    indicator_value = None
                    
                    if indicator == "rsi":
                        window = rule.get("window", 14)
                        delta = data["close"].diff()
                        gain = delta.where(delta > 0, 0)
                        loss = -delta.where(delta < 0, 0)
                        avg_gain = gain.rolling(window=window).mean()
                        avg_loss = loss.rolling(window=window).mean()
                        rs = avg_gain / avg_loss
                        rsi_values = 100 - (100 / (1 + rs))
                        indicator_value = rsi_values.iloc[-1]
                    
                    elif indicator == "ma_crossover":
                        fast_window = rule.get("fast_window", 10)
                        slow_window = rule.get("slow_window", 30)
                        
                        fast_ma = data["close"].rolling(window=fast_window).mean()
                        slow_ma = data["close"].rolling(window=slow_window).mean()
                        
                        # Check for crossover
                        if len(fast_ma) > 1 and len(slow_ma) > 1:
                            current_fast = fast_ma.iloc[-1]
                            current_slow = slow_ma.iloc[-1]
                            prev_fast = fast_ma.iloc[-2]
                            prev_slow = slow_ma.iloc[-2]
                            
                            if condition == "crosses_above":
                                indicator_value = 1 if (prev_fast <= prev_slow and current_fast > current_slow) else 0
                            elif condition == "crosses_below":
                                indicator_value = 1 if (prev_fast >= prev_slow and current_fast < current_slow) else 0
                            else:
                                indicator_value = current_fast - current_slow
                    
                    # Check condition
                    if indicator_value is not None:
                        signal_generated = False
                        
                        if condition == "above" and indicator_value > threshold:
                            signal_generated = True
                        elif condition == "below" and indicator_value < threshold:
                            signal_generated = True
                        elif condition == "crosses_above" and indicator_value == 1:
                            signal_generated = True
                        elif condition == "crosses_below" and indicator_value == 1:
                            signal_generated = True
                        
                        if signal_generated:
                            action = rule.get("action", "buy")
                            
                            if action == "buy":
                                # Calculate position size
                                quantity = self.calculate_position_size(market_id, current_price, portfolio_value)
                                
                                signals.append({
                                    "market_id": market_id,
                                    "action": "buy",
                                    "price": current_price,
                                    "quantity": quantity,
                                    "reason": f"{indicator} {condition} {threshold}",
                                    "confidence": rule.get("confidence", 0.6)
                                })
                            
                            elif action == "sell":
                                signals.append({
                                    "market_id": market_id,
                                    "action": "sell",
                                    "price": current_price,
                                    "quantity": parameters.get("current_quantity", 1.0),
                                    "reason": f"{indicator} {condition} {threshold}",
                                    "confidence": rule.get("confidence", 0.6)
                                })
        
        return signals


class SimulatedTradingClient:
    """Client for simulated trading."""
    
    def __init__(self):
        """Initialize the simulated trading client."""
        self.orders = {}
    
    def create_order(self, **kwargs):
        """
        Create a simulated order.
        
        Args:
            **kwargs: Order parameters
            
        Returns:
            Simulated order object
        """
        order_id = str(uuid.uuid4())
        
        order = {
            "id": order_id,
            "status": "filled",
            **kwargs
        }
        
        self.orders[order_id] = order
        return order
    
    def get_order(self, order_id):
        """
        Get a simulated order.
        
        Args:
            order_id: ID of the order
            
        Returns:
            Simulated order object
        """
        return self.orders.get(order_id)
