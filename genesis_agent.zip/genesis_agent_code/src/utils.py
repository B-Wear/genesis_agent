"""
Genesis Agent Utilities Module
----------------------------
This module contains utility functions used throughout the Genesis Agent system.
"""

import os
import uuid
import hashlib
import base64
import json
import logging
import datetime
from typing import Dict, List, Any, Optional, Union

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from . import config

# Configure logging
logger = logging.getLogger('genesis_agent.utils')

def generate_id() -> str:
    """
    Generate a unique identifier.
    
    Returns:
        Unique string identifier
    """
    return str(uuid.uuid4())

def generate_encryption_key(password: str, salt: bytes = None) -> bytes:
    """
    Generate an encryption key from a password.
    
    Args:
        password: Password to derive key from
        salt: Optional salt for key derivation
        
    Returns:
        Encryption key as bytes
    """
    if salt is None:
        salt = config.PASSWORD_SALT.encode() if hasattr(config, 'PASSWORD_SALT') else b'genesis-agent-salt'
    
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
    )
    
    key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
    return key

def encrypt_data(data: Any, key: bytes = None) -> str:
    """
    Encrypt data using Fernet symmetric encryption.
    
    Args:
        data: Data to encrypt (will be converted to JSON)
        key: Encryption key (if None, uses config.ENCRYPTION_KEY)
        
    Returns:
        Encrypted data as a base64 string
    """
    if key is None:
        if hasattr(config, 'ENCRYPTION_KEY'):
            key = generate_encryption_key(config.ENCRYPTION_KEY)
        else:
            key = generate_encryption_key('default-key')
    
    try:
        f = Fernet(key)
        data_json = json.dumps(data).encode()
        encrypted_data = f.encrypt(data_json)
        return base64.urlsafe_b64encode(encrypted_data).decode()
    except Exception as e:
        logger.error(f"Encryption error: {str(e)}")
        return None

def decrypt_data(encrypted_data: str, key: bytes = None) -> Any:
    """
    Decrypt data using Fernet symmetric encryption.
    
    Args:
        encrypted_data: Encrypted data as a base64 string
        key: Encryption key (if None, uses config.ENCRYPTION_KEY)
        
    Returns:
        Decrypted data (parsed from JSON)
    """
    if key is None:
        if hasattr(config, 'ENCRYPTION_KEY'):
            key = generate_encryption_key(config.ENCRYPTION_KEY)
        else:
            key = generate_encryption_key('default-key')
    
    try:
        f = Fernet(key)
        encrypted_bytes = base64.urlsafe_b64decode(encrypted_data)
        decrypted_data = f.decrypt(encrypted_bytes)
        return json.loads(decrypted_data.decode())
    except Exception as e:
        logger.error(f"Decryption error: {str(e)}")
        return None

def hash_password(password: str, salt: str = None) -> str:
    """
    Hash a password using a secure algorithm.
    
    Args:
        password: Password to hash
        salt: Optional salt for hashing
        
    Returns:
        Hashed password as a string
    """
    if salt is None:
        salt = config.PASSWORD_SALT if hasattr(config, 'PASSWORD_SALT') else 'genesis-agent-salt'
    
    algorithm = config.HASH_ALGORITHM if hasattr(config, 'HASH_ALGORITHM') else 'sha256'
    
    hash_obj = hashlib.new(algorithm)
    hash_obj.update((password + salt).encode())
    return hash_obj.hexdigest()

def verify_password(password: str, password_hash: str, salt: str = None) -> bool:
    """
    Verify a password against a hash.
    
    Args:
        password: Password to verify
        password_hash: Hash to verify against
        salt: Optional salt used for hashing
        
    Returns:
        True if password matches hash, False otherwise
    """
    return hash_password(password, salt) == password_hash

def format_currency(amount: float, currency: str = 'USD') -> str:
    """
    Format a currency amount.
    
    Args:
        amount: Amount to format
        currency: Currency code
        
    Returns:
        Formatted currency string
    """
    if currency == 'USD':
        return f"${amount:,.2f}"
    elif currency == 'EUR':
        return f"€{amount:,.2f}"
    elif currency == 'GBP':
        return f"£{amount:,.2f}"
    elif currency == 'JPY':
        return f"¥{amount:,.0f}"
    elif currency == 'BTC':
        return f"₿{amount:.8f}"
    elif currency == 'ETH':
        return f"Ξ{amount:.8f}"
    else:
        return f"{amount:,.2f} {currency}"

def parse_timeframe(timeframe: str) -> Dict[str, int]:
    """
    Parse a timeframe string into a dictionary.
    
    Args:
        timeframe: Timeframe string (e.g., "1m", "1h", "1d")
        
    Returns:
        Dictionary with unit and value
    """
    if not timeframe:
        return {"unit": "minute", "value": 1}
    
    try:
        value = int(timeframe[:-1])
        unit = timeframe[-1].lower()
        
        if unit == 'm':
            return {"unit": "minute", "value": value}
        elif unit == 'h':
            return {"unit": "hour", "value": value}
        elif unit == 'd':
            return {"unit": "day", "value": value}
        elif unit == 'w':
            return {"unit": "week", "value": value}
        else:
            logger.warning(f"Unknown timeframe unit: {unit}, defaulting to minutes")
            return {"unit": "minute", "value": value}
    except Exception as e:
        logger.error(f"Error parsing timeframe {timeframe}: {str(e)}")
        return {"unit": "minute", "value": 1}

def timeframe_to_seconds(timeframe: str) -> int:
    """
    Convert a timeframe string to seconds.
    
    Args:
        timeframe: Timeframe string (e.g., "1m", "1h", "1d")
        
    Returns:
        Number of seconds
    """
    parsed = parse_timeframe(timeframe)
    
    if parsed["unit"] == "minute":
        return parsed["value"] * 60
    elif parsed["unit"] == "hour":
        return parsed["value"] * 60 * 60
    elif parsed["unit"] == "day":
        return parsed["value"] * 60 * 60 * 24
    elif parsed["unit"] == "week":
        return parsed["value"] * 60 * 60 * 24 * 7
    else:
        return parsed["value"] * 60  # Default to minutes

def format_timestamp(timestamp: Union[str, datetime.datetime, float, int]) -> str:
    """
    Format a timestamp to ISO format.
    
    Args:
        timestamp: Timestamp to format (string, datetime, or numeric)
        
    Returns:
        ISO formatted timestamp string
    """
    if isinstance(timestamp, str):
        try:
            dt = datetime.datetime.fromisoformat(timestamp)
            return dt.isoformat()
        except ValueError:
            try:
                dt = datetime.datetime.fromtimestamp(float(timestamp))
                return dt.isoformat()
            except:
                logger.error(f"Could not parse timestamp string: {timestamp}")
                return datetime.datetime.now().isoformat()
    
    elif isinstance(timestamp, datetime.datetime):
        return timestamp.isoformat()
    
    elif isinstance(timestamp, (int, float)):
        return datetime.datetime.fromtimestamp(timestamp).isoformat()
    
    else:
        logger.error(f"Unknown timestamp format: {type(timestamp)}")
        return datetime.datetime.now().isoformat()

def safe_divide(numerator: float, denominator: float, default: float = 0.0) -> float:
    """
    Safely divide two numbers, returning a default value if denominator is zero.
    
    Args:
        numerator: Numerator value
        denominator: Denominator value
        default: Default value to return if denominator is zero
        
    Returns:
        Division result or default value
    """
    try:
        if denominator == 0:
            return default
        return numerator / denominator
    except:
        return default

def validate_email(email: str) -> bool:
    """
    Validate an email address format.
    
    Args:
        email: Email address to validate
        
    Returns:
        True if valid, False otherwise
    """
    import re
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))

def validate_password_strength(password: str) -> Dict[str, Any]:
    """
    Validate password strength.
    
    Args:
        password: Password to validate
        
    Returns:
        Dictionary with validation results
    """
    min_length = config.MIN_PASSWORD_LENGTH if hasattr(config, 'MIN_PASSWORD_LENGTH') else 8
    
    results = {
        "valid": True,
        "length": len(password) >= min_length,
        "uppercase": any(c.isupper() for c in password),
        "lowercase": any(c.islower() for c in password),
        "digit": any(c.isdigit() for c in password),
        "special": any(not c.isalnum() for c in password),
        "score": 0
    }
    
    # Calculate score (0-100)
    score = 0
    if results["length"]:
        score += 25
    if results["uppercase"]:
        score += 15
    if results["lowercase"]:
        score += 15
    if results["digit"]:
        score += 20
    if results["special"]:
        score += 25
    
    # Bonus for length beyond minimum
    if len(password) > min_length:
        score += min(len(password) - min_length, 10)
    
    # Cap at 100
    results["score"] = min(score, 100)
    
    # Overall validity
    results["valid"] = (
        results["length"] and
        results["uppercase"] and
        results["lowercase"] and
        results["digit"] and
        results["special"]
    )
    
    return results

def sanitize_input(input_str: str) -> str:
    """
    Sanitize input string to prevent injection attacks.
    
    Args:
        input_str: Input string to sanitize
        
    Returns:
        Sanitized string
    """
    if not input_str:
        return ""
    
    # Replace potentially dangerous characters
    replacements = {
        "<": "&lt;",
        ">": "&gt;",
        "&": "&amp;",
        '"': "&quot;",
        "'": "&#x27;",
        "/": "&#x2F;",
        "\\": "&#x5C;",
        "`": "&#96;"
    }
    
    for char, replacement in replacements.items():
        input_str = input_str.replace(char, replacement)
    
    return input_str

def get_system_info() -> Dict[str, Any]:
    """
    Get system information.
    
    Returns:
        Dictionary with system information
    """
    import platform
    import psutil
    
    try:
        # Basic system info
        info = {
            "platform": platform.system(),
            "platform_release": platform.release(),
            "platform_version": platform.version(),
            "architecture": platform.machine(),
            "processor": platform.processor(),
            "hostname": platform.node(),
            "python_version": platform.python_version(),
            "timestamp": datetime.datetime.now().isoformat()
        }
        
        # Memory information
        memory = psutil.virtual_memory()
        info["memory"] = {
            "total": memory.total / (1024 * 1024 * 1024),  # GB
            "available": memory.available / (1024 * 1024 * 1024),  # GB
            "percent_used": memory.percent
        }
        
        # Disk information
        disk = psutil.disk_usage('/')
        info["disk"] = {
            "total": disk.total / (1024 * 1024 * 1024),  # GB
            "used": disk.used / (1024 * 1024 * 1024),  # GB
            "free": disk.free / (1024 * 1024 * 1024),  # GB
            "percent_used": disk.percent
        }
        
        # CPU information
        info["cpu"] = {
            "physical_cores": psutil.cpu_count(logical=False),
            "total_cores": psutil.cpu_count(logical=True),
            "current_frequency": psutil.cpu_freq().current if psutil.cpu_freq() else None,
            "percent_used": psutil.cpu_percent(interval=0.1)
        }
        
        # Network information
        network_io = psutil.net_io_counters()
        info["network"] = {
            "bytes_sent": network_io.bytes_sent,
            "bytes_received": network_io.bytes_recv
        }
        
        return info
    
    except Exception as e:
        logger.error(f"Error getting system info: {str(e)}")
        return {"error": str(e)}
