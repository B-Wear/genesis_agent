"""
Genesis Agent Advanced Risk Management Module
----------------------------------------
This module provides advanced risk management capabilities for the Genesis Agent.
"""

import os
import logging
import datetime
import json
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Union
import time
from concurrent.futures import ThreadPoolExecutor
import scipy.stats as stats
import matplotlib.pyplot as plt
import seaborn as sns
from io import BytesIO

from . import config
from .utils import generate_id
from .security import SecurityManager, RiskManager

# Configure logging
logger = logging.getLogger('genesis_agent.advanced_risk')

class AdvancedRiskManager:
    """
    Advanced risk management system for the Genesis Agent.
    
    This class extends the basic risk management capabilities with sophisticated
    risk assessment, dynamic position sizing, and stress testing.
    """
    
    def __init__(self, security_manager: SecurityManager = None, 
                 risk_manager: RiskManager = None, database=None):
        """
        Initialize the advanced risk manager.
        
        Args:
            security_manager: Security manager instance
            risk_manager: Risk manager instance
            database: Database manager for storing risk data
        """
        self.security_manager = security_manager
        self.risk_manager = risk_manager
        self.database = database
        self.risk_models = self._initialize_risk_models()
        self.position_sizing_models = self._initialize_position_sizing_models()
        self.stress_test_scenarios = self._initialize_stress_test_scenarios()
        self.risk_limits = self._initialize_risk_limits()
        self.risk_events = []
        
        logger.info("Advanced risk manager initialized")
    
    def _initialize_risk_models(self) -> Dict[str, Any]:
        """Initialize advanced risk models."""
        return {
            "var": {
                "name": "Value at Risk",
                "description": "Estimates the maximum potential loss over a specific time period at a given confidence level",
                "methods": ["historical", "parametric", "monte_carlo"],
                "default_method": "historical",
                "confidence_levels": [0.95, 0.99],
                "default_confidence_level": 0.95,
                "time_horizons": [1, 5, 10, 20],  # days
                "default_time_horizon": 1
            },
            "cvar": {
                "name": "Conditional Value at Risk",
                "description": "Estimates the expected loss given that the loss exceeds the VaR threshold",
                "methods": ["historical", "parametric", "monte_carlo"],
                "default_method": "historical",
                "confidence_levels": [0.95, 0.99],
                "default_confidence_level": 0.95,
                "time_horizons": [1, 5, 10, 20],  # days
                "default_time_horizon": 1
            },
            "expected_shortfall": {
                "name": "Expected Shortfall",
                "description": "Average of all losses exceeding the VaR threshold",
                "methods": ["historical", "parametric", "monte_carlo"],
                "default_method": "historical",
                "confidence_levels": [0.95, 0.99],
                "default_confidence_level": 0.95,
                "time_horizons": [1, 5, 10, 20],  # days
                "default_time_horizon": 1
            },
            "stress_testing": {
                "name": "Stress Testing",
                "description": "Evaluates portfolio performance under extreme market conditions",
                "methods": ["historical", "hypothetical", "monte_carlo"],
                "default_method": "historical",
                "scenarios": ["market_crash", "interest_rate_spike", "liquidity_crisis", "sector_shock"],
                "default_scenario": "market_crash"
            },
            "sensitivity_analysis": {
                "name": "Sensitivity Analysis",
                "description": "Analyzes how changes in market factors affect portfolio value",
                "methods": ["delta", "gamma", "vega", "theta", "rho"],
                "default_method": "delta",
                "factors": ["price", "volatility", "interest_rate", "time"],
                "default_factor": "price"
            },
            "correlation_analysis": {
                "name": "Correlation Analysis",
                "description": "Analyzes correlations between assets in the portfolio",
                "methods": ["pearson", "spearman", "kendall"],
                "default_method": "pearson",
                "time_periods": [30, 90, 180, 365],  # days
                "default_time_period": 90
            },
            "tail_risk": {
                "name": "Tail Risk",
                "description": "Analyzes extreme events and their impact on the portfolio",
                "methods": ["extreme_value_theory", "copula", "power_law"],
                "default_method": "extreme_value_theory",
                "confidence_levels": [0.95, 0.99, 0.999],
                "default_confidence_level": 0.99
            },
            "liquidity_risk": {
                "name": "Liquidity Risk",
                "description": "Analyzes the risk of not being able to liquidate positions quickly",
                "methods": ["bid_ask_spread", "volume_analysis", "market_impact"],
                "default_method": "volume_analysis",
                "thresholds": [0.01, 0.05, 0.1],  # percentage of daily volume
                "default_threshold": 0.05
            }
        }
    
    def _initialize_position_sizing_models(self) -> Dict[str, Any]:
        """Initialize position sizing models."""
        return {
            "fixed": {
                "name": "Fixed Position Sizing",
                "description": "Uses a fixed position size for all trades",
                "parameters": {
                    "position_size": 0.02  # 2% of portfolio
                }
            },
            "kelly": {
                "name": "Kelly Criterion",
                "description": "Optimizes position size based on win rate and risk-reward ratio",
                "parameters": {
                    "fraction": 0.5,  # Half-Kelly for more conservative sizing
                    "max_position_size": 0.05  # 5% of portfolio
                }
            },
            "optimal_f": {
                "name": "Optimal F",
                "description": "Optimizes position size based on historical returns",
                "parameters": {
                    "lookback_period": 100,  # trades
                    "max_position_size": 0.05  # 5% of portfolio
                }
            },
            "volatility_based": {
                "name": "Volatility-Based Sizing",
                "description": "Adjusts position size based on market volatility",
                "parameters": {
                    "target_volatility": 0.01,  # 1% daily volatility
                    "lookback_period": 20,  # days
                    "max_position_size": 0.05  # 5% of portfolio
                }
            },
            "risk_parity": {
                "name": "Risk Parity",
                "description": "Allocates capital to equalize risk contribution across assets",
                "parameters": {
                    "risk_measure": "volatility",
                    "lookback_period": 60,  # days
                    "max_position_size": 0.1  # 10% of portfolio
                }
            },
            "adaptive": {
                "name": "Adaptive Position Sizing",
                "description": "Dynamically adjusts position size based on market conditions and strategy performance",
                "parameters": {
                    "base_size": 0.02,  # 2% of portfolio
                    "max_position_size": 0.05,  # 5% of portfolio
                    "min_position_size": 0.005,  # 0.5% of portfolio
                    "performance_lookback": 20,  # trades
                    "market_condition_lookback": 10  # days
                }
            }
        }
    
    def _initialize_stress_test_scenarios(self) -> Dict[str, Any]:
        """Initialize stress test scenarios."""
        return {
            "market_crash": {
                "name": "Market Crash",
                "description": "Simulates a severe market downturn similar to historical crashes",
                "asset_changes": {
                    "stocks": -0.3,  # 30% drop
                    "bonds": 0.05,  # 5% increase (flight to safety)
                    "crypto": -0.5,  # 50% drop
                    "commodities": -0.2,  # 20% drop
                    "forex": 0.0  # No change
                },
                "volatility_changes": {
                    "stocks": 2.0,  # 2x increase
                    "bonds": 1.5,  # 1.5x increase
                    "crypto": 3.0,  # 3x increase
                    "commodities": 2.0,  # 2x increase
                    "forex": 1.5  # 1.5x increase
                },
                "correlation_changes": {
                    "stocks_bonds": -0.7,  # Strong negative correlation
                    "stocks_crypto": 0.8,  # Strong positive correlation
                    "stocks_commodities": 0.6  # Moderate positive correlation
                },
                "liquidity_changes": {
                    "stocks": 0.5,  # 50% reduction
                    "bonds": 0.7,  # 30% reduction
                    "crypto": 0.3,  # 70% reduction
                    "commodities": 0.6,  # 40% reduction
                    "forex": 0.8  # 20% reduction
                },
                "duration": 20  # days
            },
            "interest_rate_spike": {
                "name": "Interest Rate Spike",
                "description": "Simulates a sudden and significant increase in interest rates",
                "asset_changes": {
                    "stocks": -0.15,  # 15% drop
                    "bonds": -0.1,  # 10% drop
                    "crypto": -0.2,  # 20% drop
                    "commodities": 0.05,  # 5% increase
                    "forex": 0.02  # 2% increase
                },
                "volatility_changes": {
                    "stocks": 1.5,  # 1.5x increase
                    "bonds": 2.0,  # 2x increase
                    "crypto": 1.8,  # 1.8x increase
                    "commodities": 1.3,  # 1.3x increase
                    "forex": 1.4  # 1.4x increase
                },
                "correlation_changes": {
                    "stocks_bonds": 0.6,  # Positive correlation
                    "stocks_crypto": 0.5,  # Moderate positive correlation
                    "stocks_commodities": -0.3  # Negative correlation
                },
                "liquidity_changes": {
                    "stocks": 0.8,  # 20% reduction
                    "bonds": 0.7,  # 30% reduction
                    "crypto": 0.7,  # 30% reduction
                    "commodities": 0.9,  # 10% reduction
                    "forex": 0.9  # 10% reduction
                },
                "duration": 15  # days
            },
            "liquidity_crisis": {
                "name": "Liquidity Crisis",
                "description": "Simulates a situation where market liquidity dries up",
                "asset_changes": {
                    "stocks": -0.2,  # 20% drop
                    "bonds": -0.05,  # 5% drop
                    "crypto": -0.3,  # 30% drop
                    "commodities": -0.1,  # 10% drop
                    "forex": 0.0  # No change
                },
                "volatility_changes": {
                    "stocks": 2.5,  # 2.5x increase
                    "bonds": 1.8,  # 1.8x increase
                    "crypto": 3.0,  # 3x increase
                    "commodities": 2.0,  # 2x increase
                    "forex": 1.5  # 1.5x increase
                },
                "correlation_changes": {
                    "stocks_bonds": 0.8,  # Strong positive correlation
                    "stocks_crypto": 0.9,  # Very strong positive correlation
                    "stocks_commodities": 0.7  # Strong positive correlation
                },
                "liquidity_changes": {
                    "stocks": 0.3,  # 70% reduction
                    "bonds": 0.5,  # 50% reduction
                    "crypto": 0.2,  # 80% reduction
                    "commodities": 0.4,  # 60% reduction
                    "forex": 0.6  # 40% reduction
                },
                "duration": 10  # days
            },
            "sector_shock": {
                "name": "Sector-Specific Shock",
                "description": "Simulates a shock to specific market sectors",
                "sectors": {
                    "technology": -0.25,  # 25% drop
                    "finance": -0.2,  # 20% drop
                    "healthcare": 0.05,  # 5% increase
                    "energy": -0.15,  # 15% drop
                    "consumer": -0.1  # 10% drop
                },
                "volatility_changes": {
                    "technology": 2.0,  # 2x increase
                    "finance": 1.8,  # 1.8x increase
                    "healthcare": 1.2,  # 1.2x increase
                    "energy": 1.7,  # 1.7x increase
                    "consumer": 1.5  # 1.5x increase
                },
                "correlation_changes": {
                    "technology_finance": 0.7,  # Strong positive correlation
                    "technology_healthcare": 0.3,  # Weak positive correlation
                    "finance_energy": 0.6  # Moderate positive correlation
                },
                "liquidity_changes": {
                    "technology": 0.6,  # 40% reduction
                    "finance": 0.7,  # 30% reduction
                    "healthcare": 0.9,  # 10% reduction
                    "energy": 0.7,  # 30% reduction
                    "consumer": 0.8  # 20% reduction
                },
                "duration": 15  # days
            },
            "crypto_winter": {
                "name": "Crypto Winter",
                "description": "Simulates a prolonged downturn in cryptocurrency markets",
                "asset_changes": {
                    "crypto": -0.7,  # 70% drop
                    "stocks": -0.1,  # 10% drop
                    "bonds": 0.02,  # 2% increase
                    "commodities": 0.05,  # 5% increase
                    "forex": 0.01  # 1% increase
                },
                "volatility_changes": {
                    "crypto": 4.0,  # 4x increase
                    "stocks": 1.3,  # 1.3x increase
                    "bonds": 1.1,  # 1.1x increase
                    "commodities": 1.2,  # 1.2x increase
                    "forex": 1.1  # 1.1x increase
                },
                "correlation_changes": {
                    "crypto_stocks": 0.4,  # Moderate positive correlation
                    "crypto_bonds": -0.2,  # Weak negative correlation
                    "crypto_commodities": 0.1  # Very weak positive correlation
                },
                "liquidity_changes": {
                    "crypto": 0.2,  # 80% reduction
                    "stocks": 0.9,  # 10% reduction
                    "bonds": 1.0,  # No reduction
                    "commodities": 0.9,  # 10% reduction
                    "forex": 1.0  # No reduction
                },
                "duration": 180  # days
            },
            "inflation_surge": {
                "name": "Inflation Surge",
                "description": "Simulates a period of high inflation",
                "asset_changes": {
                    "stocks": -0.05,  # 5% drop
                    "bonds": -0.15,  # 15% drop
                    "crypto": 0.1,  # 10% increase
                    "commodities": 0.2,  # 20% increase
                    "forex": -0.05  # 5% drop
                },
                "volatility_changes": {
                    "stocks": 1.4,  # 1.4x increase
                    "bonds": 1.6,  # 1.6x increase
                    "crypto": 1.5,  # 1.5x increase
                    "commodities": 1.8,  # 1.8x increase
                    "forex": 1.3  # 1.3x increase
                },
                "correlation_changes": {
                    "stocks_bonds": 0.5,  # Moderate positive correlation
                    "stocks_commodities": -0.4,  # Moderate negative correlation
                    "bonds_commodities": -0.6  # Strong negative correlation
                },
                "liquidity_changes": {
                    "stocks": 0.9,  # 10% reduction
                    "bonds": 0.8,  # 20% reduction
                    "crypto": 0.9,  # 10% reduction
                    "commodities": 0.7,  # 30% reduction
                    "forex": 0.9  # 10% reduction
                },
                "duration": 90  # days
            },
            "geopolitical_crisis": {
                "name": "Geopolitical Crisis",
                "description": "Simulates a major geopolitical crisis",
                "asset_changes": {
                    "stocks": -0.15,  # 15% drop
                    "bonds": 0.05,  # 5% increase
                    "crypto": -0.1,  # 10% drop
                    "commodities": 0.15,  # 15% increase
                    "forex": 0.03  # 3% increase
                },
                "volatility_changes": {
                    "stocks": 2.0,  # 2x increase
                    "bonds": 1.5,  # 1.5x increase
                    "crypto": 2.0,  # 2x increase
                    "commodities": 2.5,  # 2.5x increase
                    "forex": 1.8  # 1.8x increase
                },
                "correlation_changes": {
                    "stocks_bonds": -0.6,  # Strong negative correlation
                    "stocks_commodities": -0.5,  # Moderate negative correlation
                    "bonds_forex": 0.4  # Moderate positive correlation
                },
                "liquidity_changes": {
                    "stocks": 0.7,  # 30% reduction
                    "bonds": 0.8,  # 20% reduction
                    "crypto": 0.6,  # 40% reduction
                    "commodities": 0.6,  # 40% reduction
                    "forex": 0.7  # 30% reduction
                },
                "duration": 30  # days
            }
        }
    
    def _initialize_risk_limits(self) -> Dict[str, Any]:
        """Initialize risk limits."""
        return {
            "portfolio_var_limit": 0.02,  # 2% daily VaR limit
            "position_var_limit": 0.005,  # 0.5% daily VaR limit per position
            "max_drawdown_limit": 0.15,  # 15% maximum drawdown
            "concentration_limit": 0.2,  # 20% maximum concentration in a single asset
            "sector_concentration_limit": 0.3,  # 30% maximum concentration in a single sector
            "liquidity_limit": 0.1,  # Position should not exceed 10% of daily volume
            "leverage_limit": 2.0,  # Maximum leverage of 2x
            "correlation_limit": 0.7,  # Maximum correlation between assets
            "volatility_limit": 0.02,  # 2% daily volatility limit
            "stress_test_loss_limit": 0.25  # 25% maximum loss in stress tests
        }
    
    def calculate_var(self, portfolio: Dict[str, Any], method: str = "historical",
                     confidence_level: float = 0.95, time_horizon: int = 1) -> Dict[str, Any]:
        """
        Calculate Value at Risk (VaR) for a portfolio.
        
        Args:
            portfolio: Portfolio data
            method: Method to use (historical, parametric, monte_carlo)
            confidence_level: Confidence level (e.g., 0.95 for 95%)
            time_horizon: Time horizon in days
            
        Returns:
            VaR calculation results
        """
        logger.info(f"Calculating VaR using {method} method at {confidence_level} confidence level for {time_horizon} day(s)")
        
        try:
            # Get portfolio value
            portfolio_value = portfolio.get("total_value", 0.0)
            
            if portfolio_value <= 0:
                return {
                    "success": False,
                    "error": "Invalid portfolio value"
                }
            
            # Get portfolio returns
            returns = self._get_portfolio_returns(portfolio)
            
            if returns is None or len(returns) < 10:
                return {
                    "success": False,
                    "error": "Insufficient return data"
                }
            
            var_result = None
            
            # Calculate VaR using the specified method
            if method == "historical":
                var_result = self._calculate_historical_var(returns, confidence_level, time_horizon)
            elif method == "parametric":
                var_result = self._calculate_parametric_var(returns, confidence_level, time_horizon)
            elif method == "monte_carlo":
                var_result = self._calculate_monte_carlo_var(returns, confidence_level, time_horizon)
            else:
                return {
                    "success": False,
                    "error": f"Unknown VaR method: {method}"
                }
            
            # Calculate VaR as a percentage of portfolio value
            var_percentage = var_result / portfolio_value
            
            # Check if VaR exceeds limit
            var_limit = self.risk_limits["portfolio_var_limit"]
            var_status = "normal" if var_percentage <= var_limit else "exceeded"
            
            # Calculate VaR for each asset
            asset_vars = {}
            
            for asset in portfolio.get("assets", []):
                asset_id = asset["market_id"]
                asset_value = asset["current_value"]
                asset_weight = asset_value / portfolio_value
                
                # Simplified calculation: asset VaR = asset weight * portfolio VaR
                asset_var = asset_weight * var_result
                asset_var_percentage = asset_var / asset_value if asset_value > 0 else 0
                
                asset_vars[asset_id] = {
                    "var": float(asset_var),
                    "var_percentage": float(asset_var_percentage),
                    "contribution": float(asset_var / var_result) if var_result > 0 else 0
                }
            
            return {
                "success": True,
                "var": float(var_result),
                "var_percentage": float(var_percentage),
                "method": method,
                "confidence_level": confidence_level,
                "time_horizon": time_horizon,
                "limit": float(var_limit),
                "status": var_status,
                "asset_vars": asset_vars,
                "timestamp": datetime.datetime.now().isoformat()
            }
        
        except Exception as e:
            logger.error(f"Error calculating VaR: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def _calculate_historical_var(self, returns: np.ndarray, confidence_level: float, time_horizon: int) -> float:
        """
        Calculate VaR using the historical method.
        
        Args:
            returns: Array of historical returns
            confidence_level: Confidence level
            time_horizon: Time horizon in days
            
        Returns:
            VaR value
        """
        # Sort returns in ascending order
        sorted_returns = np.sort(returns)
        
        # Find the index corresponding to the confidence level
        index = int(np.ceil((1 - confidence_level) * len(sorted_returns))) - 1
        index = max(0, min(index, len(sorted_returns) - 1))
        
        # Get the return at the specified confidence level
        var_return = sorted_returns[index]
        
        # Scale to the specified time horizon
        var = -var_return * np.sqrt(time_horizon)
        
        return float(var)
    
    def _calculate_parametric_var(self, returns: np.ndarray, confidence_level: float, time_horizon: int) -> float:
        """
        Calculate VaR using the parametric method.
        
        Args:
            returns: Array of historical returns
            confidence_level: Confidence level
            time_horizon: Time horizon in days
            
        Returns:
            VaR value
        """
        # Calculate mean and standard deviation of returns
        mean_return = np.mean(returns)
        std_return = np.std(returns)
        
        # Calculate z-score for the specified confidence level
        z_score = stats.norm.ppf(confidence_level)
        
        # Calculate VaR
        var = -(mean_return + z_score * std_return) * np.sqrt(time_horizon)
        
        return float(var)
    
    def _calculate_monte_carlo_var(self, returns: np.ndarray, confidence_level: float, time_horizon: int) -> float:
        """
        Calculate VaR using the Monte Carlo method.
        
        Args:
            returns: Array of historical returns
            confidence_level: Confidence level
            time_horizon: Time horizon in days
            
        Returns:
            VaR value
        """
        # Calculate mean and standard deviation of returns
        mean_return = np.mean(returns)
        std_return = np.std(returns)
        
        # Generate random returns
        num_simulations = 10000
        random_returns = np.random.normal(mean_return, std_return, num_simulations)
        
        # Scale to the specified time horizon
        random_returns = random_returns * np.sqrt(time_horizon)
        
        # Sort returns in ascending order
        sorted_returns = np.sort(random_returns)
        
        # Find the index corresponding to the confidence level
        index = int(np.ceil((1 - confidence_level) * num_simulations)) - 1
        index = max(0, min(index, num_simulations - 1))
        
        # Get the return at the specified confidence level
        var_return = sorted_returns[index]
        
        # Calculate VaR
        var = -var_return
        
        return float(var)
    
    def calculate_cvar(self, portfolio: Dict[str, Any], method: str = "historical",
                      confidence_level: float = 0.95, time_horizon: int = 1) -> Dict[str, Any]:
        """
        Calculate Conditional Value at Risk (CVaR) for a portfolio.
        
        Args:
            portfolio: Portfolio data
            method: Method to use (historical, parametric, monte_carlo)
            confidence_level: Confidence level (e.g., 0.95 for 95%)
            time_horizon: Time horizon in days
            
        Returns:
            CVaR calculation results
        """
        logger.info(f"Calculating CVaR using {method} method at {confidence_level} confidence level for {time_horizon} day(s)")
        
        try:
            # First, calculate VaR
            var_result = self.calculate_var(portfolio, method, confidence_level, time_horizon)
            
            if not var_result["success"]:
                return var_result
            
            # Get portfolio value
            portfolio_value = portfolio.get("total_value", 0.0)
            
            # Get portfolio returns
            returns = self._get_portfolio_returns(portfolio)
            
            if returns is None or len(returns) < 10:
                return {
                    "success": False,
                    "error": "Insufficient return data"
                }
            
            cvar_result = None
            
            # Calculate CVaR using the specified method
            if method == "historical":
                cvar_result = self._calculate_historical_cvar(returns, confidence_level, time_horizon)
            elif method == "parametric":
                cvar_result = self._calculate_parametric_cvar(returns, confidence_level, time_horizon)
            elif method == "monte_carlo":
                cvar_result = self._calculate_monte_carlo_cvar(returns, confidence_level, time_horizon)
            else:
                return {
                    "success": False,
                    "error": f"Unknown CVaR method: {method}"
                }
            
            # Calculate CVaR as a percentage of portfolio value
            cvar_percentage = cvar_result / portfolio_value
            
            # Calculate CVaR for each asset
            asset_cvars = {}
            
            for asset in portfolio.get("assets", []):
                asset_id = asset["market_id"]
                asset_value = asset["current_value"]
                asset_weight = asset_value / portfolio_value
                
                # Simplified calculation: asset CVaR = asset weight * portfolio CVaR
                asset_cvar = asset_weight * cvar_result
                asset_cvar_percentage = asset_cvar / asset_value if asset_value > 0 else 0
                
                asset_cvars[asset_id] = {
                    "cvar": float(asset_cvar),
                    "cvar_percentage": float(asset_cvar_percentage),
                    "contribution": float(asset_cvar / cvar_result) if cvar_result > 0 else 0
                }
            
            return {
                "success": True,
                "var": var_result["var"],
                "cvar": float(cvar_result),
                "cvar_percentage": float(cvar_percentage),
                "method": method,
                "confidence_level": confidence_level,
                "time_horizon": time_horizon,
                "asset_cvars": asset_cvars,
                "timestamp": datetime.datetime.now().isoformat()
            }
        
        except Exception as e:
            logger.error(f"Error calculating CVaR: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def _calculate_historical_cvar(self, returns: np.ndarray, confidence_level: float, time_horizon: int) -> float:
        """
        Calculate CVaR using the historical method.
        
        Args:
            returns: Array of historical returns
            confidence_level: Confidence level
            time_horizon: Time horizon in days
            
        Returns:
            CVaR value
        """
        # Sort returns in ascending order
        sorted_returns = np.sort(returns)
        
        # Find the index corresponding to the confidence level
        index = int(np.ceil((1 - confidence_level) * len(sorted_returns))) - 1
        index = max(0, min(index, len(sorted_returns) - 1))
        
        # Calculate CVaR as the average of returns beyond the VaR threshold
        cvar_returns = sorted_returns[:index+1]
        cvar_return = np.mean(cvar_returns)
        
        # Scale to the specified time horizon
        cvar = -cvar_return * np.sqrt(time_horizon)
        
        return float(cvar)
    
    def _calculate_parametric_cvar(self, returns: np.ndarray, confidence_level: float, time_horizon: int) -> float:
        """
        Calculate CVaR using the parametric method.
        
        Args:
            returns: Array of historical returns
            confidence_level: Confidence level
            time_horizon: Time horizon in days
            
        Returns:
            CVaR value
        """
        # Calculate mean and standard deviation of returns
        mean_return = np.mean(returns)
        std_return = np.std(returns)
        
        # Calculate z-score for the specified confidence level
        z_score = stats.norm.ppf(confidence_level)
        
        # Calculate CVaR
        pdf_z = stats.norm.pdf(z_score)
        cdf_z = stats.norm.cdf(z_score)
        
        cvar_return = mean_return - std_return * pdf_z / (1 - confidence_level)
        
        # Scale to the specified time horizon
        cvar = -cvar_return * np.sqrt(time_horizon)
        
        return float(cvar)
    
    def _calculate_monte_carlo_cvar(self, returns: np.ndarray, confidence_level: float, time_horizon: int) -> float:
        """
        Calculate CVaR using the Monte Carlo method.
        
        Args:
            returns: Array of historical returns
            confidence_level: Confidence level
            time_horizon: Time horizon in days
            
        Returns:
            CVaR value
        """
        # Calculate mean and standard deviation of returns
        mean_return = np.mean(returns)
        std_return = np.std(returns)
        
        # Generate random returns
        num_simulations = 10000
        random_returns = np.random.normal(mean_return, std_return, num_simulations)
        
        # Scale to the specified time horizon
        random_returns = random_returns * np.sqrt(time_horizon)
        
        # Sort returns in ascending order
        sorted_returns = np.sort(random_returns)
        
        # Find the index corresponding to the confidence level
        index = int(np.ceil((1 - confidence_level) * num_simulations)) - 1
        index = max(0, min(index, num_simulations - 1))
        
        # Calculate CVaR as the average of returns beyond the VaR threshold
        cvar_returns = sorted_returns[:index+1]
        cvar_return = np.mean(cvar_returns)
        
        # Calculate CVaR
        cvar = -cvar_return
        
        return float(cvar)
    
    def run_stress_test(self, portfolio: Dict[str, Any], scenario: str = "market_crash") -> Dict[str, Any]:
        """
        Run a stress test on a portfolio.
        
        Args:
            portfolio: Portfolio data
            scenario: Stress test scenario
            
        Returns:
            Stress test results
        """
        logger.info(f"Running stress test with scenario: {scenario}")
        
        try:
            # Check if scenario exists
            if scenario not in self.stress_test_scenarios:
                return {
                    "success": False,
                    "error": f"Unknown scenario: {scenario}"
                }
            
            # Get scenario
            scenario_data = self.stress_test_scenarios[scenario]
            
            # Get portfolio value
            portfolio_value = portfolio.get("total_value", 0.0)
            
            if portfolio_value <= 0:
                return {
                    "success": False,
                    "error": "Invalid portfolio value"
                }
            
            # Apply scenario to portfolio
            asset_impacts = []
            total_impact = 0.0
            
            for asset in portfolio.get("assets", []):
                asset_id = asset["market_id"]
                asset_value = asset["current_value"]
                asset_type = self._determine_asset_type(asset_id)
                
                # Get asset change
                asset_change = 0.0
                
                if "asset_changes" in scenario_data and asset_type in scenario_data["asset_changes"]:
                    asset_change = scenario_data["asset_changes"][asset_type]
                elif "sectors" in scenario_data:
                    # Check if asset belongs to a specific sector
                    asset_sector = self._determine_asset_sector(asset_id)
                    
                    if asset_sector in scenario_data["sectors"]:
                        asset_change = scenario_data["sectors"][asset_sector]
                
                # Calculate impact
                impact = asset_value * asset_change
                total_impact += impact
                
                # Calculate new value
                new_value = asset_value + impact
                
                # Get volatility change
                volatility_change = 1.0
                
                if "volatility_changes" in scenario_data:
                    if asset_type in scenario_data["volatility_changes"]:
                        volatility_change = scenario_data["volatility_changes"][asset_type]
                    elif "sectors" in scenario_data and asset_sector in scenario_data["volatility_changes"]:
                        volatility_change = scenario_data["volatility_changes"][asset_sector]
                
                # Get liquidity change
                liquidity_change = 1.0
                
                if "liquidity_changes" in scenario_data:
                    if asset_type in scenario_data["liquidity_changes"]:
                        liquidity_change = scenario_data["liquidity_changes"][asset_type]
                    elif "sectors" in scenario_data and asset_sector in scenario_data["liquidity_changes"]:
                        liquidity_change = scenario_data["liquidity_changes"][asset_sector]
                
                asset_impacts.append({
                    "asset_id": asset_id,
                    "asset_type": asset_type,
                    "current_value": float(asset_value),
                    "change": float(asset_change),
                    "impact": float(impact),
                    "new_value": float(new_value),
                    "volatility_change": float(volatility_change),
                    "liquidity_change": float(liquidity_change)
                })
            
            # Calculate new portfolio value
            new_portfolio_value = portfolio_value + total_impact
            
            # Calculate percentage change
            percentage_change = (new_portfolio_value / portfolio_value - 1) * 100
            
            # Check if loss exceeds limit
            loss_limit = self.risk_limits["stress_test_loss_limit"] * 100
            status = "normal" if abs(percentage_change) <= loss_limit else "exceeded"
            
            return {
                "success": True,
                "scenario": scenario,
                "scenario_name": scenario_data["name"],
                "scenario_description": scenario_data["description"],
                "current_value": float(portfolio_value),
                "new_value": float(new_portfolio_value),
                "impact": float(total_impact),
                "percentage_change": float(percentage_change),
                "loss_limit": float(loss_limit),
                "status": status,
                "asset_impacts": asset_impacts,
                "duration": scenario_data.get("duration", 0),
                "timestamp": datetime.datetime.now().isoformat()
            }
        
        except Exception as e:
            logger.error(f"Error running stress test: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def run_all_stress_tests(self, portfolio: Dict[str, Any]) -> Dict[str, Any]:
        """
        Run all stress tests on a portfolio.
        
        Args:
            portfolio: Portfolio data
            
        Returns:
            All stress test results
        """
        logger.info("Running all stress tests")
        
        try:
            results = {}
            worst_scenario = None
            worst_impact = 0.0
            
            for scenario in self.stress_test_scenarios:
                result = self.run_stress_test(portfolio, scenario)
                
                if result["success"]:
                    results[scenario] = result
                    
                    # Check if this is the worst scenario
                    if result["impact"] < worst_impact:
                        worst_impact = result["impact"]
                        worst_scenario = scenario
            
            return {
                "success": True,
                "results": results,
                "worst_scenario": worst_scenario,
                "worst_impact": float(worst_impact) if worst_scenario else 0.0,
                "timestamp": datetime.datetime.now().isoformat()
            }
        
        except Exception as e:
            logger.error(f"Error running all stress tests: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def calculate_position_size(self, portfolio: Dict[str, Any], market_id: str,
                               model: str = "adaptive", params: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Calculate optimal position size for a trade.
        
        Args:
            portfolio: Portfolio data
            market_id: Market ID for the trade
            model: Position sizing model to use
            params: Additional parameters for the model
            
        Returns:
            Position sizing results
        """
        logger.info(f"Calculating position size for {market_id} using {model} model")
        
        if params is None:
            params = {}
        
        try:
            # Check if model exists
            if model not in self.position_sizing_models:
                return {
                    "success": False,
                    "error": f"Unknown position sizing model: {model}"
                }
            
            # Get model
            model_data = self.position_sizing_models[model]
            
            # Get portfolio value
            portfolio_value = portfolio.get("total_value", 0.0)
            
            if portfolio_value <= 0:
                return {
                    "success": False,
                    "error": "Invalid portfolio value"
                }
            
            # Calculate position size based on the model
            position_size = 0.0
            
            if model == "fixed":
                position_size = self._calculate_fixed_position_size(portfolio, market_id, params)
            elif model == "kelly":
                position_size = self._calculate_kelly_position_size(portfolio, market_id, params)
            elif model == "optimal_f":
                position_size = self._calculate_optimal_f_position_size(portfolio, market_id, params)
            elif model == "volatility_based":
                position_size = self._calculate_volatility_based_position_size(portfolio, market_id, params)
            elif model == "risk_parity":
                position_size = self._calculate_risk_parity_position_size(portfolio, market_id, params)
            elif model == "adaptive":
                position_size = self._calculate_adaptive_position_size(portfolio, market_id, params)
            else:
                return {
                    "success": False,
                    "error": f"Position sizing model not implemented: {model}"
                }
            
            # Calculate position value
            position_value = portfolio_value * position_size
            
            # Check if position size exceeds limits
            max_position_size = model_data["parameters"].get("max_position_size", 0.05)
            
            if "max_position_size" in params:
                max_position_size = params["max_position_size"]
            
            if position_size > max_position_size:
                position_size = max_position_size
                position_value = portfolio_value * position_size
            
            return {
                "success": True,
                "market_id": market_id,
                "model": model,
                "position_size": float(position_size),
                "position_value": float(position_value),
                "max_position_size": float(max_position_size),
                "timestamp": datetime.datetime.now().isoformat()
            }
        
        except Exception as e:
            logger.error(f"Error calculating position size: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def _calculate_fixed_position_size(self, portfolio: Dict[str, Any], market_id: str, params: Dict[str, Any]) -> float:
        """
        Calculate position size using the fixed model.
        
        Args:
            portfolio: Portfolio data
            market_id: Market ID for the trade
            params: Additional parameters
            
        Returns:
            Position size as a fraction of portfolio value
        """
        # Get model parameters
        model_params = self.position_sizing_models["fixed"]["parameters"]
        
        # Get position size
        position_size = params.get("position_size", model_params["position_size"])
        
        return position_size
    
    def _calculate_kelly_position_size(self, portfolio: Dict[str, Any], market_id: str, params: Dict[str, Any]) -> float:
        """
        Calculate position size using the Kelly Criterion.
        
        Args:
            portfolio: Portfolio data
            market_id: Market ID for the trade
            params: Additional parameters
            
        Returns:
            Position size as a fraction of portfolio value
        """
        # Get model parameters
        model_params = self.position_sizing_models["kelly"]["parameters"]
        
        # Get win rate and risk-reward ratio
        win_rate = params.get("win_rate", 0.5)
        risk_reward = params.get("risk_reward", 1.0)
        
        # Calculate Kelly fraction
        kelly_fraction = win_rate - (1 - win_rate) / risk_reward
        
        # Apply fraction parameter
        fraction = params.get("fraction", model_params["fraction"])
        position_size = kelly_fraction * fraction
        
        # Ensure position size is non-negative
        position_size = max(0, position_size)
        
        # Apply maximum position size
        max_position_size = params.get("max_position_size", model_params["max_position_size"])
        position_size = min(position_size, max_position_size)
        
        return position_size
    
    def _calculate_optimal_f_position_size(self, portfolio: Dict[str, Any], market_id: str, params: Dict[str, Any]) -> float:
        """
        Calculate position size using the Optimal F method.
        
        Args:
            portfolio: Portfolio data
            market_id: Market ID for the trade
            params: Additional parameters
            
        Returns:
            Position size as a fraction of portfolio value
        """
        # Get model parameters
        model_params = self.position_sizing_models["optimal_f"]["parameters"]
        
        # In a real implementation, we would:
        # 1. Get historical trades for the market
        # 2. Calculate the optimal f value
        # 3. Apply the optimal f value to determine position size
        
        # For now, use a placeholder value
        position_size = 0.02
        
        # Apply maximum position size
        max_position_size = params.get("max_position_size", model_params["max_position_size"])
        position_size = min(position_size, max_position_size)
        
        return position_size
    
    def _calculate_volatility_based_position_size(self, portfolio: Dict[str, Any], market_id: str, params: Dict[str, Any]) -> float:
        """
        Calculate position size based on market volatility.
        
        Args:
            portfolio: Portfolio data
            market_id: Market ID for the trade
            params: Additional parameters
            
        Returns:
            Position size as a fraction of portfolio value
        """
        # Get model parameters
        model_params = self.position_sizing_models["volatility_based"]["parameters"]
        
        # Get target volatility
        target_volatility = params.get("target_volatility", model_params["target_volatility"])
        
        # Get market volatility
        market_volatility = params.get("market_volatility", 0.02)  # Default to 2% daily volatility
        
        # Calculate position size
        position_size = target_volatility / market_volatility
        
        # Apply maximum position size
        max_position_size = params.get("max_position_size", model_params["max_position_size"])
        position_size = min(position_size, max_position_size)
        
        return position_size
    
    def _calculate_risk_parity_position_size(self, portfolio: Dict[str, Any], market_id: str, params: Dict[str, Any]) -> float:
        """
        Calculate position size using the risk parity approach.
        
        Args:
            portfolio: Portfolio data
            market_id: Market ID for the trade
            params: Additional parameters
            
        Returns:
            Position size as a fraction of portfolio value
        """
        # Get model parameters
        model_params = self.position_sizing_models["risk_parity"]["parameters"]
        
        # In a real implementation, we would:
        # 1. Calculate the risk contribution of each asset
        # 2. Determine the position size that equalizes risk contributions
        
        # For now, use a placeholder value
        position_size = 0.03
        
        # Apply maximum position size
        max_position_size = params.get("max_position_size", model_params["max_position_size"])
        position_size = min(position_size, max_position_size)
        
        return position_size
    
    def _calculate_adaptive_position_size(self, portfolio: Dict[str, Any], market_id: str, params: Dict[str, Any]) -> float:
        """
        Calculate position size using an adaptive approach.
        
        Args:
            portfolio: Portfolio data
            market_id: Market ID for the trade
            params: Additional parameters
            
        Returns:
            Position size as a fraction of portfolio value
        """
        # Get model parameters
        model_params = self.position_sizing_models["adaptive"]["parameters"]
        
        # Get base position size
        base_size = params.get("base_size", model_params["base_size"])
        
        # Get performance factor
        performance_factor = params.get("performance_factor", 1.0)
        
        # Get market condition factor
        market_condition_factor = params.get("market_condition_factor", 1.0)
        
        # Calculate position size
        position_size = base_size * performance_factor * market_condition_factor
        
        # Apply minimum and maximum position size
        min_position_size = params.get("min_position_size", model_params["min_position_size"])
        max_position_size = params.get("max_position_size", model_params["max_position_size"])
        
        position_size = max(min_position_size, min(position_size, max_position_size))
        
        return position_size
    
    def analyze_portfolio_risk(self, portfolio: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform a comprehensive risk analysis of a portfolio.
        
        Args:
            portfolio: Portfolio data
            
        Returns:
            Risk analysis results
        """
        logger.info("Analyzing portfolio risk")
        
        try:
            # Get portfolio value
            portfolio_value = portfolio.get("total_value", 0.0)
            
            if portfolio_value <= 0:
                return {
                    "success": False,
                    "error": "Invalid portfolio value"
                }
            
            # Calculate VaR
            var_result = self.calculate_var(portfolio)
            
            # Calculate CVaR
            cvar_result = self.calculate_cvar(portfolio)
            
            # Run stress tests
            stress_test_result = self.run_all_stress_tests(portfolio)
            
            # Calculate portfolio metrics
            metrics = self._calculate_portfolio_metrics(portfolio)
            
            # Calculate concentration metrics
            concentration = self._calculate_concentration_metrics(portfolio)
            
            # Calculate correlation metrics
            correlation = self._calculate_correlation_metrics(portfolio)
            
            # Calculate liquidity metrics
            liquidity = self._calculate_liquidity_metrics(portfolio)
            
            # Calculate overall risk score
            risk_score = self._calculate_risk_score(var_result, cvar_result, stress_test_result, metrics, concentration, correlation, liquidity)
            
            # Generate risk report
            risk_report = {
                "success": True,
                "portfolio_value": float(portfolio_value),
                "var": var_result if var_result["success"] else None,
                "cvar": cvar_result if cvar_result["success"] else None,
                "stress_tests": stress_test_result if stress_test_result["success"] else None,
                "metrics": metrics,
                "concentration": concentration,
                "correlation": correlation,
                "liquidity": liquidity,
                "risk_score": risk_score,
                "timestamp": datetime.datetime.now().isoformat()
            }
            
            # Log risk assessment
            self._log_risk_event("portfolio_risk_analysis", risk_report)
            
            return risk_report
        
        except Exception as e:
            logger.error(f"Error analyzing portfolio risk: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def _calculate_portfolio_metrics(self, portfolio: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculate portfolio metrics.
        
        Args:
            portfolio: Portfolio data
            
        Returns:
            Portfolio metrics
        """
        # Get portfolio returns
        returns = self._get_portfolio_returns(portfolio)
        
        if returns is None or len(returns) < 10:
            return {
                "success": False,
                "error": "Insufficient return data"
            }
        
        # Calculate metrics
        annualized_return = np.mean(returns) * 252
        volatility = np.std(returns) * np.sqrt(252)
        sharpe_ratio = annualized_return / volatility if volatility > 0 else 0
        
        # Calculate maximum drawdown
        cumulative_returns = np.cumprod(1 + returns)
        max_drawdown = 1 - min(cumulative_returns / np.maximum.accumulate(cumulative_returns))
        
        # Calculate Sortino ratio
        negative_returns = returns[returns < 0]
        downside_deviation = np.std(negative_returns) * np.sqrt(252) if len(negative_returns) > 0 else 0.0001
        sortino_ratio = annualized_return / downside_deviation if downside_deviation > 0 else 0
        
        # Calculate Calmar ratio
        calmar_ratio = annualized_return / max_drawdown if max_drawdown > 0 else 0
        
        return {
            "annualized_return": float(annualized_return),
            "volatility": float(volatility),
            "sharpe_ratio": float(sharpe_ratio),
            "sortino_ratio": float(sortino_ratio),
            "max_drawdown": float(max_drawdown),
            "calmar_ratio": float(calmar_ratio)
        }
    
    def _calculate_concentration_metrics(self, portfolio: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculate concentration metrics.
        
        Args:
            portfolio: Portfolio data
            
        Returns:
            Concentration metrics
        """
        # Get portfolio value
        portfolio_value = portfolio.get("total_value", 0.0)
        
        if portfolio_value <= 0:
            return {
                "success": False,
                "error": "Invalid portfolio value"
            }
        
        # Calculate asset concentration
        assets = portfolio.get("assets", [])
        asset_weights = {}
        
        for asset in assets:
            asset_id = asset["market_id"]
            asset_value = asset["current_value"]
            asset_weight = asset_value / portfolio_value
            asset_weights[asset_id] = asset_weight
        
        # Calculate Herfindahl-Hirschman Index (HHI)
        hhi = sum(weight ** 2 for weight in asset_weights.values())
        
        # Calculate sector concentration
        sector_weights = {}
        
        for asset in assets:
            asset_id = asset["market_id"]
            asset_value = asset["current_value"]
            asset_weight = asset_value / portfolio_value
            
            sector = self._determine_asset_sector(asset_id)
            
            if sector in sector_weights:
                sector_weights[sector] += asset_weight
            else:
                sector_weights[sector] = asset_weight
        
        # Calculate sector HHI
        sector_hhi = sum(weight ** 2 for weight in sector_weights.values())
        
        # Find highest concentration
        highest_asset_concentration = max(asset_weights.values()) if asset_weights else 0
        highest_asset = max(asset_weights.items(), key=lambda x: x[1])[0] if asset_weights else None
        
        highest_sector_concentration = max(sector_weights.values()) if sector_weights else 0
        highest_sector = max(sector_weights.items(), key=lambda x: x[1])[0] if sector_weights else None
        
        # Check against limits
        asset_concentration_limit = self.risk_limits["concentration_limit"]
        sector_concentration_limit = self.risk_limits["sector_concentration_limit"]
        
        asset_concentration_status = "normal" if highest_asset_concentration <= asset_concentration_limit else "exceeded"
        sector_concentration_status = "normal" if highest_sector_concentration <= sector_concentration_limit else "exceeded"
        
        return {
            "asset_weights": {k: float(v) for k, v in asset_weights.items()},
            "sector_weights": {k: float(v) for k, v in sector_weights.items()},
            "hhi": float(hhi),
            "sector_hhi": float(sector_hhi),
            "highest_asset_concentration": float(highest_asset_concentration),
            "highest_asset": highest_asset,
            "highest_sector_concentration": float(highest_sector_concentration),
            "highest_sector": highest_sector,
            "asset_concentration_limit": float(asset_concentration_limit),
            "sector_concentration_limit": float(sector_concentration_limit),
            "asset_concentration_status": asset_concentration_status,
            "sector_concentration_status": sector_concentration_status
        }
    
    def _calculate_correlation_metrics(self, portfolio: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculate correlation metrics.
        
        Args:
            portfolio: Portfolio data
            
        Returns:
            Correlation metrics
        """
        # In a real implementation, we would:
        # 1. Get historical returns for all assets
        # 2. Calculate correlation matrix
        # 3. Calculate various correlation metrics
        
        # For now, return placeholder values
        return {
            "average_correlation": 0.3,
            "highest_correlation": 0.7,
            "lowest_correlation": -0.2,
            "correlation_limit": float(self.risk_limits["correlation_limit"]),
            "correlation_status": "normal"
        }
    
    def _calculate_liquidity_metrics(self, portfolio: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculate liquidity metrics.
        
        Args:
            portfolio: Portfolio data
            
        Returns:
            Liquidity metrics
        """
        # In a real implementation, we would:
        # 1. Get trading volume data for all assets
        # 2. Calculate liquidity metrics
        
        # For now, return placeholder values
        return {
            "average_liquidity_ratio": 0.05,
            "lowest_liquidity_ratio": 0.1,
            "liquidity_limit": float(self.risk_limits["liquidity_limit"]),
            "liquidity_status": "normal"
        }
    
    def _calculate_risk_score(self, var_result: Dict[str, Any], cvar_result: Dict[str, Any],
                             stress_test_result: Dict[str, Any], metrics: Dict[str, Any],
                             concentration: Dict[str, Any], correlation: Dict[str, Any],
                             liquidity: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculate overall risk score.
        
        Args:
            var_result: VaR calculation result
            cvar_result: CVaR calculation result
            stress_test_result: Stress test result
            metrics: Portfolio metrics
            concentration: Concentration metrics
            correlation: Correlation metrics
            liquidity: Liquidity metrics
            
        Returns:
            Risk score
        """
        # Calculate risk score components
        var_score = 0
        if var_result["success"]:
            var_percentage = var_result["var_percentage"]
            var_limit = self.risk_limits["portfolio_var_limit"]
            var_score = min(10, 10 * var_percentage / var_limit)
        
        cvar_score = 0
        if cvar_result["success"]:
            cvar_percentage = cvar_result["cvar_percentage"]
            cvar_limit = self.risk_limits["portfolio_var_limit"] * 1.5  # CVaR limit is typically higher than VaR
            cvar_score = min(10, 10 * cvar_percentage / cvar_limit)
        
        stress_test_score = 0
        if stress_test_result["success"] and "worst_impact" in stress_test_result:
            worst_impact = abs(stress_test_result["worst_impact"])
            stress_test_limit = self.risk_limits["stress_test_loss_limit"] * portfolio_value
            stress_test_score = min(10, 10 * worst_impact / stress_test_limit)
        
        volatility_score = min(10, 10 * metrics["volatility"] / self.risk_limits["volatility_limit"])
        
        drawdown_score = min(10, 10 * metrics["max_drawdown"] / self.risk_limits["max_drawdown_limit"])
        
        concentration_score = min(10, 10 * concentration["highest_asset_concentration"] / self.risk_limits["concentration_limit"])
        
        sector_concentration_score = min(10, 10 * concentration["highest_sector_concentration"] / self.risk_limits["sector_concentration_limit"])
        
        correlation_score = min(10, 10 * correlation["highest_correlation"] / self.risk_limits["correlation_limit"])
        
        liquidity_score = min(10, 10 * liquidity["average_liquidity_ratio"] / self.risk_limits["liquidity_limit"])
        
        # Calculate weighted average
        weights = {
            "var": 0.15,
            "cvar": 0.15,
            "stress_test": 0.15,
            "volatility": 0.1,
            "drawdown": 0.1,
            "concentration": 0.1,
            "sector_concentration": 0.1,
            "correlation": 0.075,
            "liquidity": 0.075
        }
        
        total_score = (
            weights["var"] * var_score +
            weights["cvar"] * cvar_score +
            weights["stress_test"] * stress_test_score +
            weights["volatility"] * volatility_score +
            weights["drawdown"] * drawdown_score +
            weights["concentration"] * concentration_score +
            weights["sector_concentration"] * sector_concentration_score +
            weights["correlation"] * correlation_score +
            weights["liquidity"] * liquidity_score
        )
        
        # Determine risk level
        risk_level = "low"
        if total_score >= 7.5:
            risk_level = "very high"
        elif total_score >= 5:
            risk_level = "high"
        elif total_score >= 2.5:
            risk_level = "medium"
        
        return {
            "total_score": float(total_score),
            "risk_level": risk_level,
            "components": {
                "var": float(var_score),
                "cvar": float(cvar_score),
                "stress_test": float(stress_test_score),
                "volatility": float(volatility_score),
                "drawdown": float(drawdown_score),
                "concentration": float(concentration_score),
                "sector_concentration": float(sector_concentration_score),
                "correlation": float(correlation_score),
                "liquidity": float(liquidity_score)
            },
            "weights": weights
        }
    
    def validate_trade(self, trade_params: Dict[str, Any], portfolio: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate a trade against risk limits.
        
        Args:
            trade_params: Parameters for the trade
            portfolio: Current portfolio
            
        Returns:
            Validation result
        """
        logger.info(f"Validating trade: {trade_params}")
        
        try:
            # First, use security manager to validate basic limits
            if self.security_manager:
                security_validation = self.security_manager.validate_trade(trade_params)
                
                if not security_validation["success"]:
                    return security_validation
            
            # Get trade parameters
            trade_type = trade_params.get("type")
            market_id = trade_params.get("market_id")
            quantity = float(trade_params.get("quantity", 0))
            price = float(trade_params.get("price", 0))
            
            # Calculate trade value
            trade_value = quantity * price
            
            # Get portfolio value
            portfolio_value = portfolio.get("total_value", 0.0)
            
            # Check position concentration
            if trade_type == "buy":
                # Find existing position
                existing_position = 0.0
                for asset in portfolio.get("assets", []):
                    if asset["market_id"] == market_id:
                        existing_position = asset["current_value"]
                        break
                
                # Calculate new position
                new_position = existing_position + trade_value
                
                # Check concentration
                concentration = new_position / portfolio_value
                
                if concentration > self.risk_limits["concentration_limit"]:
                    return {
                        "success": False,
                        "error": f"Position concentration ({concentration:.2%}) exceeds maximum ({self.risk_limits['concentration_limit']:.2%})"
                    }
                
                # Check sector concentration
                sector = self._determine_asset_sector(market_id)
                
                sector_position = 0.0
                for asset in portfolio.get("assets", []):
                    if self._determine_asset_sector(asset["market_id"]) == sector:
                        sector_position += asset["current_value"]
                
                new_sector_position = sector_position + trade_value
                sector_concentration = new_sector_position / portfolio_value
                
                if sector_concentration > self.risk_limits["sector_concentration_limit"]:
                    return {
                        "success": False,
                        "error": f"Sector concentration ({sector_concentration:.2%}) exceeds maximum ({self.risk_limits['sector_concentration_limit']:.2%})"
                    }
            
            # Check impact on portfolio risk
            # In a real implementation, we would simulate the trade and recalculate risk metrics
            
            # For now, return success
            return {
                "success": True,
                "trade_value": float(trade_value),
                "portfolio_value": float(portfolio_value),
                "trade_percentage": float(trade_value / portfolio_value)
            }
        
        except Exception as e:
            logger.error(f"Error validating trade: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def generate_risk_report(self, portfolio: Dict[str, Any], format: str = "json") -> Dict[str, Any]:
        """
        Generate a comprehensive risk report.
        
        Args:
            portfolio: Portfolio data
            format: Report format (json, html, pdf)
            
        Returns:
            Risk report
        """
        logger.info(f"Generating risk report in {format} format")
        
        try:
            # Analyze portfolio risk
            risk_analysis = self.analyze_portfolio_risk(portfolio)
            
            if not risk_analysis["success"]:
                return risk_analysis
            
            # Generate report based on format
            if format == "json":
                return {
                    "success": True,
                    "format": format,
                    "report": risk_analysis,
                    "timestamp": datetime.datetime.now().isoformat()
                }
            elif format == "html":
                html_report = self._generate_html_risk_report(risk_analysis)
                
                return {
                    "success": True,
                    "format": format,
                    "report": html_report,
                    "timestamp": datetime.datetime.now().isoformat()
                }
            elif format == "pdf":
                # In a real implementation, we would generate a PDF report
                return {
                    "success": False,
                    "error": "PDF report generation not implemented"
                }
            else:
                return {
                    "success": False,
                    "error": f"Unknown report format: {format}"
                }
        
        except Exception as e:
            logger.error(f"Error generating risk report: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def _generate_html_risk_report(self, risk_analysis: Dict[str, Any]) -> str:
        """
        Generate an HTML risk report.
        
        Args:
            risk_analysis: Risk analysis results
            
        Returns:
            HTML report
        """
        # In a real implementation, we would generate a proper HTML report
        # For now, return a simple HTML representation
        html = f"""
        <html>
        <head>
            <title>Portfolio Risk Report</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                h1, h2, h3 {{ color: #333; }}
                table {{ border-collapse: collapse; width: 100%; margin-bottom: 20px; }}
                th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                th {{ background-color: #f2f2f2; }}
                .risk-low {{ color: green; }}
                .risk-medium {{ color: orange; }}
                .risk-high {{ color: red; }}
                .risk-very-high {{ color: darkred; }}
            </style>
        </head>
        <body>
            <h1>Portfolio Risk Report</h1>
            <p>Generated on: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            
            <h2>Risk Summary</h2>
            <p>Portfolio Value: ${risk_analysis['portfolio_value']:,.2f}</p>
            <p>Risk Score: <span class="risk-{risk_analysis['risk_score']['risk_level'].replace(' ', '-')}">{risk_analysis['risk_score']['total_score']:.2f} ({risk_analysis['risk_score']['risk_level'].upper()})</span></p>
            
            <h2>Value at Risk (VaR)</h2>
            <p>Daily VaR (95%): ${risk_analysis['var']['var']:,.2f} ({risk_analysis['var']['var_percentage']:.2%} of portfolio)</p>
            <p>Status: <span class="risk-{risk_analysis['var']['status']}">{risk_analysis['var']['status'].upper()}</span></p>
            
            <h2>Conditional Value at Risk (CVaR)</h2>
            <p>Daily CVaR (95%): ${risk_analysis['cvar']['cvar']:,.2f} ({risk_analysis['cvar']['cvar_percentage']:.2%} of portfolio)</p>
            
            <h2>Stress Test Results</h2>
            <p>Worst Scenario: {risk_analysis['stress_tests']['worst_scenario']}</p>
            <p>Worst Impact: ${abs(risk_analysis['stress_tests']['worst_impact']):,.2f} ({abs(risk_analysis['stress_tests']['worst_impact']) / risk_analysis['portfolio_value']:.2%} of portfolio)</p>
            
            <h2>Portfolio Metrics</h2>
            <table>
                <tr>
                    <th>Metric</th>
                    <th>Value</th>
                </tr>
                <tr>
                    <td>Annualized Return</td>
                    <td>{risk_analysis['metrics']['annualized_return']:.2%}</td>
                </tr>
                <tr>
                    <td>Volatility</td>
                    <td>{risk_analysis['metrics']['volatility']:.2%}</td>
                </tr>
                <tr>
                    <td>Sharpe Ratio</td>
                    <td>{risk_analysis['metrics']['sharpe_ratio']:.2f}</td>
                </tr>
                <tr>
                    <td>Sortino Ratio</td>
                    <td>{risk_analysis['metrics']['sortino_ratio']:.2f}</td>
                </tr>
                <tr>
                    <td>Maximum Drawdown</td>
                    <td>{risk_analysis['metrics']['max_drawdown']:.2%}</td>
                </tr>
                <tr>
                    <td>Calmar Ratio</td>
                    <td>{risk_analysis['metrics']['calmar_ratio']:.2f}</td>
                </tr>
            </table>
            
            <h2>Concentration Analysis</h2>
            <p>Highest Asset Concentration: {risk_analysis['concentration']['highest_asset']} ({risk_analysis['concentration']['highest_asset_concentration']:.2%})</p>
            <p>Status: <span class="risk-{risk_analysis['concentration']['asset_concentration_status']}">{risk_analysis['concentration']['asset_concentration_status'].upper()}</span></p>
            
            <p>Highest Sector Concentration: {risk_analysis['concentration']['highest_sector']} ({risk_analysis['concentration']['highest_sector_concentration']:.2%})</p>
            <p>Status: <span class="risk-{risk_analysis['concentration']['sector_concentration_status']}">{risk_analysis['concentration']['sector_concentration_status'].upper()}</span></p>
            
            <h2>Risk Score Components</h2>
            <table>
                <tr>
                    <th>Component</th>
                    <th>Score</th>
                    <th>Weight</th>
                    <th>Contribution</th>
                </tr>
        """
        
        for component, score in risk_analysis['risk_score']['components'].items():
            weight = risk_analysis['risk_score']['weights'][component]
            contribution = score * weight
            html += f"""
                <tr>
                    <td>{component.replace('_', ' ').title()}</td>
                    <td>{score:.2f}</td>
                    <td>{weight:.2f}</td>
                    <td>{contribution:.2f}</td>
                </tr>
            """
        
        html += """
            </table>
        </body>
        </html>
        """
        
        return html
    
    def generate_risk_charts(self, portfolio: Dict[str, Any], chart_type: str = "var") -> Dict[str, Any]:
        """
        Generate risk visualization charts.
        
        Args:
            portfolio: Portfolio data
            chart_type: Type of chart to generate
            
        Returns:
            Chart data
        """
        logger.info(f"Generating {chart_type} chart")
        
        try:
            # Set up matplotlib
            plt.figure(figsize=(10, 6))
            
            if chart_type == "var":
                # Generate VaR chart
                chart_data = self._generate_var_chart(portfolio)
            elif chart_type == "stress_test":
                # Generate stress test chart
                chart_data = self._generate_stress_test_chart(portfolio)
            elif chart_type == "concentration":
                # Generate concentration chart
                chart_data = self._generate_concentration_chart(portfolio)
            elif chart_type == "correlation":
                # Generate correlation chart
                chart_data = self._generate_correlation_chart(portfolio)
            elif chart_type == "risk_score":
                # Generate risk score chart
                chart_data = self._generate_risk_score_chart(portfolio)
            else:
                return {
                    "success": False,
                    "error": f"Unknown chart type: {chart_type}"
                }
            
            # Save chart to buffer
            buffer = BytesIO()
            plt.savefig(buffer, format="png")
            buffer.seek(0)
            
            # Encode chart as base64
            import base64
            chart_base64 = base64.b64encode(buffer.read()).decode("utf-8")
            
            return {
                "success": True,
                "chart_type": chart_type,
                "chart_data": chart_data,
                "chart_image": chart_base64,
                "timestamp": datetime.datetime.now().isoformat()
            }
        
        except Exception as e:
            logger.error(f"Error generating risk chart: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def _generate_var_chart(self, portfolio: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a VaR chart.
        
        Args:
            portfolio: Portfolio data
            
        Returns:
            Chart data
        """
        # Get portfolio returns
        returns = self._get_portfolio_returns(portfolio)
        
        if returns is None or len(returns) < 10:
            return {
                "success": False,
                "error": "Insufficient return data"
            }
        
        # Calculate VaR at different confidence levels
        confidence_levels = [0.9, 0.95, 0.99]
        var_values = []
        
        for cl in confidence_levels:
            var_result = self.calculate_var(portfolio, confidence_level=cl)
            if var_result["success"]:
                var_values.append(var_result["var"])
            else:
                var_values.append(0)
        
        # Plot histogram of returns
        sns.histplot(returns, kde=True)
        
        # Plot VaR lines
        colors = ["green", "orange", "red"]
        
        for i, (cl, var) in enumerate(zip(confidence_levels, var_values)):
            plt.axvline(-var, color=colors[i], linestyle="--", label=f"VaR {cl:.0%}")
        
        plt.title("Portfolio Returns Distribution and VaR")
        plt.xlabel("Daily Return")
        plt.ylabel("Frequency")
        plt.legend()
        
        return {
            "confidence_levels": confidence_levels,
            "var_values": [float(v) for v in var_values]
        }
    
    def _generate_stress_test_chart(self, portfolio: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a stress test chart.
        
        Args:
            portfolio: Portfolio data
            
        Returns:
            Chart data
        """
        # Run all stress tests
        stress_test_result = self.run_all_stress_tests(portfolio)
        
        if not stress_test_result["success"]:
            return {
                "success": False,
                "error": "Failed to run stress tests"
            }
        
        # Extract scenario names and impacts
        scenarios = []
        impacts = []
        
        for scenario, result in stress_test_result["results"].items():
            scenarios.append(scenario)
            impacts.append(result["percentage_change"])
        
        # Sort by impact
        sorted_data = sorted(zip(scenarios, impacts), key=lambda x: x[1])
        scenarios, impacts = zip(*sorted_data)
        
        # Plot bar chart
        colors = ["green" if i >= 0 else "red" for i in impacts]
        plt.barh(scenarios, impacts, color=colors)
        
        plt.title("Stress Test Scenarios Impact")
        plt.xlabel("Portfolio Impact (%)")
        plt.ylabel("Scenario")
        
        # Add a vertical line at 0
        plt.axvline(0, color="black", linestyle="-", linewidth=0.5)
        
        return {
            "scenarios": scenarios,
            "impacts": [float(i) for i in impacts]
        }
    
    def _generate_concentration_chart(self, portfolio: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a concentration chart.
        
        Args:
            portfolio: Portfolio data
            
        Returns:
            Chart data
        """
        # Get portfolio value
        portfolio_value = portfolio.get("total_value", 0.0)
        
        # Calculate asset weights
        assets = portfolio.get("assets", [])
        asset_names = []
        asset_weights = []
        
        for asset in assets:
            asset_id = asset["market_id"]
            asset_value = asset["current_value"]
            asset_weight = asset_value / portfolio_value
            
            asset_names.append(asset_id)
            asset_weights.append(asset_weight)
        
        # Sort by weight
        sorted_data = sorted(zip(asset_names, asset_weights), key=lambda x: x[1], reverse=True)
        asset_names, asset_weights = zip(*sorted_data)
        
        # Plot pie chart
        plt.pie(asset_weights, labels=asset_names, autopct="%1.1f%%")
        plt.title("Portfolio Asset Allocation")
        
        return {
            "asset_names": asset_names,
            "asset_weights": [float(w) for w in asset_weights]
        }
    
    def _generate_correlation_chart(self, portfolio: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a correlation chart.
        
        Args:
            portfolio: Portfolio data
            
        Returns:
            Chart data
        """
        # In a real implementation, we would:
        # 1. Get historical returns for all assets
        # 2. Calculate correlation matrix
        # 3. Plot correlation heatmap
        
        # For now, generate a placeholder correlation matrix
        assets = portfolio.get("assets", [])
        asset_ids = [asset["market_id"] for asset in assets]
        
        n = len(asset_ids)
        correlation_matrix = np.random.uniform(-0.5, 1.0, (n, n))
        
        # Make the matrix symmetric
        correlation_matrix = (correlation_matrix + correlation_matrix.T) / 2
        
        # Set diagonal to 1
        np.fill_diagonal(correlation_matrix, 1.0)
        
        # Plot correlation heatmap
        sns.heatmap(correlation_matrix, annot=True, cmap="coolwarm", vmin=-1, vmax=1, xticklabels=asset_ids, yticklabels=asset_ids)
        plt.title("Asset Correlation Matrix")
        
        return {
            "asset_ids": asset_ids,
            "correlation_matrix": correlation_matrix.tolist()
        }
    
    def _generate_risk_score_chart(self, portfolio: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a risk score chart.
        
        Args:
            portfolio: Portfolio data
            
        Returns:
            Chart data
        """
        # Analyze portfolio risk
        risk_analysis = self.analyze_portfolio_risk(portfolio)
        
        if not risk_analysis["success"]:
            return {
                "success": False,
                "error": "Failed to analyze portfolio risk"
            }
        
        # Extract risk score components
        components = []
        scores = []
        
        for component, score in risk_analysis["risk_score"]["components"].items():
            components.append(component.replace("_", " ").title())
            scores.append(score)
        
        # Plot radar chart
        angles = np.linspace(0, 2*np.pi, len(components), endpoint=False).tolist()
        angles += angles[:1]  # Close the loop
        
        scores += scores[:1]  # Close the loop
        
        fig, ax = plt.subplots(figsize=(10, 6), subplot_kw={"polar": True})
        ax.plot(angles, scores, "o-", linewidth=2)
        ax.fill(angles, scores, alpha=0.25)
        ax.set_thetagrids(np.degrees(angles[:-1]), components)
        
        ax.set_ylim(0, 10)
        ax.set_title("Risk Score Components")
        
        return {
            "components": components,
            "scores": [float(s) for s in scores[:-1]],
            "total_score": float(risk_analysis["risk_score"]["total_score"]),
            "risk_level": risk_analysis["risk_score"]["risk_level"]
        }
    
    def _get_portfolio_returns(self, portfolio: Dict[str, Any]) -> np.ndarray:
        """
        Get historical returns for a portfolio.
        
        Args:
            portfolio: Portfolio data
            
        Returns:
            Array of historical returns
        """
        # In a real implementation, we would:
        # 1. Get historical prices for all assets
        # 2. Calculate portfolio returns based on asset weights
        
        # For now, generate random returns
        np.random.seed(42)  # For reproducibility
        return np.random.normal(0.0005, 0.01, 252)  # 1 year of daily returns
    
    def _determine_asset_type(self, market_id: str) -> str:
        """
        Determine the type of an asset based on its market ID.
        
        Args:
            market_id: Market ID
            
        Returns:
            Asset type
        """
        if market_id.endswith("USD") or market_id.endswith("USDT") or market_id.endswith("BTC"):
            return "crypto"
        elif market_id in ["GLD", "SLV", "USO", "UNG"]:
            return "commodities"
        elif market_id in ["TLT", "IEF", "SHY", "AGG"]:
            return "bonds"
        elif market_id in ["EUR/USD", "GBP/USD", "USD/JPY", "USD/CAD"]:
            return "forex"
        else:
            return "stocks"
    
    def _determine_asset_sector(self, market_id: str) -> str:
        """
        Determine the sector of an asset based on its market ID.
        
        Args:
            market_id: Market ID
            
        Returns:
            Asset sector
        """
        # Technology stocks
        if market_id in ["AAPL", "MSFT", "GOOGL", "AMZN", "META", "TSLA", "NVDA"]:
            return "technology"
        
        # Financial stocks
        elif market_id in ["JPM", "BAC", "WFC", "C", "GS", "MS", "V", "MA"]:
            return "finance"
        
        # Healthcare stocks
        elif market_id in ["JNJ", "PFE", "MRK", "ABBV", "UNH", "CVS"]:
            return "healthcare"
        
        # Energy stocks
        elif market_id in ["XOM", "CVX", "COP", "BP", "SLB"]:
            return "energy"
        
        # Consumer stocks
        elif market_id in ["WMT", "PG", "KO", "PEP", "MCD", "SBUX", "NKE"]:
            return "consumer"
        
        # Cryptocurrency
        elif market_id.endswith("USD") or market_id.endswith("USDT") or market_id.endswith("BTC"):
            return "crypto"
        
        # Commodities
        elif market_id in ["GLD", "SLV", "USO", "UNG"]:
            return "commodities"
        
        # Bonds
        elif market_id in ["TLT", "IEF", "SHY", "AGG"]:
            return "bonds"
        
        # Forex
        elif market_id in ["EUR/USD", "GBP/USD", "USD/JPY", "USD/CAD"]:
            return "forex"
        
        # Default
        else:
            return "other"
    
    def _log_risk_event(self, event_type: str, details: Dict[str, Any]):
        """
        Log a risk event.
        
        Args:
            event_type: Type of risk event
            details: Details of the event
        """
        event = {
            "id": generate_id(),
            "type": event_type,
            "timestamp": datetime.datetime.now().isoformat(),
            "details": details
        }
        
        # Add to in-memory log
        self.risk_events.append(event)
        
        # Log to file
        logger.info(f"Risk event: {event_type}")
        
        # Save to database if available
        if self.database:
            self.database.save_execution(
                "advanced_risk_manager",
                event["id"],
                event
            )
    
    def get_risk_events(self, filters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """
        Get risk events.
        
        Args:
            filters: Filters to apply
            
        Returns:
            List of risk events
        """
        if filters is None:
            filters = {}
        
        # Apply filters
        filtered_events = self.risk_events
        
        if "type" in filters:
            filtered_events = [e for e in filtered_events if e["type"] == filters["type"]]
        
        if "start_time" in filters:
            start_time = datetime.datetime.fromisoformat(filters["start_time"])
            filtered_events = [e for e in filtered_events if datetime.datetime.fromisoformat(e["timestamp"]) >= start_time]
        
        if "end_time" in filters:
            end_time = datetime.datetime.fromisoformat(filters["end_time"])
            filtered_events = [e for e in filtered_events if datetime.datetime.fromisoformat(e["timestamp"]) <= end_time]
        
        return filtered_events
    
    def update_risk_limits(self, new_limits: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update risk limits.
        
        Args:
            new_limits: New risk limits
            
        Returns:
            Updated risk limits
        """
        # Update limits
        for key, value in new_limits.items():
            if key in self.risk_limits:
                self.risk_limits[key] = value
        
        logger.info(f"Risk limits updated")
        
        return self.risk_limits
    
    def get_risk_limits(self) -> Dict[str, Any]:
        """
        Get current risk limits.
        
        Returns:
            Current risk limits
        """
        return self.risk_limits
