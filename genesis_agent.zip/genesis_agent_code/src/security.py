"""
Genesis Agent Security Module
--------------------------
This module handles security and risk management for the Genesis Agent.
"""

import os
import logging
import datetime
import json
import hashlib
import secrets
import base64
import re
from typing import Dict, List, Any, Optional, Union
import time
from concurrent.futures import ThreadPoolExecutor

from . import config
from .utils import generate_id

# Configure logging
logger = logging.getLogger('genesis_agent.security')

class SecurityManager:
    """
    Handles security and risk management for the Genesis Agent.
    
    This class provides methods for authentication, encryption, access control,
    and risk management.
    """
    
    def __init__(self, database=None):
        """
        Initialize the security manager.
        
        Args:
            database: Database manager for storing security data
        """
        self.database = database
        self.auth_tokens = {}
        self.access_rules = self._initialize_access_rules()
        self.risk_limits = self._initialize_risk_limits()
        self.security_events = []
        
        logger.info("Security manager initialized")
    
    def _initialize_access_rules(self) -> Dict[str, Any]:
        """Initialize access control rules."""
        return {
            "trading": {
                "execute_trade": ["admin", "trader"],
                "view_portfolio": ["admin", "trader", "analyst", "viewer"],
                "create_strategy": ["admin", "trader", "analyst"]
            },
            "analysis": {
                "analyze_market": ["admin", "trader", "analyst", "viewer"],
                "create_strategy": ["admin", "trader", "analyst"]
            },
            "admin": {
                "manage_users": ["admin"],
                "configure_system": ["admin"],
                "view_logs": ["admin"]
            }
        }
    
    def _initialize_risk_limits(self) -> Dict[str, Any]:
        """Initialize risk management limits."""
        return {
            "max_trade_size": config.MAX_TRADE_SIZE if hasattr(config, 'MAX_TRADE_SIZE') else 10000.0,
            "max_daily_volume": config.MAX_DAILY_VOLUME if hasattr(config, 'MAX_DAILY_VOLUME') else 50000.0,
            "max_position_size": config.MAX_POSITION_SIZE if hasattr(config, 'MAX_POSITION_SIZE') else 0.2,
            "max_leverage": config.MAX_LEVERAGE if hasattr(config, 'MAX_LEVERAGE') else 2.0,
            "max_drawdown": config.MAX_DRAWDOWN if hasattr(config, 'MAX_DRAWDOWN') else 0.1,
            "max_concentration": config.MAX_CONCENTRATION if hasattr(config, 'MAX_CONCENTRATION') else 0.25
        }
    
    def authenticate(self, credentials: Dict[str, str]) -> Dict[str, Any]:
        """
        Authenticate a user.
        
        Args:
            credentials: User credentials (username, password)
            
        Returns:
            Authentication result with token if successful
        """
        username = credentials.get("username")
        password = credentials.get("password")
        
        if not username or not password:
            logger.warning("Authentication attempt with missing credentials")
            return {
                "success": False,
                "error": "Missing credentials"
            }
        
        # In a real implementation, we would verify against stored credentials
        # For now, use a simple placeholder
        if username == "admin" and password == "admin":
            # Generate token
            token = self._generate_auth_token(username)
            
            # Store token
            self.auth_tokens[token] = {
                "username": username,
                "role": "admin",
                "created_at": datetime.datetime.now().isoformat(),
                "expires_at": (datetime.datetime.now() + datetime.timedelta(hours=24)).isoformat()
            }
            
            logger.info(f"User {username} authenticated successfully")
            
            return {
                "success": True,
                "token": token,
                "username": username,
                "role": "admin",
                "expires_at": self.auth_tokens[token]["expires_at"]
            }
        
        elif username == "trader" and password == "trader":
            # Generate token
            token = self._generate_auth_token(username)
            
            # Store token
            self.auth_tokens[token] = {
                "username": username,
                "role": "trader",
                "created_at": datetime.datetime.now().isoformat(),
                "expires_at": (datetime.datetime.now() + datetime.timedelta(hours=24)).isoformat()
            }
            
            logger.info(f"User {username} authenticated successfully")
            
            return {
                "success": True,
                "token": token,
                "username": username,
                "role": "trader",
                "expires_at": self.auth_tokens[token]["expires_at"]
            }
        
        logger.warning(f"Failed authentication attempt for user {username}")
        
        return {
            "success": False,
            "error": "Invalid credentials"
        }
    
    def _generate_auth_token(self, username: str) -> str:
        """
        Generate an authentication token.
        
        Args:
            username: Username to generate token for
            
        Returns:
            Authentication token
        """
        # Generate a random token
        token_bytes = secrets.token_bytes(32)
        token = base64.urlsafe_b64encode(token_bytes).decode('utf-8')
        
        return token
    
    def verify_token(self, token: str) -> Dict[str, Any]:
        """
        Verify an authentication token.
        
        Args:
            token: Authentication token to verify
            
        Returns:
            Verification result
        """
        if not token:
            return {
                "success": False,
                "error": "Missing token"
            }
        
        if token not in self.auth_tokens:
            return {
                "success": False,
                "error": "Invalid token"
            }
        
        token_info = self.auth_tokens[token]
        
        # Check if token has expired
        expires_at = datetime.datetime.fromisoformat(token_info["expires_at"])
        if expires_at < datetime.datetime.now():
            # Remove expired token
            self.auth_tokens.pop(token)
            
            return {
                "success": False,
                "error": "Token expired"
            }
        
        return {
            "success": True,
            "username": token_info["username"],
            "role": token_info["role"]
        }
    
    def check_access(self, token: str, module: str, action: str) -> Dict[str, Any]:
        """
        Check if a user has access to perform an action.
        
        Args:
            token: Authentication token
            module: Module to access
            action: Action to perform
            
        Returns:
            Access check result
        """
        # Verify token
        token_result = self.verify_token(token)
        
        if not token_result["success"]:
            return token_result
        
        # Get user role
        role = token_result["role"]
        
        # Check if module exists
        if module not in self.access_rules:
            return {
                "success": False,
                "error": f"Unknown module: {module}"
            }
        
        # Check if action exists
        if action not in self.access_rules[module]:
            return {
                "success": False,
                "error": f"Unknown action: {action}"
            }
        
        # Check if role has access
        allowed_roles = self.access_rules[module][action]
        
        if role in allowed_roles:
            return {
                "success": True,
                "username": token_result["username"],
                "role": role
            }
        
        return {
            "success": False,
            "error": f"Access denied: {role} cannot perform {action} in {module}"
        }
    
    def encrypt_data(self, data: str) -> str:
        """
        Encrypt sensitive data.
        
        Args:
            data: Data to encrypt
            
        Returns:
            Encrypted data
        """
        # In a real implementation, we would use proper encryption
        # For now, use a simple placeholder
        
        # Convert to bytes
        data_bytes = data.encode('utf-8')
        
        # Generate a random key
        key = secrets.token_bytes(32)
        
        # XOR with key (not secure, just a placeholder)
        encrypted_bytes = bytes(a ^ b for a, b in zip(data_bytes, key * (len(data_bytes) // len(key) + 1)))
        
        # Encode as base64
        encrypted = base64.b64encode(encrypted_bytes).decode('utf-8')
        
        return encrypted
    
    def decrypt_data(self, encrypted: str) -> str:
        """
        Decrypt sensitive data.
        
        Args:
            encrypted: Encrypted data
            
        Returns:
            Decrypted data
        """
        # In a real implementation, we would use proper decryption
        # For now, return a placeholder
        
        return "decrypted_data"
    
    def hash_password(self, password: str) -> str:
        """
        Hash a password.
        
        Args:
            password: Password to hash
            
        Returns:
            Hashed password
        """
        # Generate a random salt
        salt = secrets.token_hex(16)
        
        # Hash password with salt
        hashed = hashlib.sha256((password + salt).encode('utf-8')).hexdigest()
        
        # Return salt and hash
        return f"{salt}:{hashed}"
    
    def verify_password(self, password: str, hashed: str) -> bool:
        """
        Verify a password against a hash.
        
        Args:
            password: Password to verify
            hashed: Hashed password
            
        Returns:
            True if password matches hash, False otherwise
        """
        # Split salt and hash
        salt, hash_value = hashed.split(':')
        
        # Hash password with salt
        computed_hash = hashlib.sha256((password + salt).encode('utf-8')).hexdigest()
        
        # Compare hashes
        return computed_hash == hash_value
    
    def sanitize_input(self, input_str: str) -> str:
        """
        Sanitize user input to prevent injection attacks.
        
        Args:
            input_str: Input string to sanitize
            
        Returns:
            Sanitized input string
        """
        # Remove potentially dangerous characters
        sanitized = re.sub(r'[<>\'";]', '', input_str)
        
        return sanitized
    
    def validate_trade(self, trade_params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate a trade against risk limits.
        
        Args:
            trade_params: Parameters for the trade
            
        Returns:
            Validation result
        """
        trade_type = trade_params.get("type")
        market_id = trade_params.get("market_id")
        quantity = trade_params.get("quantity")
        price = trade_params.get("price")
        
        if not market_id or not quantity:
            return {
                "success": False,
                "error": "Missing required parameters"
            }
        
        try:
            # Convert to float
            quantity = float(quantity)
            price = float(price) if price else 0.0
            
            # Calculate trade value
            trade_value = quantity * price
            
            # Check against max trade size
            if trade_value > self.risk_limits["max_trade_size"]:
                return {
                    "success": False,
                    "error": f"Trade value ({trade_value}) exceeds maximum ({self.risk_limits['max_trade_size']})"
                }
            
            # In a real implementation, we would check other risk limits
            # such as daily volume, position size, etc.
            
            return {
                "success": True
            }
        
        except Exception as e:
            logger.error(f"Error validating trade: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def log_security_event(self, event_type: str, details: Dict[str, Any]):
        """
        Log a security event.
        
        Args:
            event_type: Type of security event
            details: Details of the event
        """
        event = {
            "id": generate_id(),
            "type": event_type,
            "timestamp": datetime.datetime.now().isoformat(),
            "details": details
        }
        
        # Add to in-memory log
        self.security_events.append(event)
        
        # Log to file
        logger.info(f"Security event: {event_type} - {json.dumps(details)}")
        
        # Save to database if available
        if self.database:
            self.database.save_execution(
                "security_manager",
                event["id"],
                event
            )
    
    def get_security_events(self, filters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """
        Get security events.
        
        Args:
            filters: Filters to apply
            
        Returns:
            List of security events
        """
        if filters is None:
            filters = {}
        
        # Apply filters
        filtered_events = self.security_events
        
        if "type" in filters:
            filtered_events = [e for e in filtered_events if e["type"] == filters["type"]]
        
        if "start_time" in filters:
            start_time = datetime.datetime.fromisoformat(filters["start_time"])
            filtered_events = [e for e in filtered_events if datetime.datetime.fromisoformat(e["timestamp"]) >= start_time]
        
        if "end_time" in filters:
            end_time = datetime.datetime.fromisoformat(filters["end_time"])
            filtered_events = [e for e in filtered_events if datetime.datetime.fromisoformat(e["timestamp"]) <= end_time]
        
        return filtered_events
    
    def update_risk_limits(self, new_limits: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update risk management limits.
        
        Args:
            new_limits: New risk limits
            
        Returns:
            Updated risk limits
        """
        # Update limits
        for key, value in new_limits.items():
            if key in self.risk_limits:
                self.risk_limits[key] = value
        
        logger.info(f"Risk limits updated: {json.dumps(self.risk_limits)}")
        
        return self.risk_limits
    
    def get_risk_limits(self) -> Dict[str, Any]:
        """
        Get current risk management limits.
        
        Returns:
            Current risk limits
        """
        return self.risk_limits


class RiskManager:
    """
    Manages risk for the Genesis Agent.
    
    This class provides methods for risk assessment, monitoring, and mitigation.
    """
    
    def __init__(self, security_manager: SecurityManager = None, database=None):
        """
        Initialize the risk manager.
        
        Args:
            security_manager: Security manager instance
            database: Database manager for storing risk data
        """
        self.security_manager = security_manager
        self.database = database
        self.risk_models = self._initialize_risk_models()
        self.risk_events = []
        self.risk_metrics = {
            "portfolio_var": 0.0,
            "max_drawdown": 0.0,
            "sharpe_ratio": 0.0,
            "volatility": 0.0
        }
        
        logger.info("Risk manager initialized")
    
    def _initialize_risk_models(self) -> Dict[str, Any]:
        """Initialize risk models."""
        return {
            "var": {
                "name": "Value at Risk",
                "confidence_level": 0.95,
                "time_horizon": 1  # days
            },
            "stress_test": {
                "name": "Stress Test",
                "scenarios": [
                    {
                        "name": "Market Crash",
                        "asset_changes": {
                            "stocks": -0.3,
                            "bonds": 0.05,
                            "crypto": -0.5,
                            "commodities": -0.2
                        }
                    },
                    {
                        "name": "Interest Rate Spike",
                        "asset_changes": {
                            "stocks": -0.1,
                            "bonds": -0.15,
                            "crypto": -0.05,
                            "commodities": 0.1
                        }
                    }
                ]
            }
        }
    
    def assess_portfolio_risk(self, portfolio: Dict[str, Any]) -> Dict[str, Any]:
        """
        Assess risk for a portfolio.
        
        Args:
            portfolio: Portfolio to assess
            
        Returns:
            Risk assessment results
        """
        try:
            # Calculate Value at Risk (VaR)
            var = self._calculate_var(portfolio)
            
            # Run stress tests
            stress_test_results = self._run_stress_tests(portfolio)
            
            # Calculate other risk metrics
            volatility = self._calculate_volatility(portfolio)
            max_drawdown = self._calculate_max_drawdown(portfolio)
            sharpe_ratio = self._calculate_sharpe_ratio(portfolio)
            
            # Update risk metrics
            self.risk_metrics = {
                "portfolio_var": var,
                "max_drawdown": max_drawdown,
                "sharpe_ratio": sharpe_ratio,
                "volatility": volatility
            }
            
            # Compile results
            results = {
                "var": var,
                "stress_tests": stress_test_results,
                "volatility": volatility,
                "max_drawdown": max_drawdown,
                "sharpe_ratio": sharpe_ratio,
                "timestamp": datetime.datetime.now().isoformat()
            }
            
            # Log risk assessment
            self._log_risk_event("portfolio_assessment", results)
            
            return results
        
        except Exception as e:
            logger.error(f"Error assessing portfolio risk: {str(e)}")
            return {"error": str(e)}
    
    def _calculate_var(self, portfolio: Dict[str, Any]) -> float:
        """
        Calculate Value at Risk (VaR) for a portfolio.
        
        Args:
            portfolio: Portfolio to calculate VaR for
            
        Returns:
            VaR value
        """
        # In a real implementation, we would use historical data or Monte Carlo simulation
        # For now, use a simple placeholder
        
        # Get portfolio value
        portfolio_value = portfolio.get("total_value", 0.0)
        
        # Assume a normal distribution with a standard deviation of 2% daily
        import scipy.stats as stats
        
        confidence_level = self.risk_models["var"]["confidence_level"]
        time_horizon = self.risk_models["var"]["time_horizon"]
        
        # Calculate VaR
        var = portfolio_value * 0.02 * np.sqrt(time_horizon) * stats.norm.ppf(confidence_level)
        
        return float(var)
    
    def _run_stress_tests(self, portfolio: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Run stress tests on a portfolio.
        
        Args:
            portfolio: Portfolio to stress test
            
        Returns:
            Stress test results
        """
        results = []
        
        # Get portfolio assets
        assets = portfolio.get("assets", [])
        
        # Run each scenario
        for scenario in self.risk_models["stress_test"]["scenarios"]:
            scenario_name = scenario["name"]
            asset_changes = scenario["asset_changes"]
            
            # Calculate impact
            total_impact = 0.0
            
            for asset in assets:
                market_id = asset["market_id"]
                current_value = asset["current_value"]
                
                # Determine asset type
                asset_type = "stocks"  # Default
                
                if market_id.endswith("USD") or market_id.endswith("USDT") or market_id.endswith("BTC"):
                    asset_type = "crypto"
                elif market_id in ["GLD", "SLV", "USO", "UNG"]:
                    asset_type = "commodities"
                elif market_id in ["TLT", "IEF", "SHY", "AGG"]:
                    asset_type = "bonds"
                
                # Apply change
                if asset_type in asset_changes:
                    impact = current_value * asset_changes[asset_type]
                    total_impact += impact
            
            # Calculate new portfolio value
            new_value = portfolio.get("total_value", 0.0) + total_impact
            percent_change = (new_value / portfolio.get("total_value", 1.0) - 1) * 100
            
            results.append({
                "scenario": scenario_name,
                "impact": total_impact,
                "new_value": new_value,
                "percent_change": percent_change
            })
        
        return results
    
    def _calculate_volatility(self, portfolio: Dict[str, Any]) -> float:
        """
        Calculate portfolio volatility.
        
        Args:
            portfolio: Portfolio to calculate volatility for
            
        Returns:
            Volatility value
        """
        # In a real implementation, we would use historical returns
        # For now, use a simple placeholder
        return 0.15  # 15% annualized volatility
    
    def _calculate_max_drawdown(self, portfolio: Dict[str, Any]) -> float:
        """
        Calculate maximum drawdown.
        
        Args:
            portfolio: Portfolio to calculate max drawdown for
            
        Returns:
            Max drawdown value
        """
        # In a real implementation, we would use historical values
        # For now, use a simple placeholder
        return 0.12  # 12% maximum drawdown
    
    def _calculate_sharpe_ratio(self, portfolio: Dict[str, Any]) -> float:
        """
        Calculate Sharpe ratio.
        
        Args:
            portfolio: Portfolio to calculate Sharpe ratio for
            
        Returns:
            Sharpe ratio value
        """
        # In a real implementation, we would use historical returns
        # For now, use a simple placeholder
        return 1.2  # Sharpe ratio of 1.2
    
    def validate_trade(self, trade_params: Dict[str, Any], portfolio: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate a trade against risk limits.
        
        Args:
            trade_params: Parameters for the trade
            portfolio: Current portfolio
            
        Returns:
            Validation result
        """
        # First, use security manager to validate basic limits
        if self.security_manager:
            security_validation = self.security_manager.validate_trade(trade_params)
            
            if not security_validation["success"]:
                return security_validation
        
        trade_type = trade_params.get("type")
        market_id = trade_params.get("market_id")
        quantity = float(trade_params.get("quantity", 0))
        price = float(trade_params.get("price", 0))
        
        # Calculate trade value
        trade_value = quantity * price
        
        # Get portfolio value
        portfolio_value = portfolio.get("total_value", 0.0)
        
        try:
            # Check position concentration
            if trade_type == "buy":
                # Find existing position
                existing_position = 0.0
                for asset in portfolio.get("assets", []):
                    if asset["market_id"] == market_id:
                        existing_position = asset["current_value"]
                        break
                
                # Calculate new position
                new_position = existing_position + trade_value
                
                # Check concentration
                concentration = new_position / portfolio_value
                
                if concentration > self.security_manager.risk_limits["max_concentration"]:
                    return {
                        "success": False,
                        "error": f"Position concentration ({concentration:.2%}) exceeds maximum ({self.security_manager.risk_limits['max_concentration']:.2%})"
                    }
            
            # Check impact on portfolio risk
            # In a real implementation, we would simulate the trade and recalculate risk metrics
            
            return {
                "success": True
            }
        
        except Exception as e:
            logger.error(f"Error validating trade against risk limits: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def _log_risk_event(self, event_type: str, details: Dict[str, Any]):
        """
        Log a risk event.
        
        Args:
            event_type: Type of risk event
            details: Details of the event
        """
        event = {
            "id": generate_id(),
            "type": event_type,
            "timestamp": datetime.datetime.now().isoformat(),
            "details": details
        }
        
        # Add to in-memory log
        self.risk_events.append(event)
        
        # Log to file
        logger.info(f"Risk event: {event_type} - {json.dumps(details)}")
        
        # Save to database if available
        if self.database:
            self.database.save_execution(
                "risk_manager",
                event["id"],
                event
            )
    
    def get_risk_events(self, filters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """
        Get risk events.
        
        Args:
            filters: Filters to apply
            
        Returns:
            List of risk events
        """
        if filters is None:
            filters = {}
        
        # Apply filters
        filtered_events = self.risk_events
        
        if "type" in filters:
            filtered_events = [e for e in filtered_events if e["type"] == filters["type"]]
        
        if "start_time" in filters:
            start_time = datetime.datetime.fromisoformat(filters["start_time"])
            filtered_events = [e for e in filtered_events if datetime.datetime.fromisoformat(e["timestamp"]) >= start_time]
        
        if "end_time" in filters:
            end_time = datetime.datetime.fromisoformat(filters["end_time"])
            filtered_events = [e for e in filtered_events if datetime.datetime.fromisoformat(e["timestamp"]) <= end_time]
        
        return filtered_events
    
    def get_risk_metrics(self) -> Dict[str, Any]:
        """
        Get current risk metrics.
        
        Returns:
            Current risk metrics
        """
        return self.risk_metrics
