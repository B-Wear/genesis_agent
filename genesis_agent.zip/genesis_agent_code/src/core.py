"""
Genesis Agent Core Module
------------------------
This module contains the core functionality of the Genesis Agent system.
"""

import os
import logging
import datetime
import json
import uuid
import threading
import time
from typing import Dict, List, Any, Optional, Union

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
import tensorflow as tf

from . import config
from .database import DatabaseManager
from .models import ModelManager
from .trading import TradingEngine
from .analysis import AnalysisEngine
from .security import SecurityManager
from .utils import encrypt_data, decrypt_data, generate_id

# Configure logging
logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(config.LOGS_DIR, 'genesis_agent.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('genesis_agent.core')

class GenesisAgent:
    """
    Main class for the Genesis Agent system.
    
    This class orchestrates all components of the system and provides
    the main interface for interacting with the Genesis Agent.
    """
    
    def __init__(self, user_id: str = None, initialize: bool = True):
        """
        Initialize the Genesis Agent.
        
        Args:
            user_id: Unique identifier for the user
            initialize: Whether to initialize all components
        """
        self.agent_id = generate_id()
        self.user_id = user_id
        self.start_time = datetime.datetime.now()
        self.status = "initializing"
        self.components = {}
        self.tasks = {}
        self.active_strategies = {}
        self.performance_metrics = {}
        self.last_update = self.start_time
        
        logger.info(f"Initializing Genesis Agent {self.agent_id} for user {self.user_id}")
        
        # Initialize components if requested
        if initialize:
            self._initialize_components()
            self.status = "ready"
            logger.info(f"Genesis Agent {self.agent_id} initialized and ready")
    
    def _initialize_components(self):
        """Initialize all components of the Genesis Agent."""
        try:
            # Initialize database connection
            self.db = DatabaseManager()
            self.components["database"] = {"status": "connected", "type": self.db.db_type}
            
            # Initialize security manager
            self.security = SecurityManager()
            self.components["security"] = {"status": "active"}
            
            # Initialize model manager
            self.models = ModelManager()
            self.components["models"] = {"status": "loaded", "count": self.models.count}
            
            # Initialize analysis engine
            self.analysis = AnalysisEngine(self.models)
            self.components["analysis"] = {"status": "ready"}
            
            # Initialize trading engine if enabled
            if config.TRADING_ENABLED:
                self.trading = TradingEngine(self.analysis, self.db)
                self.components["trading"] = {"status": "ready", "enabled": True}
            else:
                self.components["trading"] = {"status": "disabled", "enabled": False}
            
            # Start monitoring thread if enabled
            if config.ENABLE_MONITORING:
                self._start_monitoring()
                self.components["monitoring"] = {"status": "active"}
            
            logger.info("All components initialized successfully")
        except Exception as e:
            logger.error(f"Error initializing components: {str(e)}")
            self.status = "error"
            raise
    
    def _start_monitoring(self):
        """Start the monitoring thread."""
        self.monitoring_active = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop)
        self.monitoring_thread.daemon = True
        self.monitoring_thread.start()
        logger.info("Monitoring thread started")
    
    def _monitoring_loop(self):
        """Main monitoring loop that runs in a separate thread."""
        while self.monitoring_active:
            try:
                # Update performance metrics
                self._update_performance_metrics()
                
                # Check system health
                self._check_system_health()
                
                # Update status
                self.last_update = datetime.datetime.now()
                
                # Sleep for the configured interval
                time.sleep(config.MONITORING_INTERVAL)
            except Exception as e:
                logger.error(f"Error in monitoring loop: {str(e)}")
                time.sleep(config.MONITORING_INTERVAL * 2)  # Sleep longer on error
    
    def _update_performance_metrics(self):
        """Update performance metrics for the agent."""
        now = datetime.datetime.now()
        uptime = (now - self.start_time).total_seconds()
        
        # Basic system metrics
        self.performance_metrics["uptime"] = uptime
        self.performance_metrics["last_update"] = now.isoformat()
        
        # Component-specific metrics
        if "trading" in self.components and self.components["trading"]["enabled"]:
            self.performance_metrics["trading"] = self.trading.get_performance_metrics()
        
        if "analysis" in self.components:
            self.performance_metrics["analysis"] = self.analysis.get_performance_metrics()
        
        # Save metrics to database
        if hasattr(self, 'db'):
            self.db.save_metrics(self.agent_id, self.performance_metrics)
    
    def _check_system_health(self):
        """Check the health of all system components."""
        all_healthy = True
        
        # Check database connection
        if hasattr(self, 'db'):
            db_health = self.db.check_health()
            self.components["database"]["status"] = "connected" if db_health else "error"
            all_healthy = all_healthy and db_health
        
        # Check model manager
        if hasattr(self, 'models'):
            model_health = self.models.check_health()
            self.components["models"]["status"] = "loaded" if model_health else "error"
            all_healthy = all_healthy and model_health
        
        # Update overall status
        if all_healthy:
            if self.status == "error":
                logger.info("System recovered from error state")
            self.status = "ready"
        else:
            if self.status != "error":
                logger.warning("System entered error state")
            self.status = "error"
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get the current status of the Genesis Agent.
        
        Returns:
            Dict containing status information
        """
        return {
            "agent_id": self.agent_id,
            "user_id": self.user_id,
            "status": self.status,
            "uptime": (datetime.datetime.now() - self.start_time).total_seconds(),
            "components": self.components,
            "active_strategies": list(self.active_strategies.keys()),
            "last_update": self.last_update.isoformat()
        }
    
    def analyze_market(self, market_id: str, timeframe: str = "1d", limit: int = 100) -> Dict[str, Any]:
        """
        Analyze a specific market.
        
        Args:
            market_id: Identifier for the market (e.g., "BTCUSD", "AAPL")
            timeframe: Timeframe for analysis (e.g., "1m", "1h", "1d")
            limit: Number of data points to analyze
            
        Returns:
            Dict containing analysis results
        """
        logger.info(f"Analyzing market {market_id} on {timeframe} timeframe")
        
        if not hasattr(self, 'analysis'):
            logger.error("Analysis engine not initialized")
            return {"error": "Analysis engine not initialized"}
        
        try:
            # Perform the analysis
            results = self.analysis.analyze_market(market_id, timeframe, limit)
            
            # Log the completion
            logger.info(f"Analysis of {market_id} completed successfully")
            
            # Save results to database
            if hasattr(self, 'db'):
                self.db.save_analysis(self.agent_id, market_id, results)
            
            return results
        except Exception as e:
            logger.error(f"Error analyzing market {market_id}: {str(e)}")
            return {"error": str(e)}
    
    def create_strategy(self, strategy_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create a new trading or analysis strategy.
        
        Args:
            strategy_config: Configuration for the strategy
            
        Returns:
            Dict containing strategy information
        """
        strategy_id = generate_id()
        strategy_type = strategy_config.get("type", "unknown")
        
        logger.info(f"Creating {strategy_type} strategy with ID {strategy_id}")
        
        try:
            # Validate the strategy configuration
            if strategy_type == "trading" and not config.TRADING_ENABLED:
                return {"error": "Trading is disabled in configuration"}
            
            # Create the strategy based on type
            if strategy_type == "trading":
                strategy = self.trading.create_strategy(strategy_config)
            elif strategy_type == "analysis":
                strategy = self.analysis.create_strategy(strategy_config)
            else:
                return {"error": f"Unknown strategy type: {strategy_type}"}
            
            # Store the strategy
            self.active_strategies[strategy_id] = {
                "type": strategy_type,
                "config": strategy_config,
                "created_at": datetime.datetime.now().isoformat(),
                "status": "active",
                "strategy": strategy
            }
            
            # Save to database
            if hasattr(self, 'db'):
                self.db.save_strategy(self.agent_id, strategy_id, {
                    "type": strategy_type,
                    "config": strategy_config,
                    "created_at": datetime.datetime.now().isoformat(),
                    "status": "active"
                })
            
            logger.info(f"Strategy {strategy_id} created successfully")
            
            return {
                "strategy_id": strategy_id,
                "type": strategy_type,
                "status": "active"
            }
        except Exception as e:
            logger.error(f"Error creating strategy: {str(e)}")
            return {"error": str(e)}
    
    def execute_strategy(self, strategy_id: str, parameters: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Execute a specific strategy.
        
        Args:
            strategy_id: ID of the strategy to execute
            parameters: Additional parameters for execution
            
        Returns:
            Dict containing execution results
        """
        if strategy_id not in self.active_strategies:
            logger.error(f"Strategy {strategy_id} not found")
            return {"error": f"Strategy {strategy_id} not found"}
        
        strategy_info = self.active_strategies[strategy_id]
        logger.info(f"Executing {strategy_info['type']} strategy {strategy_id}")
        
        try:
            # Execute the strategy based on type
            if strategy_info['type'] == "trading":
                results = self.trading.execute_strategy(strategy_info['strategy'], parameters)
            elif strategy_info['type'] == "analysis":
                results = self.analysis.execute_strategy(strategy_info['strategy'], parameters)
            else:
                return {"error": f"Unknown strategy type: {strategy_info['type']}"}
            
            # Update strategy status
            self.active_strategies[strategy_id]["last_executed"] = datetime.datetime.now().isoformat()
            self.active_strategies[strategy_id]["last_results"] = results
            
            # Save execution results to database
            if hasattr(self, 'db'):
                self.db.save_execution(self.agent_id, strategy_id, results)
            
            logger.info(f"Strategy {strategy_id} executed successfully")
            
            return {
                "strategy_id": strategy_id,
                "execution_time": datetime.datetime.now().isoformat(),
                "results": results
            }
        except Exception as e:
            logger.error(f"Error executing strategy {strategy_id}: {str(e)}")
            return {"error": str(e)}
    
    def get_portfolio_status(self) -> Dict[str, Any]:
        """
        Get the current status of the investment portfolio.
        
        Returns:
            Dict containing portfolio information
        """
        if not config.TRADING_ENABLED or not hasattr(self, 'trading'):
            logger.warning("Trading is disabled, cannot get portfolio status")
            return {"error": "Trading is disabled"}
        
        try:
            portfolio = self.trading.get_portfolio()
            
            # Calculate additional metrics
            portfolio["total_value"] = sum(asset["current_value"] for asset in portfolio["assets"])
            portfolio["profit_loss"] = sum(asset["profit_loss"] for asset in portfolio["assets"])
            portfolio["profit_loss_percent"] = (portfolio["profit_loss"] / 
                                              (portfolio["total_value"] - portfolio["profit_loss"])) * 100 if portfolio["total_value"] != portfolio["profit_loss"] else 0
            
            logger.info(f"Retrieved portfolio status with {len(portfolio['assets'])} assets")
            
            return portfolio
        except Exception as e:
            logger.error(f"Error getting portfolio status: {str(e)}")
            return {"error": str(e)}
    
    def generate_report(self, report_type: str, parameters: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Generate a report of the specified type.
        
        Args:
            report_type: Type of report to generate
            parameters: Additional parameters for report generation
            
        Returns:
            Dict containing the report data
        """
        logger.info(f"Generating {report_type} report")
        
        if parameters is None:
            parameters = {}
        
        try:
            report_data = {}
            
            # Generate different types of reports
            if report_type == "performance":
                report_data = self._generate_performance_report(parameters)
            elif report_type == "market_analysis":
                report_data = self._generate_market_analysis_report(parameters)
            elif report_type == "portfolio":
                report_data = self._generate_portfolio_report(parameters)
            elif report_type == "system_health":
                report_data = self._generate_system_health_report(parameters)
            else:
                return {"error": f"Unknown report type: {report_type}"}
            
            # Save report to database
            if hasattr(self, 'db'):
                report_id = generate_id()
                self.db.save_report(self.agent_id, report_id, {
                    "type": report_type,
                    "parameters": parameters,
                    "data": report_data,
                    "generated_at": datetime.datetime.now().isoformat()
                })
                report_data["report_id"] = report_id
            
            logger.info(f"{report_type} report generated successfully")
            
            return report_data
        except Exception as e:
            logger.error(f"Error generating {report_type} report: {str(e)}")
            return {"error": str(e)}
    
    def _generate_performance_report(self, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Generate a performance report."""
        # Get time range from parameters
        start_date = parameters.get("start_date", (datetime.datetime.now() - datetime.timedelta(days=30)).isoformat())
        end_date = parameters.get("end_date", datetime.datetime.now().isoformat())
        
        # Get metrics from database
        metrics = self.db.get_metrics(self.agent_id, start_date, end_date) if hasattr(self, 'db') else []
        
        # Process metrics
        processed_metrics = self._process_metrics_for_report(metrics)
        
        return {
            "type": "performance",
            "start_date": start_date,
            "end_date": end_date,
            "metrics": processed_metrics,
            "summary": self._generate_performance_summary(processed_metrics)
        }
    
    def _generate_market_analysis_report(self, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Generate a market analysis report."""
        # Get market and timeframe from parameters
        market_id = parameters.get("market_id", "BTCUSD")
        timeframe = parameters.get("timeframe", "1d")
        limit = parameters.get("limit", 100)
        
        # Perform market analysis
        analysis_results = self.analyze_market(market_id, timeframe, limit)
        
        return {
            "type": "market_analysis",
            "market_id": market_id,
            "timeframe": timeframe,
            "analysis_date": datetime.datetime.now().isoformat(),
            "results": analysis_results
        }
    
    def _generate_portfolio_report(self, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Generate a portfolio report."""
        if not config.TRADING_ENABLED or not hasattr(self, 'trading'):
            return {"error": "Trading is disabled"}
        
        # Get portfolio status
        portfolio = self.trading.get_portfolio()
        
        # Get historical performance if available
        start_date = parameters.get("start_date", (datetime.datetime.now() - datetime.timedelta(days=30)).isoformat())
        historical_performance = self.trading.get_historical_performance(start_date) if hasattr(self.trading, 'get_historical_performance') else []
        
        return {
            "type": "portfolio",
            "date": datetime.datetime.now().isoformat(),
            "portfolio": portfolio,
            "historical_performance": historical_performance,
            "summary": self._generate_portfolio_summary(portfolio, historical_performance)
        }
    
    def _generate_system_health_report(self, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Generate a system health report."""
        # Get component status
        component_status = self.components.copy()
        
        # Get resource usage
        resource_usage = {
            "cpu": self._get_cpu_usage(),
            "memory": self._get_memory_usage(),
            "disk": self._get_disk_usage()
        }
        
        return {
            "type": "system_health",
            "date": datetime.datetime.now().isoformat(),
            "status": self.status,
            "uptime": (datetime.datetime.now() - self.start_time).total_seconds(),
            "components": component_status,
            "resource_usage": resource_usage
        }
    
    def _process_metrics_for_report(self, metrics: List[Dict[str, Any]]) -> Dict[str, List]:
        """Process metrics for reporting."""
        processed = {
            "timestamps": [],
            "trading_performance": [],
            "analysis_accuracy": []
        }
        
        for metric in metrics:
            processed["timestamps"].append(metric.get("timestamp"))
            
            if "trading" in metric:
                processed["trading_performance"].append(metric["trading"].get("performance", 0))
            else:
                processed["trading_performance"].append(0)
            
            if "analysis" in metric:
                processed["analysis_accuracy"].append(metric["analysis"].get("accuracy", 0))
            else:
                processed["analysis_accuracy"].append(0)
        
        return processed
    
    def _generate_performance_summary(self, metrics: Dict[str, List]) -> Dict[str, Any]:
        """Generate a summary of performance metrics."""
        if not metrics["trading_performance"]:
            return {"error": "No performance data available"}
        
        return {
            "average_trading_performance": sum(metrics["trading_performance"]) / len(metrics["trading_performance"]) if metrics["trading_performance"] else 0,
            "average_analysis_accuracy": sum(metrics["analysis_accuracy"]) / len(metrics["analysis_accuracy"]) if metrics["analysis_accuracy"] else 0,
            "max_trading_performance": max(metrics["trading_performance"]) if metrics["trading_performance"] else 0,
            "min_trading_performance": min(metrics["trading_performance"]) if metrics["trading_performance"] else 0
        }
    
    def _generate_portfolio_summary(self, portfolio: Dict[str, Any], historical_performance: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate a summary of portfolio performance."""
        if "error" in portfolio:
            return {"error": "Portfolio data not available"}
        
        # Calculate performance metrics
        total_value = portfolio.get("total_value", 0)
        profit_loss = portfolio.get("profit_loss", 0)
        profit_loss_percent = portfolio.get("profit_loss_percent", 0)
        
        # Calculate historical metrics if available
        historical_returns = []
        for perf in historical_performance:
            if "daily_return" in perf:
                historical_returns.append(perf["daily_return"])
        
        volatility = np.std(historical_returns) * 100 if historical_returns else 0
        sharpe_ratio = (np.mean(historical_returns) / np.std(historical_returns)) * np.sqrt(252) if historical_returns and np.std(historical_returns) > 0 else 0
        
        return {
            "total_value": total_value,
            "profit_loss": profit_loss,
            "profit_loss_percent": profit_loss_percent,
            "asset_count": len(portfolio.get("assets", [])),
            "volatility": volatility,
            "sharpe_ratio": sharpe_ratio
        }
    
    def _get_cpu_usage(self) -> float:
        """Get current CPU usage."""
        try:
            import psutil
            return psutil.cpu_percent()
        except ImportError:
            return 0
    
    def _get_memory_usage(self) -> Dict[str, float]:
        """Get current memory usage."""
        try:
            import psutil
            memory = psutil.virtual_memory()
            return {
                "total": memory.total / (1024 * 1024 * 1024),  # GB
                "used": memory.used / (1024 * 1024 * 1024),    # GB
                "percent": memory.percent
            }
        except ImportError:
            return {"total": 0, "used": 0, "percent": 0}
    
    def _get_disk_usage(self) -> Dict[str, float]:
        """Get current disk usage."""
        try:
            import psutil
            disk = psutil.disk_usage('/')
            return {
                "total": disk.total / (1024 * 1024 * 1024),  # GB
                "used": disk.used / (1024 * 1024 * 1024),    # GB
                "percent": disk.percent
            }
        except ImportError:
            return {"total": 0, "used": 0, "percent": 0}
    
    def shutdown(self):
        """Shutdown the Genesis Agent and all its components."""
        logger.info(f"Shutting down Genesis Agent {self.agent_id}")
        
        # Stop monitoring thread if active
        if hasattr(self, 'monitoring_active') and self.monitoring_active:
            self.monitoring_active = False
            if hasattr(self, 'monitoring_thread'):
                self.monitoring_thread.join(timeout=5)
        
        # Shutdown trading engine if enabled
        if config.TRADING_ENABLED and hasattr(self, 'trading'):
            self.trading.shutdown()
        
        # Close database connection
        if hasattr(self, 'db'):
            self.db.close()
        
        self.status = "shutdown"
        logger.info(f"Genesis Agent {self.agent_id} shutdown complete")
