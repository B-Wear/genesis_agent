"""
Genesis Agent Analysis Module
--------------------------
This module handles market analysis and financial data processing for the Genesis Agent.
"""

import os
import logging
import datetime
import json
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Union
import requests
import time
from concurrent.futures import ThreadPoolExecutor

from . import config
from .models import ModelManager
from .utils import generate_id, timeframe_to_seconds, format_timestamp, safe_divide

# Configure logging
logger = logging.getLogger('genesis_agent.analysis')

class AnalysisEngine:
    """
    Handles market analysis and financial data processing.
    
    This class provides methods for analyzing market data, generating
    trading signals, and identifying investment opportunities.
    """
    
    def __init__(self, model_manager: ModelManager = None):
        """
        Initialize the analysis engine.
        
        Args:
            model_manager: ModelManager instance for accessing ML models
        """
        self.model_manager = model_manager
        self.data_sources = self._initialize_data_sources()
        self.indicators = self._initialize_indicators()
        self.strategies = {}
        self.analysis_cache = {}
        self.performance_metrics = {
            "analyses_performed": 0,
            "average_analysis_time": 0,
            "successful_predictions": 0,
            "total_predictions": 0
        }
        
        logger.info("Analysis engine initialized")
    
    def _initialize_data_sources(self) -> Dict[str, Any]:
        """Initialize data sources for market data."""
        data_sources = {
            "yahoo_finance": {
                "name": "Yahoo Finance",
                "type": "stock",
                "enabled": True,
                "api_key": config.YAHOO_FINANCE_RAPID_API_KEY if hasattr(config, 'YAHOO_FINANCE_RAPID_API_KEY') else None
            },
            "alpha_vantage": {
                "name": "Alpha Vantage",
                "type": "stock",
                "enabled": False,
                "api_key": None
            },
            "binance": {
                "name": "Binance",
                "type": "crypto",
                "enabled": True,
                "api_key": config.BINANCE_API_KEY if hasattr(config, 'BINANCE_API_KEY') else None,
                "api_secret": config.BINANCE_API_SECRET if hasattr(config, 'BINANCE_API_SECRET') else None
            },
            "alpaca": {
                "name": "Alpaca",
                "type": "stock",
                "enabled": True,
                "api_key": config.ALPACA_API_KEY if hasattr(config, 'ALPACA_API_KEY') else None,
                "api_secret": config.ALPACA_API_SECRET if hasattr(config, 'ALPACA_API_SECRET') else None
            }
        }
        
        return data_sources
    
    def _initialize_indicators(self) -> Dict[str, Any]:
        """Initialize technical indicators for analysis."""
        indicators = {
            "moving_average": {
                "name": "Moving Average",
                "type": "trend",
                "parameters": {
                    "window": 20,
                    "column": "close"
                },
                "function": self._calculate_moving_average
            },
            "exponential_moving_average": {
                "name": "Exponential Moving Average",
                "type": "trend",
                "parameters": {
                    "window": 20,
                    "column": "close"
                },
                "function": self._calculate_exponential_moving_average
            },
            "relative_strength_index": {
                "name": "Relative Strength Index",
                "type": "momentum",
                "parameters": {
                    "window": 14,
                    "column": "close"
                },
                "function": self._calculate_rsi
            },
            "macd": {
                "name": "MACD",
                "type": "momentum",
                "parameters": {
                    "fast_period": 12,
                    "slow_period": 26,
                    "signal_period": 9,
                    "column": "close"
                },
                "function": self._calculate_macd
            },
            "bollinger_bands": {
                "name": "Bollinger Bands",
                "type": "volatility",
                "parameters": {
                    "window": 20,
                    "num_std": 2,
                    "column": "close"
                },
                "function": self._calculate_bollinger_bands
            },
            "average_true_range": {
                "name": "Average True Range",
                "type": "volatility",
                "parameters": {
                    "window": 14
                },
                "function": self._calculate_atr
            },
            "on_balance_volume": {
                "name": "On Balance Volume",
                "type": "volume",
                "parameters": {
                    "column": "close"
                },
                "function": self._calculate_obv
            }
        }
        
        return indicators
    
    def get_market_data(self, market_id: str, timeframe: str = "1d", limit: int = 100) -> pd.DataFrame:
        """
        Get historical market data.
        
        Args:
            market_id: Identifier for the market (e.g., "BTCUSD", "AAPL")
            timeframe: Timeframe for data (e.g., "1m", "1h", "1d")
            limit: Number of data points to retrieve
            
        Returns:
            DataFrame with market data
        """
        # Check cache first
        cache_key = f"{market_id}_{timeframe}_{limit}"
        if cache_key in self.analysis_cache:
            cache_entry = self.analysis_cache[cache_key]
            cache_age = (datetime.datetime.now() - cache_entry["timestamp"]).total_seconds()
            
            # Use cache if it's less than 5 minutes old
            if cache_age < 300:
                logger.debug(f"Using cached data for {market_id}")
                return cache_entry["data"]
        
        logger.info(f"Fetching market data for {market_id} on {timeframe} timeframe")
        
        # Determine market type and data source
        market_type = self._determine_market_type(market_id)
        data_source = self._select_data_source(market_type)
        
        if data_source is None:
            logger.error(f"No suitable data source found for {market_id}")
            return pd.DataFrame()
        
        # Fetch data from the selected source
        if data_source == "yahoo_finance":
            data = self._fetch_yahoo_finance_data(market_id, timeframe, limit)
        elif data_source == "binance":
            data = self._fetch_binance_data(market_id, timeframe, limit)
        elif data_source == "alpaca":
            data = self._fetch_alpaca_data(market_id, timeframe, limit)
        else:
            logger.error(f"Unsupported data source: {data_source}")
            return pd.DataFrame()
        
        # Cache the data
        if not data.empty:
            self.analysis_cache[cache_key] = {
                "timestamp": datetime.datetime.now(),
                "data": data
            }
        
        return data
    
    def _determine_market_type(self, market_id: str) -> str:
        """
        Determine the type of market based on the market ID.
        
        Args:
            market_id: Identifier for the market
            
        Returns:
            Market type (e.g., "stock", "crypto")
        """
        # Simple heuristic based on market ID format
        if market_id.endswith("USD") or market_id.endswith("USDT") or market_id.endswith("BTC"):
            return "crypto"
        elif len(market_id) <= 5:
            return "stock"
        else:
            return "unknown"
    
    def _select_data_source(self, market_type: str) -> Optional[str]:
        """
        Select an appropriate data source for the market type.
        
        Args:
            market_type: Type of market
            
        Returns:
            Name of the selected data source or None if no suitable source is found
        """
        # Find enabled data sources for the market type
        suitable_sources = [
            source_name
            for source_name, source_info in self.data_sources.items()
            if source_info["type"] == market_type and source_info["enabled"]
        ]
        
        if not suitable_sources:
            return None
        
        # For now, just return the first suitable source
        # In a more advanced implementation, we could select based on data quality, cost, etc.
        return suitable_sources[0]
    
    def _fetch_yahoo_finance_data(self, market_id: str, timeframe: str, limit: int) -> pd.DataFrame:
        """
        Fetch data from Yahoo Finance.
        
        Args:
            market_id: Stock symbol
            timeframe: Timeframe for data
            limit: Number of data points
            
        Returns:
            DataFrame with market data
        """
        try:
            # Convert timeframe to interval
            interval_map = {
                "1m": "1m",
                "5m": "5m",
                "15m": "15m",
                "30m": "30m",
                "1h": "1h",
                "1d": "1d",
                "1w": "1wk",
                "1M": "1mo"
            }
            
            interval = interval_map.get(timeframe, "1d")
            
            # Calculate range based on limit and interval
            seconds_per_candle = timeframe_to_seconds(timeframe)
            range_seconds = seconds_per_candle * limit
            
            # Convert to Yahoo Finance range
            if range_seconds <= 86400 * 7:
                range_str = "7d"
            elif range_seconds <= 86400 * 30:
                range_str = "1mo"
            elif range_seconds <= 86400 * 90:
                range_str = "3mo"
            elif range_seconds <= 86400 * 180:
                range_str = "6mo"
            elif range_seconds <= 86400 * 365:
                range_str = "1y"
            elif range_seconds <= 86400 * 730:
                range_str = "2y"
            elif range_seconds <= 86400 * 1825:
                range_str = "5y"
            else:
                range_str = "max"
            
            # Use RapidAPI if API key is available
            if self.data_sources["yahoo_finance"]["api_key"]:
                url = "https://apidojo-yahoo-finance-v1.p.rapidapi.com/stock/v3/get-historical-data"
                
                headers = {
                    "X-RapidAPI-Key": self.data_sources["yahoo_finance"]["api_key"],
                    "X-RapidAPI-Host": "apidojo-yahoo-finance-v1.p.rapidapi.com"
                }
                
                params = {
                    "symbol": market_id,
                    "region": "US"
                }
                
                response = requests.get(url, headers=headers, params=params)
                response.raise_for_status()
                
                data = response.json()
                
                if "prices" not in data:
                    logger.error(f"Invalid response from Yahoo Finance API: {data}")
                    return pd.DataFrame()
                
                # Convert to DataFrame
                df = pd.DataFrame(data["prices"])
                
                # Rename columns
                df = df.rename(columns={
                    "date": "timestamp",
                    "open": "open",
                    "high": "high",
                    "low": "low",
                    "close": "close",
                    "volume": "volume",
                    "adjclose": "adj_close"
                })
                
                # Convert timestamp to datetime
                df["timestamp"] = pd.to_datetime(df["timestamp"], unit="s")
                
                # Set timestamp as index
                df = df.set_index("timestamp")
                
                # Sort by timestamp
                df = df.sort_index()
                
                # Limit to requested number of data points
                df = df.tail(limit)
                
                return df
            
            # Use yfinance as fallback
            else:
                import yfinance as yf
                
                # Fetch data
                data = yf.download(
                    market_id,
                    period=range_str,
                    interval=interval,
                    auto_adjust=True
                )
                
                # Rename columns
                data = data.rename(columns={
                    "Open": "open",
                    "High": "high",
                    "Low": "low",
                    "Close": "close",
                    "Volume": "volume"
                })
                
                # Limit to requested number of data points
                data = data.tail(limit)
                
                return data
        
        except Exception as e:
            logger.error(f"Error fetching Yahoo Finance data for {market_id}: {str(e)}")
            return pd.DataFrame()
    
    def _fetch_binance_data(self, market_id: str, timeframe: str, limit: int) -> pd.DataFrame:
        """
        Fetch data from Binance.
        
        Args:
            market_id: Cryptocurrency pair
            timeframe: Timeframe for data
            limit: Number of data points
            
        Returns:
            DataFrame with market data
        """
        try:
            # Convert timeframe to Binance interval
            interval_map = {
                "1m": "1m",
                "3m": "3m",
                "5m": "5m",
                "15m": "15m",
                "30m": "30m",
                "1h": "1h",
                "2h": "2h",
                "4h": "4h",
                "6h": "6h",
                "8h": "8h",
                "12h": "12h",
                "1d": "1d",
                "3d": "3d",
                "1w": "1w",
                "1M": "1M"
            }
            
            interval = interval_map.get(timeframe, "1d")
            
            # Use python-binance if API keys are available
            if self.data_sources["binance"]["api_key"] and self.data_sources["binance"]["api_secret"]:
                from binance.client import Client
                
                client = Client(
                    self.data_sources["binance"]["api_key"],
                    self.data_sources["binance"]["api_secret"]
                )
                
                # Fetch klines
                klines = client.get_klines(
                    symbol=market_id,
                    interval=interval,
                    limit=limit
                )
                
                # Convert to DataFrame
                df = pd.DataFrame(klines, columns=[
                    "timestamp", "open", "high", "low", "close", "volume",
                    "close_time", "quote_asset_volume", "number_of_trades",
                    "taker_buy_base_asset_volume", "taker_buy_quote_asset_volume", "ignore"
                ])
                
                # Convert types
                df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
                df["open"] = df["open"].astype(float)
                df["high"] = df["high"].astype(float)
                df["low"] = df["low"].astype(float)
                df["close"] = df["close"].astype(float)
                df["volume"] = df["volume"].astype(float)
                
                # Set timestamp as index
                df = df.set_index("timestamp")
                
                # Keep only OHLCV columns
                df = df[["open", "high", "low", "close", "volume"]]
                
                return df
            
            # Use public API as fallback
            else:
                url = f"https://api.binance.com/api/v3/klines"
                
                params = {
                    "symbol": market_id,
                    "interval": interval,
                    "limit": limit
                }
                
                response = requests.get(url, params=params)
                response.raise_for_status()
                
                data = response.json()
                
                # Convert to DataFrame
                df = pd.DataFrame(data, columns=[
                    "timestamp", "open", "high", "low", "close", "volume",
                    "close_time", "quote_asset_volume", "number_of_trades",
                    "taker_buy_base_asset_volume", "taker_buy_quote_asset_volume", "ignore"
                ])
                
                # Convert types
                df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
                df["open"] = df["open"].astype(float)
                df["high"] = df["high"].astype(float)
                df["low"] = df["low"].astype(float)
                df["close"] = df["close"].astype(float)
                df["volume"] = df["volume"].astype(float)
                
                # Set timestamp as index
                df = df.set_index("timestamp")
                
                # Keep only OHLCV columns
                df = df[["open", "high", "low", "close", "volume"]]
                
                return df
        
        except Exception as e:
            logger.error(f"Error fetching Binance data for {market_id}: {str(e)}")
            return pd.DataFrame()
    
    def _fetch_alpaca_data(self, market_id: str, timeframe: str, limit: int) -> pd.DataFrame:
        """
        Fetch data from Alpaca.
        
        Args:
            market_id: Stock symbol
            timeframe: Timeframe for data
            limit: Number of data points
            
        Returns:
            DataFrame with market data
        """
        try:
            # Check if API keys are available
            if not self.data_sources["alpaca"]["api_key"] or not self.data_sources["alpaca"]["api_secret"]:
                logger.error("Alpaca API keys not configured")
                return pd.DataFrame()
            
            import alpaca_trade_api as tradeapi
            
            # Convert timeframe to Alpaca timeframe
            timeframe_map = {
                "1m": "1Min",
                "5m": "5Min",
                "15m": "15Min",
                "30m": "30Min",
                "1h": "1Hour",
                "1d": "1Day"
            }
            
            alpaca_timeframe = timeframe_map.get(timeframe, "1Day")
            
            # Initialize Alpaca API
            api = tradeapi.REST(
                self.data_sources["alpaca"]["api_key"],
                self.data_sources["alpaca"]["api_secret"],
                base_url=config.ALPACA_BASE_URL if hasattr(config, 'ALPACA_BASE_URL') else "https://paper-api.alpaca.markets"
            )
            
            # Calculate start and end dates
            end_date = datetime.datetime.now()
            seconds_per_candle = timeframe_to_seconds(timeframe)
            start_date = end_date - datetime.timedelta(seconds=seconds_per_candle * limit)
            
            # Fetch data
            df = api.get_barset(
                market_id,
                alpaca_timeframe,
                limit=limit,
                start=start_date.isoformat(),
                end=end_date.isoformat()
            ).df
            
            # Handle multi-symbol response
            if isinstance(df.columns, pd.MultiIndex):
                df = df[market_id]
            
            # Rename columns
            df = df.rename(columns={
                "open": "open",
                "high": "high",
                "low": "low",
                "close": "close",
                "volume": "volume"
            })
            
            return df
        
        except Exception as e:
            logger.error(f"Error fetching Alpaca data for {market_id}: {str(e)}")
            return pd.DataFrame()
    
    def analyze_market(self, market_id: str, timeframe: str = "1d", limit: int = 100) -> Dict[str, Any]:
        """
        Perform comprehensive analysis on a market.
        
        Args:
            market_id: Identifier for the market
            timeframe: Timeframe for analysis
            limit: Number of data points to analyze
            
        Returns:
            Dictionary with analysis results
        """
        start_time = time.time()
        logger.info(f"Analyzing market {market_id} on {timeframe} timeframe")
        
        try:
            # Get market data
            data = self.get_market_data(market_id, timeframe, limit)
            
            if data.empty:
                logger.error(f"No data available for {market_id}")
                return {"error": "No data available"}
            
            # Calculate technical indicators
            indicators = self._calculate_indicators(data)
            
            # Perform trend analysis
            trend_analysis = self._analyze_trend(data, indicators)
            
            # Perform volatility analysis
            volatility_analysis = self._analyze_volatility(data, indicators)
            
            # Perform volume analysis
            volume_analysis = self._analyze_volume(data, indicators)
            
            # Perform sentiment analysis if model is available
            sentiment_analysis = self._analyze_sentiment(market_id)
            
            # Generate trading signals
            signals = self._generate_signals(data, indicators, trend_analysis, volatility_analysis, volume_analysis, sentiment_analysis)
            
            # Make price predictions if model is available
            predictions = self._predict_prices(market_id, data)
            
            # Identify potential opportunities
            opportunities = self._identify_opportunities(market_id, data, indicators, signals, predictions)
            
            # Calculate market statistics
            stats = self._calculate_market_statistics(data)
            
            # Update performance metrics
            self.performance_metrics["analyses_performed"] += 1
            self.performance_metrics["average_analysis_time"] = (
                (self.performance_metrics["average_analysis_time"] * (self.performance_metrics["analyses_performed"] - 1)) +
                (time.time() - start_time)
            ) / self.performance_metrics["analyses_performed"]
            
            # Compile results
            results = {
                "market_id": market_id,
                "timeframe": timeframe,
                "analysis_time": datetime.datetime.now().isoformat(),
                "data_points": len(data),
                "latest_price": float(data["close"].iloc[-1]) if "close" in data else None,
                "price_change_24h": float(data["close"].iloc[-1] - data["close"].iloc[-2]) if len(data) > 1 and "close" in data else None,
                "price_change_percent_24h": float((data["close"].iloc[-1] / data["close"].iloc[-2] - 1) * 100) if len(data) > 1 and "close" in data else None,
                "indicators": indicators,
                "trend_analysis": trend_analysis,
                "volatility_analysis": volatility_analysis,
                "volume_analysis": volume_analysis,
                "sentiment_analysis": sentiment_analysis,
                "signals": signals,
                "predictions": predictions,
                "opportunities": opportunities,
                "statistics": stats
            }
            
            logger.info(f"Analysis of {market_id} completed in {time.time() - start_time:.2f} seconds")
            return results
        
        except Exception as e:
            logger.error(f"Error analyzing market {market_id}: {str(e)}")
            return {"error": str(e)}
    
    def _calculate_indicators(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Calculate technical indicators for the given data.
        
        Args:
            data: Market data as DataFrame
            
        Returns:
            Dictionary with calculated indicators
        """
        results = {}
        
        # Calculate each indicator
        for indicator_name, indicator_info in self.indicators.items():
            try:
                # Call the indicator function with the data and parameters
                indicator_result = indicator_info["function"](data, **indicator_info["parameters"])
                results[indicator_name] = indicator_result
            except Exception as e:
                logger.error(f"Error calculating indicator {indicator_name}: {str(e)}")
                results[indicator_name] = None
        
        return results
    
    def _calculate_moving_average(self, data: pd.DataFrame, window: int, column: str) -> Dict[str, Any]:
        """
        Calculate simple moving average.
        
        Args:
            data: Market data
            window: Window size for MA
            column: Column to use for calculation
            
        Returns:
            Dictionary with MA values
        """
        if column not in data.columns:
            return {"error": f"Column {column} not found in data"}
        
        ma = data[column].rolling(window=window).mean()
        
        return {
            "name": "Moving Average",
            "window": window,
            "values": ma.dropna().tolist(),
            "latest": float(ma.iloc[-1]) if not ma.empty else None
        }
    
    def _calculate_exponential_moving_average(self, data: pd.DataFrame, window: int, column: str) -> Dict[str, Any]:
        """
        Calculate exponential moving average.
        
        Args:
            data: Market data
            window: Window size for EMA
            column: Column to use for calculation
            
        Returns:
            Dictionary with EMA values
        """
        if column not in data.columns:
            return {"error": f"Column {column} not found in data"}
        
        ema = data[column].ewm(span=window, adjust=False).mean()
        
        return {
            "name": "Exponential Moving Average",
            "window": window,
            "values": ema.dropna().tolist(),
            "latest": float(ema.iloc[-1]) if not ema.empty else None
        }
    
    def _calculate_rsi(self, data: pd.DataFrame, window: int, column: str) -> Dict[str, Any]:
        """
        Calculate Relative Strength Index.
        
        Args:
            data: Market data
            window: Window size for RSI
            column: Column to use for calculation
            
        Returns:
            Dictionary with RSI values
        """
        if column not in data.columns:
            return {"error": f"Column {column} not found in data"}
        
        # Calculate price changes
        delta = data[column].diff()
        
        # Separate gains and losses
        gain = delta.where(delta > 0, 0)
        loss = -delta.where(delta < 0, 0)
        
        # Calculate average gain and loss
        avg_gain = gain.rolling(window=window).mean()
        avg_loss = loss.rolling(window=window).mean()
        
        # Calculate RS
        rs = avg_gain / avg_loss
        
        # Calculate RSI
        rsi = 100 - (100 / (1 + rs))
        
        return {
            "name": "Relative Strength Index",
            "window": window,
            "values": rsi.dropna().tolist(),
            "latest": float(rsi.iloc[-1]) if not rsi.empty else None,
            "is_oversold": float(rsi.iloc[-1]) < 30 if not rsi.empty else None,
            "is_overbought": float(rsi.iloc[-1]) > 70 if not rsi.empty else None
        }
    
    def _calculate_macd(self, data: pd.DataFrame, fast_period: int, slow_period: int, signal_period: int, column: str) -> Dict[str, Any]:
        """
        Calculate MACD (Moving Average Convergence Divergence).
        
        Args:
            data: Market data
            fast_period: Fast period for MACD
            slow_period: Slow period for MACD
            signal_period: Signal period for MACD
            column: Column to use for calculation
            
        Returns:
            Dictionary with MACD values
        """
        if column not in data.columns:
            return {"error": f"Column {column} not found in data"}
        
        # Calculate EMAs
        ema_fast = data[column].ewm(span=fast_period, adjust=False).mean()
        ema_slow = data[column].ewm(span=slow_period, adjust=False).mean()
        
        # Calculate MACD line
        macd_line = ema_fast - ema_slow
        
        # Calculate signal line
        signal_line = macd_line.ewm(span=signal_period, adjust=False).mean()
        
        # Calculate histogram
        histogram = macd_line - signal_line
        
        return {
            "name": "MACD",
            "fast_period": fast_period,
            "slow_period": slow_period,
            "signal_period": signal_period,
            "macd_line": macd_line.dropna().tolist(),
            "signal_line": signal_line.dropna().tolist(),
            "histogram": histogram.dropna().tolist(),
            "latest_macd": float(macd_line.iloc[-1]) if not macd_line.empty else None,
            "latest_signal": float(signal_line.iloc[-1]) if not signal_line.empty else None,
            "latest_histogram": float(histogram.iloc[-1]) if not histogram.empty else None,
            "is_bullish": float(macd_line.iloc[-1]) > float(signal_line.iloc[-1]) if not macd_line.empty and not signal_line.empty else None,
            "is_bearish": float(macd_line.iloc[-1]) < float(signal_line.iloc[-1]) if not macd_line.empty and not signal_line.empty else None
        }
    
    def _calculate_bollinger_bands(self, data: pd.DataFrame, window: int, num_std: float, column: str) -> Dict[str, Any]:
        """
        Calculate Bollinger Bands.
        
        Args:
            data: Market data
            window: Window size for moving average
            num_std: Number of standard deviations for bands
            column: Column to use for calculation
            
        Returns:
            Dictionary with Bollinger Bands values
        """
        if column not in data.columns:
            return {"error": f"Column {column} not found in data"}
        
        # Calculate middle band (SMA)
        middle_band = data[column].rolling(window=window).mean()
        
        # Calculate standard deviation
        std = data[column].rolling(window=window).std()
        
        # Calculate upper and lower bands
        upper_band = middle_band + (std * num_std)
        lower_band = middle_band - (std * num_std)
        
        # Calculate bandwidth
        bandwidth = (upper_band - lower_band) / middle_band
        
        # Calculate %B
        percent_b = (data[column] - lower_band) / (upper_band - lower_band)
        
        return {
            "name": "Bollinger Bands",
            "window": window,
            "num_std": num_std,
            "middle_band": middle_band.dropna().tolist(),
            "upper_band": upper_band.dropna().tolist(),
            "lower_band": lower_band.dropna().tolist(),
            "bandwidth": bandwidth.dropna().tolist(),
            "percent_b": percent_b.dropna().tolist(),
            "latest_middle": float(middle_band.iloc[-1]) if not middle_band.empty else None,
            "latest_upper": float(upper_band.iloc[-1]) if not upper_band.empty else None,
            "latest_lower": float(lower_band.iloc[-1]) if not lower_band.empty else None,
            "latest_bandwidth": float(bandwidth.iloc[-1]) if not bandwidth.empty else None,
            "latest_percent_b": float(percent_b.iloc[-1]) if not percent_b.empty else None,
            "is_above_upper": float(data[column].iloc[-1]) > float(upper_band.iloc[-1]) if not data.empty and not upper_band.empty else None,
            "is_below_lower": float(data[column].iloc[-1]) < float(lower_band.iloc[-1]) if not data.empty and not lower_band.empty else None
        }
    
    def _calculate_atr(self, data: pd.DataFrame, window: int) -> Dict[str, Any]:
        """
        Calculate Average True Range.
        
        Args:
            data: Market data
            window: Window size for ATR
            
        Returns:
            Dictionary with ATR values
        """
        if "high" not in data.columns or "low" not in data.columns or "close" not in data.columns:
            return {"error": "Required columns (high, low, close) not found in data"}
        
        # Calculate true range
        high_low = data["high"] - data["low"]
        high_close = (data["high"] - data["close"].shift()).abs()
        low_close = (data["low"] - data["close"].shift()).abs()
        
        true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        
        # Calculate ATR
        atr = true_range.rolling(window=window).mean()
        
        return {
            "name": "Average True Range",
            "window": window,
            "values": atr.dropna().tolist(),
            "latest": float(atr.iloc[-1]) if not atr.empty else None
        }
    
    def _calculate_obv(self, data: pd.DataFrame, column: str) -> Dict[str, Any]:
        """
        Calculate On Balance Volume.
        
        Args:
            data: Market data
            column: Column to use for price
            
        Returns:
            Dictionary with OBV values
        """
        if column not in data.columns or "volume" not in data.columns:
            return {"error": f"Required columns ({column}, volume) not found in data"}
        
        # Calculate price changes
        price_change = data[column].diff()
        
        # Initialize OBV
        obv = pd.Series(0, index=data.index)
        
        # Calculate OBV
        obv.iloc[1:] = np.where(
            price_change.iloc[1:] > 0,
            data["volume"].iloc[1:],
            np.where(
                price_change.iloc[1:] < 0,
                -data["volume"].iloc[1:],
                0
            )
        ).cumsum()
        
        return {
            "name": "On Balance Volume",
            "values": obv.dropna().tolist(),
            "latest": float(obv.iloc[-1]) if not obv.empty else None
        }
    
    def _analyze_trend(self, data: pd.DataFrame, indicators: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze market trend.
        
        Args:
            data: Market data
            indicators: Calculated technical indicators
            
        Returns:
            Dictionary with trend analysis results
        """
        try:
            # Get relevant indicators
            ma = indicators.get("moving_average", {})
            ema = indicators.get("exponential_moving_average", {})
            macd = indicators.get("macd", {})
            
            # Determine short-term trend (last 5 periods)
            if len(data) >= 5:
                short_term_prices = data["close"].iloc[-5:]
                short_term_trend = "up" if short_term_prices.iloc[-1] > short_term_prices.iloc[0] else "down"
                short_term_strength = abs((short_term_prices.iloc[-1] / short_term_prices.iloc[0] - 1) * 100)
            else:
                short_term_trend = "unknown"
                short_term_strength = 0
            
            # Determine medium-term trend (last 20 periods)
            if len(data) >= 20:
                medium_term_prices = data["close"].iloc[-20:]
                medium_term_trend = "up" if medium_term_prices.iloc[-1] > medium_term_prices.iloc[0] else "down"
                medium_term_strength = abs((medium_term_prices.iloc[-1] / medium_term_prices.iloc[0] - 1) * 100)
            else:
                medium_term_trend = "unknown"
                medium_term_strength = 0
            
            # Determine long-term trend (last 50 periods)
            if len(data) >= 50:
                long_term_prices = data["close"].iloc[-50:]
                long_term_trend = "up" if long_term_prices.iloc[-1] > long_term_prices.iloc[0] else "down"
                long_term_strength = abs((long_term_prices.iloc[-1] / long_term_prices.iloc[0] - 1) * 100)
            else:
                long_term_trend = "unknown"
                long_term_strength = 0
            
            # Check for trend confirmation using MACD
            macd_confirms_trend = False
            if macd.get("is_bullish") and short_term_trend == "up":
                macd_confirms_trend = True
            elif macd.get("is_bearish") and short_term_trend == "down":
                macd_confirms_trend = True
            
            # Check for price relative to moving averages
            price_above_ma = False
            price_above_ema = False
            
            if ma.get("latest") is not None and "close" in data:
                price_above_ma = data["close"].iloc[-1] > ma["latest"]
            
            if ema.get("latest") is not None and "close" in data:
                price_above_ema = data["close"].iloc[-1] > ema["latest"]
            
            # Determine overall trend
            if short_term_trend == medium_term_trend == long_term_trend:
                overall_trend = short_term_trend
                overall_strength = "strong"
            elif short_term_trend == medium_term_trend:
                overall_trend = short_term_trend
                overall_strength = "moderate"
            else:
                overall_trend = short_term_trend
                overall_strength = "weak"
            
            return {
                "short_term": {
                    "trend": short_term_trend,
                    "strength": float(short_term_strength)
                },
                "medium_term": {
                    "trend": medium_term_trend,
                    "strength": float(medium_term_strength)
                },
                "long_term": {
                    "trend": long_term_trend,
                    "strength": float(long_term_strength)
                },
                "overall": {
                    "trend": overall_trend,
                    "strength": overall_strength
                },
                "macd_confirms_trend": macd_confirms_trend,
                "price_above_ma": price_above_ma,
                "price_above_ema": price_above_ema
            }
        
        except Exception as e:
            logger.error(f"Error analyzing trend: {str(e)}")
            return {"error": str(e)}
    
    def _analyze_volatility(self, data: pd.DataFrame, indicators: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze market volatility.
        
        Args:
            data: Market data
            indicators: Calculated technical indicators
            
        Returns:
            Dictionary with volatility analysis results
        """
        try:
            # Get relevant indicators
            bb = indicators.get("bollinger_bands", {})
            atr = indicators.get("average_true_range", {})
            
            # Calculate historical volatility (standard deviation of returns)
            if "close" in data and len(data) > 1:
                returns = data["close"].pct_change().dropna()
                historical_volatility = float(returns.std() * np.sqrt(252))  # Annualized
            else:
                historical_volatility = None
            
            # Determine volatility level based on Bollinger Bandwidth
            volatility_level = "unknown"
            if bb.get("latest_bandwidth") is not None:
                if bb["latest_bandwidth"] > 0.05:
                    volatility_level = "high"
                elif bb["latest_bandwidth"] > 0.02:
                    volatility_level = "medium"
                else:
                    volatility_level = "low"
            
            # Check for volatility expansion/contraction
            volatility_trend = "unknown"
            if bb.get("bandwidth") is not None and len(bb["bandwidth"]) > 5:
                recent_bandwidth = bb["bandwidth"][-5:]
                if recent_bandwidth[-1] > recent_bandwidth[0]:
                    volatility_trend = "expanding"
                else:
                    volatility_trend = "contracting"
            
            # Check for potential breakout based on Bollinger Bands
            potential_breakout = False
            if bb.get("is_above_upper") or bb.get("is_below_lower"):
                potential_breakout = True
            
            return {
                "historical_volatility": historical_volatility,
                "atr": atr.get("latest"),
                "bollinger_bandwidth": bb.get("latest_bandwidth"),
                "volatility_level": volatility_level,
                "volatility_trend": volatility_trend,
                "potential_breakout": potential_breakout
            }
        
        except Exception as e:
            logger.error(f"Error analyzing volatility: {str(e)}")
            return {"error": str(e)}
    
    def _analyze_volume(self, data: pd.DataFrame, indicators: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze trading volume.
        
        Args:
            data: Market data
            indicators: Calculated technical indicators
            
        Returns:
            Dictionary with volume analysis results
        """
        try:
            # Get relevant indicators
            obv = indicators.get("on_balance_volume", {})
            
            # Calculate average volume
            if "volume" in data:
                avg_volume = float(data["volume"].mean())
                latest_volume = float(data["volume"].iloc[-1])
                volume_ratio = latest_volume / avg_volume if avg_volume > 0 else 0
            else:
                avg_volume = None
                latest_volume = None
                volume_ratio = None
            
            # Determine volume trend
            volume_trend = "unknown"
            if "volume" in data and len(data) > 5:
                recent_volume = data["volume"].iloc[-5:]
                if recent_volume.iloc[-1] > recent_volume.iloc[0]:
                    volume_trend = "increasing"
                else:
                    volume_trend = "decreasing"
            
            # Check for volume confirmation of price movement
            volume_confirms_price = False
            if "close" in data and "volume" in data and len(data) > 1:
                price_change = data["close"].iloc[-1] - data["close"].iloc[-2]
                volume_change = data["volume"].iloc[-1] - data["volume"].iloc[-2]
                
                if (price_change > 0 and volume_change > 0) or (price_change < 0 and volume_change > 0):
                    volume_confirms_price = True
            
            # Check for volume divergence
            volume_divergence = False
            if obv.get("values") is not None and "close" in data and len(obv["values"]) > 5 and len(data) > 5:
                recent_obv = obv["values"][-5:]
                recent_price = data["close"].iloc[-5:].values
                
                obv_trend = "up" if recent_obv[-1] > recent_obv[0] else "down"
                price_trend = "up" if recent_price[-1] > recent_price[0] else "down"
                
                if obv_trend != price_trend:
                    volume_divergence = True
            
            return {
                "average_volume": avg_volume,
                "latest_volume": latest_volume,
                "volume_ratio": volume_ratio,
                "volume_trend": volume_trend,
                "volume_confirms_price": volume_confirms_price,
                "volume_divergence": volume_divergence,
                "obv": obv.get("latest")
            }
        
        except Exception as e:
            logger.error(f"Error analyzing volume: {str(e)}")
            return {"error": str(e)}
    
    def _analyze_sentiment(self, market_id: str) -> Dict[str, Any]:
        """
        Analyze market sentiment.
        
        Args:
            market_id: Identifier for the market
            
        Returns:
            Dictionary with sentiment analysis results
        """
        try:
            # Find sentiment analysis models
            sentiment_models = {}
            if self.model_manager:
                sentiment_models = self.model_manager.get_models_by_name("market_sentiment")
            
            if not sentiment_models:
                return {
                    "sentiment": "unknown",
                    "confidence": 0,
                    "source": "none"
                }
            
            # Use the first available model
            model_id, model = next(iter(sentiment_models.items()))
            model_config = self.model_manager.get_model_config(model_id)
            
            # For now, return a placeholder result
            # In a real implementation, we would fetch news, social media data, etc.
            # and use the model to analyze sentiment
            
            return {
                "sentiment": "neutral",
                "confidence": 0.5,
                "source": "model"
            }
        
        except Exception as e:
            logger.error(f"Error analyzing sentiment for {market_id}: {str(e)}")
            return {"error": str(e)}
    
    def _generate_signals(self, data: pd.DataFrame, indicators: Dict[str, Any], trend_analysis: Dict[str, Any], volatility_analysis: Dict[str, Any], volume_analysis: Dict[str, Any], sentiment_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate trading signals based on analysis.
        
        Args:
            data: Market data
            indicators: Calculated technical indicators
            trend_analysis: Trend analysis results
            volatility_analysis: Volatility analysis results
            volume_analysis: Volume analysis results
            sentiment_analysis: Sentiment analysis results
            
        Returns:
            Dictionary with trading signals
        """
        try:
            signals = {
                "buy": [],
                "sell": [],
                "hold": [],
                "overall": "hold",
                "confidence": 0.5
            }
            
            # Check for buy signals
            
            # Moving average crossover
            if (indicators.get("moving_average", {}).get("latest") is not None and
                indicators.get("exponential_moving_average", {}).get("latest") is not None):
                
                ma = indicators["moving_average"]["latest"]
                ema = indicators["exponential_moving_average"]["latest"]
                
                if ema > ma:
                    signals["buy"].append({
                        "type": "ma_crossover",
                        "description": "EMA crossed above MA",
                        "strength": "moderate"
                    })
            
            # RSI oversold
            if indicators.get("relative_strength_index", {}).get("is_oversold"):
                signals["buy"].append({
                    "type": "rsi_oversold",
                    "description": "RSI indicates oversold conditions",
                    "strength": "strong"
                })
            
            # MACD bullish crossover
            if indicators.get("macd", {}).get("is_bullish"):
                signals["buy"].append({
                    "type": "macd_bullish",
                    "description": "MACD line crossed above signal line",
                    "strength": "moderate"
                })
            
            # Bollinger Bands bounce from lower band
            if (indicators.get("bollinger_bands", {}).get("is_below_lower") and
                trend_analysis.get("short_term", {}).get("trend") == "up"):
                
                signals["buy"].append({
                    "type": "bb_bounce",
                    "description": "Price bounced from lower Bollinger Band",
                    "strength": "moderate"
                })
            
            # Volume confirmation of uptrend
            if (volume_analysis.get("volume_confirms_price") and
                trend_analysis.get("short_term", {}).get("trend") == "up"):
                
                signals["buy"].append({
                    "type": "volume_confirmation",
                    "description": "Volume confirms uptrend",
                    "strength": "moderate"
                })
            
            # Positive sentiment
            if sentiment_analysis.get("sentiment") == "bullish":
                signals["buy"].append({
                    "type": "positive_sentiment",
                    "description": "Market sentiment is bullish",
                    "strength": "weak"
                })
            
            # Check for sell signals
            
            # Moving average crossover
            if (indicators.get("moving_average", {}).get("latest") is not None and
                indicators.get("exponential_moving_average", {}).get("latest") is not None):
                
                ma = indicators["moving_average"]["latest"]
                ema = indicators["exponential_moving_average"]["latest"]
                
                if ema < ma:
                    signals["sell"].append({
                        "type": "ma_crossover",
                        "description": "EMA crossed below MA",
                        "strength": "moderate"
                    })
            
            # RSI overbought
            if indicators.get("relative_strength_index", {}).get("is_overbought"):
                signals["sell"].append({
                    "type": "rsi_overbought",
                    "description": "RSI indicates overbought conditions",
                    "strength": "strong"
                })
            
            # MACD bearish crossover
            if indicators.get("macd", {}).get("is_bearish"):
                signals["sell"].append({
                    "type": "macd_bearish",
                    "description": "MACD line crossed below signal line",
                    "strength": "moderate"
                })
            
            # Bollinger Bands bounce from upper band
            if (indicators.get("bollinger_bands", {}).get("is_above_upper") and
                trend_analysis.get("short_term", {}).get("trend") == "down"):
                
                signals["sell"].append({
                    "type": "bb_bounce",
                    "description": "Price bounced from upper Bollinger Band",
                    "strength": "moderate"
                })
            
            # Volume confirmation of downtrend
            if (volume_analysis.get("volume_confirms_price") and
                trend_analysis.get("short_term", {}).get("trend") == "down"):
                
                signals["sell"].append({
                    "type": "volume_confirmation",
                    "description": "Volume confirms downtrend",
                    "strength": "moderate"
                })
            
            # Negative sentiment
            if sentiment_analysis.get("sentiment") == "bearish":
                signals["sell"].append({
                    "type": "negative_sentiment",
                    "description": "Market sentiment is bearish",
                    "strength": "weak"
                })
            
            # Check for hold signals
            
            # Consolidation pattern
            if volatility_analysis.get("volatility_level") == "low":
                signals["hold"].append({
                    "type": "consolidation",
                    "description": "Market is in consolidation",
                    "strength": "moderate"
                })
            
            # Conflicting signals
            if len(signals["buy"]) > 0 and len(signals["sell"]) > 0:
                signals["hold"].append({
                    "type": "conflicting_signals",
                    "description": "Buy and sell signals are conflicting",
                    "strength": "moderate"
                })
            
            # Determine overall signal
            buy_strength = sum(1 if s["strength"] == "weak" else 2 if s["strength"] == "moderate" else 3 for s in signals["buy"])
            sell_strength = sum(1 if s["strength"] == "weak" else 2 if s["strength"] == "moderate" else 3 for s in signals["sell"])
            hold_strength = sum(1 if s["strength"] == "weak" else 2 if s["strength"] == "moderate" else 3 for s in signals["hold"])
            
            if buy_strength > sell_strength and buy_strength > hold_strength:
                signals["overall"] = "buy"
                signals["confidence"] = min(0.9, 0.5 + (buy_strength - max(sell_strength, hold_strength)) / 10)
            elif sell_strength > buy_strength and sell_strength > hold_strength:
                signals["overall"] = "sell"
                signals["confidence"] = min(0.9, 0.5 + (sell_strength - max(buy_strength, hold_strength)) / 10)
            else:
                signals["overall"] = "hold"
                signals["confidence"] = min(0.9, 0.5 + (hold_strength - max(buy_strength, sell_strength)) / 10)
            
            return signals
        
        except Exception as e:
            logger.error(f"Error generating signals: {str(e)}")
            return {"error": str(e)}
    
    def _predict_prices(self, market_id: str, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Make price predictions using ML models.
        
        Args:
            market_id: Identifier for the market
            data: Market data
            
        Returns:
            Dictionary with price predictions
        """
        try:
            # Find price prediction models
            prediction_models = {}
            if self.model_manager:
                prediction_models = self.model_manager.get_models_by_name("price_prediction")
            
            if not prediction_models:
                return {
                    "next_period": None,
                    "next_day": None,
                    "next_week": None,
                    "confidence": 0
                }
            
            # Use the first available model
            model_id, model = next(iter(prediction_models.items()))
            model_config = self.model_manager.get_model_config(model_id)
            
            # For now, return a placeholder prediction
            # In a real implementation, we would prepare the data and use the model to make predictions
            
            if "close" in data and len(data) > 0:
                latest_price = float(data["close"].iloc[-1])
                
                # Simple placeholder predictions
                next_period_prediction = latest_price * (1 + np.random.normal(0, 0.01))
                next_day_prediction = latest_price * (1 + np.random.normal(0, 0.02))
                next_week_prediction = latest_price * (1 + np.random.normal(0, 0.05))
                
                return {
                    "next_period": float(next_period_prediction),
                    "next_day": float(next_day_prediction),
                    "next_week": float(next_week_prediction),
                    "confidence": 0.5
                }
            else:
                return {
                    "next_period": None,
                    "next_day": None,
                    "next_week": None,
                    "confidence": 0
                }
        
        except Exception as e:
            logger.error(f"Error predicting prices for {market_id}: {str(e)}")
            return {"error": str(e)}
    
    def _identify_opportunities(self, market_id: str, data: pd.DataFrame, indicators: Dict[str, Any], signals: Dict[str, Any], predictions: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Identify potential investment opportunities.
        
        Args:
            market_id: Identifier for the market
            data: Market data
            indicators: Calculated technical indicators
            signals: Generated trading signals
            predictions: Price predictions
            
        Returns:
            List of identified opportunities
        """
        try:
            opportunities = []
            
            # Check for undervalued assets
            if "close" in data and indicators.get("bollinger_bands", {}).get("latest_percent_b") is not None:
                percent_b = indicators["bollinger_bands"]["latest_percent_b"]
                
                if percent_b < 0.2:
                    opportunities.append({
                        "type": "undervalued",
                        "description": "Asset may be undervalued based on Bollinger Bands",
                        "confidence": 0.6,
                        "potential_return": 0.05
                    })
            
            # Check for breakout opportunities
            if (volatility_analysis := volatility_analysis.get("potential_breakout")) and "close" in data:
                latest_price = float(data["close"].iloc[-1])
                
                opportunities.append({
                    "type": "breakout",
                    "description": "Potential breakout detected based on volatility",
                    "confidence": 0.5,
                    "potential_return": 0.08
                })
            
            # Check for trend reversal opportunities
            if (indicators.get("relative_strength_index", {}).get("is_oversold") and
                signals.get("overall") == "buy"):
                
                opportunities.append({
                    "type": "trend_reversal",
                    "description": "Potential trend reversal from downtrend to uptrend",
                    "confidence": 0.7,
                    "potential_return": 0.1
                })
            
            # Check for strong trend continuation
            if (trend_analysis := trend_analysis.get("overall", {}).get("strength") == "strong" and
                signals.get("overall") in ["buy", "sell"]):
                
                opportunities.append({
                    "type": "trend_continuation",
                    "description": f"Strong {trend_analysis.get('overall', {}).get('trend')} trend likely to continue",
                    "confidence": 0.6,
                    "potential_return": 0.06
                })
            
            # Check for positive divergence
            if (indicators.get("relative_strength_index", {}).get("values") and
                "close" in data and len(data) > 5):
                
                price_trend = "up" if data["close"].iloc[-1] > data["close"].iloc[-5] else "down"
                rsi_trend = "up" if indicators["relative_strength_index"]["values"][-1] > indicators["relative_strength_index"]["values"][-5] else "down"
                
                if price_trend == "down" and rsi_trend == "up":
                    opportunities.append({
                        "type": "positive_divergence",
                        "description": "Positive divergence between price and RSI",
                        "confidence": 0.65,
                        "potential_return": 0.08
                    })
            
            return opportunities
        
        except Exception as e:
            logger.error(f"Error identifying opportunities for {market_id}: {str(e)}")
            return []
    
    def _calculate_market_statistics(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Calculate various market statistics.
        
        Args:
            data: Market data
            
        Returns:
            Dictionary with market statistics
        """
        try:
            stats = {}
            
            if "close" in data:
                # Price statistics
                stats["price"] = {
                    "latest": float(data["close"].iloc[-1]) if len(data) > 0 else None,
                    "mean": float(data["close"].mean()) if len(data) > 0 else None,
                    "median": float(data["close"].median()) if len(data) > 0 else None,
                    "std": float(data["close"].std()) if len(data) > 0 else None,
                    "min": float(data["close"].min()) if len(data) > 0 else None,
                    "max": float(data["close"].max()) if len(data) > 0 else None
                }
                
                # Return statistics
                if len(data) > 1:
                    returns = data["close"].pct_change().dropna()
                    
                    stats["returns"] = {
                        "latest": float(returns.iloc[-1]) if len(returns) > 0 else None,
                        "mean": float(returns.mean()) if len(returns) > 0 else None,
                        "median": float(returns.median()) if len(returns) > 0 else None,
                        "std": float(returns.std()) if len(returns) > 0 else None,
                        "min": float(returns.min()) if len(returns) > 0 else None,
                        "max": float(returns.max()) if len(returns) > 0 else None,
                        "sharpe": float(returns.mean() / returns.std() * np.sqrt(252)) if len(returns) > 0 and returns.std() > 0 else None
                    }
            
            if "volume" in data:
                # Volume statistics
                stats["volume"] = {
                    "latest": float(data["volume"].iloc[-1]) if len(data) > 0 else None,
                    "mean": float(data["volume"].mean()) if len(data) > 0 else None,
                    "median": float(data["volume"].median()) if len(data) > 0 else None,
                    "std": float(data["volume"].std()) if len(data) > 0 else None,
                    "min": float(data["volume"].min()) if len(data) > 0 else None,
                    "max": float(data["volume"].max()) if len(data) > 0 else None
                }
            
            return stats
        
        except Exception as e:
            logger.error(f"Error calculating market statistics: {str(e)}")
            return {"error": str(e)}
    
    def create_strategy(self, strategy_config: Dict[str, Any]) -> Any:
        """
        Create a new analysis strategy.
        
        Args:
            strategy_config: Configuration for the strategy
            
        Returns:
            Strategy object
        """
        strategy_id = generate_id()
        strategy_type = strategy_config.get("type", "unknown")
        
        logger.info(f"Creating analysis strategy {strategy_id} of type {strategy_type}")
        
        try:
            if strategy_type == "trend_following":
                strategy = TrendFollowingStrategy(strategy_config)
            elif strategy_type == "mean_reversion":
                strategy = MeanReversionStrategy(strategy_config)
            elif strategy_type == "breakout":
                strategy = BreakoutStrategy(strategy_config)
            elif strategy_type == "sentiment":
                strategy = SentimentStrategy(strategy_config)
            elif strategy_type == "multi_factor":
                strategy = MultiFactorStrategy(strategy_config)
            else:
                logger.error(f"Unknown strategy type: {strategy_type}")
                return None
            
            # Store the strategy
            self.strategies[strategy_id] = {
                "id": strategy_id,
                "type": strategy_type,
                "config": strategy_config,
                "created_at": datetime.datetime.now().isoformat(),
                "strategy": strategy
            }
            
            logger.info(f"Created analysis strategy {strategy_id}")
            return strategy
        
        except Exception as e:
            logger.error(f"Error creating analysis strategy: {str(e)}")
            return None
    
    def execute_strategy(self, strategy: Any, parameters: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Execute an analysis strategy.
        
        Args:
            strategy: Strategy object to execute
            parameters: Additional parameters for execution
            
        Returns:
            Dictionary with execution results
        """
        if parameters is None:
            parameters = {}
        
        try:
            # Get market data
            market_id = parameters.get("market_id")
            timeframe = parameters.get("timeframe", "1d")
            limit = parameters.get("limit", 100)
            
            if market_id is None:
                return {"error": "Market ID not provided"}
            
            data = self.get_market_data(market_id, timeframe, limit)
            
            if data.empty:
                return {"error": f"No data available for {market_id}"}
            
            # Execute the strategy
            results = strategy.execute(data, self, parameters)
            
            return results
        
        except Exception as e:
            logger.error(f"Error executing analysis strategy: {str(e)}")
            return {"error": str(e)}
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """
        Get performance metrics for the analysis engine.
        
        Returns:
            Dictionary with performance metrics
        """
        return self.performance_metrics


class AnalysisStrategy:
    """Base class for analysis strategies."""
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the strategy.
        
        Args:
            config: Strategy configuration
        """
        self.config = config
        self.name = config.get("name", "Unnamed Strategy")
        self.description = config.get("description", "")
    
    def execute(self, data: pd.DataFrame, analysis_engine: AnalysisEngine, parameters: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Execute the strategy.
        
        Args:
            data: Market data
            analysis_engine: Analysis engine instance
            parameters: Additional parameters
            
        Returns:
            Dictionary with execution results
        """
        raise NotImplementedError("Subclasses must implement execute method")


class TrendFollowingStrategy(AnalysisStrategy):
    """Strategy that follows market trends."""
    
    def execute(self, data: pd.DataFrame, analysis_engine: AnalysisEngine, parameters: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Execute the trend following strategy.
        
        Args:
            data: Market data
            analysis_engine: Analysis engine instance
            parameters: Additional parameters
            
        Returns:
            Dictionary with execution results
        """
        if parameters is None:
            parameters = {}
        
        # Calculate indicators
        ma_window = self.config.get("ma_window", 20)
        ma = data["close"].rolling(window=ma_window).mean()
        
        # Generate signals
        signals = pd.Series(0, index=data.index)
        signals[data["close"] > ma] = 1  # Buy signal
        signals[data["close"] < ma] = -1  # Sell signal
        
        # Calculate returns
        position = signals.shift(1)
        position.iloc[0] = 0
        
        returns = data["close"].pct_change() * position
        cumulative_returns = (1 + returns).cumprod()
        
        return {
            "strategy": "trend_following",
            "signals": signals.tolist(),
            "positions": position.tolist(),
            "returns": returns.tolist(),
            "cumulative_returns": cumulative_returns.tolist(),
            "total_return": float(cumulative_returns.iloc[-1] - 1) if len(cumulative_returns) > 0 else 0,
            "sharpe_ratio": float(returns.mean() / returns.std() * np.sqrt(252)) if returns.std() > 0 else 0,
            "win_rate": float(len(returns[returns > 0]) / len(returns[returns != 0])) if len(returns[returns != 0]) > 0 else 0
        }


class MeanReversionStrategy(AnalysisStrategy):
    """Strategy that trades mean reversion."""
    
    def execute(self, data: pd.DataFrame, analysis_engine: AnalysisEngine, parameters: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Execute the mean reversion strategy.
        
        Args:
            data: Market data
            analysis_engine: Analysis engine instance
            parameters: Additional parameters
            
        Returns:
            Dictionary with execution results
        """
        if parameters is None:
            parameters = {}
        
        # Calculate indicators
        bb_window = self.config.get("bb_window", 20)
        bb_std = self.config.get("bb_std", 2)
        
        ma = data["close"].rolling(window=bb_window).mean()
        std = data["close"].rolling(window=bb_window).std()
        upper_band = ma + (std * bb_std)
        lower_band = ma - (std * bb_std)
        
        # Generate signals
        signals = pd.Series(0, index=data.index)
        signals[data["close"] < lower_band] = 1  # Buy signal
        signals[data["close"] > upper_band] = -1  # Sell signal
        
        # Calculate returns
        position = signals.shift(1)
        position.iloc[0] = 0
        
        returns = data["close"].pct_change() * position
        cumulative_returns = (1 + returns).cumprod()
        
        return {
            "strategy": "mean_reversion",
            "signals": signals.tolist(),
            "positions": position.tolist(),
            "returns": returns.tolist(),
            "cumulative_returns": cumulative_returns.tolist(),
            "total_return": float(cumulative_returns.iloc[-1] - 1) if len(cumulative_returns) > 0 else 0,
            "sharpe_ratio": float(returns.mean() / returns.std() * np.sqrt(252)) if returns.std() > 0 else 0,
            "win_rate": float(len(returns[returns > 0]) / len(returns[returns != 0])) if len(returns[returns != 0]) > 0 else 0
        }


class BreakoutStrategy(AnalysisStrategy):
    """Strategy that trades breakouts."""
    
    def execute(self, data: pd.DataFrame, analysis_engine: AnalysisEngine, parameters: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Execute the breakout strategy.
        
        Args:
            data: Market data
            analysis_engine: Analysis engine instance
            parameters: Additional parameters
            
        Returns:
            Dictionary with execution results
        """
        if parameters is None:
            parameters = {}
        
        # Calculate indicators
        window = self.config.get("window", 20)
        
        high_max = data["high"].rolling(window=window).max()
        low_min = data["low"].rolling(window=window).min()
        
        # Generate signals
        signals = pd.Series(0, index=data.index)
        signals[data["close"] > high_max.shift(1)] = 1  # Buy signal
        signals[data["close"] < low_min.shift(1)] = -1  # Sell signal
        
        # Calculate returns
        position = signals.shift(1)
        position.iloc[0] = 0
        
        returns = data["close"].pct_change() * position
        cumulative_returns = (1 + returns).cumprod()
        
        return {
            "strategy": "breakout",
            "signals": signals.tolist(),
            "positions": position.tolist(),
            "returns": returns.tolist(),
            "cumulative_returns": cumulative_returns.tolist(),
            "total_return": float(cumulative_returns.iloc[-1] - 1) if len(cumulative_returns) > 0 else 0,
            "sharpe_ratio": float(returns.mean() / returns.std() * np.sqrt(252)) if returns.std() > 0 else 0,
            "win_rate": float(len(returns[returns > 0]) / len(returns[returns != 0])) if len(returns[returns != 0]) > 0 else 0
        }


class SentimentStrategy(AnalysisStrategy):
    """Strategy that trades based on sentiment."""
    
    def execute(self, data: pd.DataFrame, analysis_engine: AnalysisEngine, parameters: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Execute the sentiment strategy.
        
        Args:
            data: Market data
            analysis_engine: Analysis engine instance
            parameters: Additional parameters
            
        Returns:
            Dictionary with execution results
        """
        if parameters is None:
            parameters = {}
        
        # In a real implementation, we would use sentiment data
        # For now, use a simple placeholder
        
        # Generate random sentiment scores
        np.random.seed(42)  # For reproducibility
        sentiment_scores = np.random.normal(0, 1, size=len(data))
        
        # Generate signals
        signals = pd.Series(0, index=data.index)
        signals[sentiment_scores > 0.5] = 1  # Buy signal
        signals[sentiment_scores < -0.5] = -1  # Sell signal
        
        # Calculate returns
        position = signals.shift(1)
        position.iloc[0] = 0
        
        returns = data["close"].pct_change() * position
        cumulative_returns = (1 + returns).cumprod()
        
        return {
            "strategy": "sentiment",
            "signals": signals.tolist(),
            "positions": position.tolist(),
            "returns": returns.tolist(),
            "cumulative_returns": cumulative_returns.tolist(),
            "total_return": float(cumulative_returns.iloc[-1] - 1) if len(cumulative_returns) > 0 else 0,
            "sharpe_ratio": float(returns.mean() / returns.std() * np.sqrt(252)) if returns.std() > 0 else 0,
            "win_rate": float(len(returns[returns > 0]) / len(returns[returns != 0])) if len(returns[returns != 0]) > 0 else 0
        }


class MultiFactorStrategy(AnalysisStrategy):
    """Strategy that combines multiple factors."""
    
    def execute(self, data: pd.DataFrame, analysis_engine: AnalysisEngine, parameters: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Execute the multi-factor strategy.
        
        Args:
            data: Market data
            analysis_engine: Analysis engine instance
            parameters: Additional parameters
            
        Returns:
            Dictionary with execution results
        """
        if parameters is None:
            parameters = {}
        
        # Calculate indicators
        ma_window = self.config.get("ma_window", 20)
        rsi_window = self.config.get("rsi_window", 14)
        
        # Moving average
        ma = data["close"].rolling(window=ma_window).mean()
        
        # RSI
        delta = data["close"].diff()
        gain = delta.where(delta > 0, 0)
        loss = -delta.where(delta < 0, 0)
        avg_gain = gain.rolling(window=rsi_window).mean()
        avg_loss = loss.rolling(window=rsi_window).mean()
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        # Generate signals
        trend_signal = pd.Series(0, index=data.index)
        trend_signal[data["close"] > ma] = 1
        trend_signal[data["close"] < ma] = -1
        
        momentum_signal = pd.Series(0, index=data.index)
        momentum_signal[rsi < 30] = 1
        momentum_signal[rsi > 70] = -1
        
        # Combine signals
        signals = trend_signal + momentum_signal
        signals[signals > 0] = 1
        signals[signals < 0] = -1
        
        # Calculate returns
        position = signals.shift(1)
        position.iloc[0] = 0
        
        returns = data["close"].pct_change() * position
        cumulative_returns = (1 + returns).cumprod()
        
        return {
            "strategy": "multi_factor",
            "signals": signals.tolist(),
            "positions": position.tolist(),
            "returns": returns.tolist(),
            "cumulative_returns": cumulative_returns.tolist(),
            "total_return": float(cumulative_returns.iloc[-1] - 1) if len(cumulative_returns) > 0 else 0,
            "sharpe_ratio": float(returns.mean() / returns.std() * np.sqrt(252)) if returns.std() > 0 else 0,
            "win_rate": float(len(returns[returns > 0]) / len(returns[returns != 0])) if len(returns[returns != 0]) > 0 else 0
        }
